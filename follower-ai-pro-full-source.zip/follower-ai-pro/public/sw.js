// Safe caching: only static assets. /api/* and /webhook are NEVER cached; page navigations are network-only with an offline notice.
const CACHE = 'fap-static-v2', STATIC = ['/offline.html', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(STATIC)))); // no auto skipWaiting: the page asks the user to update
self.addEventListener('message', e => { if (e.data === 'SKIP_WAITING') self.skipWaiting(); });
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== CACHE).map(x => caches.delete(x)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/') || u.pathname === '/webhook') return; // network only, nothing stored
  if (r.mode === 'navigate') { e.respondWith(fetch(r).catch(() => caches.match('/offline.html'))); return; }
  if (STATIC.includes(u.pathname)) e.respondWith(caches.match(r).then(m => m || fetch(r)));
});
