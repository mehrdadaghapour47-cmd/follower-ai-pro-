// One AI entry point. Priority: Cloudflare Workers AI binding (no external key) -> Anthropic key -> none.
export const AI_DEFAULT_MODEL = '@cf/meta/llama-3.1-8b-instruct';
export function aiProvider(env) {
  if (env.AI_PROVIDER === 'anthropic' && env.ANTHROPIC_API_KEY) return 'anthropic';
  if (env.AI && typeof env.AI.run === 'function') return 'workers-ai';
  if (env.ANTHROPIC_API_KEY) return 'anthropic';
  return null;
}
export async function runAI(env, { system, user, maxTokens = 700, fetchFn = fetch }) {
  const provider = aiProvider(env);
  if (!provider) return { ok: false, reason: 'NOT_CONNECTED' };
  try {
    if (provider === 'workers-ai') {
      const model = env.AI_MODEL || AI_DEFAULT_MODEL;
      const r = await env.AI.run(model, { messages: [{ role: 'system', content: system }, { role: 'user', content: user }], max_tokens: maxTokens });
      const text = typeof r === 'string' ? r : (r?.response ?? r?.result?.response ?? '');
      if (!String(text).trim()) return { ok: false, reason: 'EMPTY_RESPONSE', provider, model };
      return { ok: true, text: String(text).trim(), provider, model };
    }
    const model = env.ANTHROPIC_MODEL || 'claude-sonnet-4-6';
    const r = await fetchFn('https://api.anthropic.com/v1/messages', { method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model, max_tokens: maxTokens, system, messages: [{ role: 'user', content: user }] }) });
    const j = await r.json().catch(() => ({}));
    const text = j.content?.map(c => c.text).filter(Boolean).join('\n');
    if (!r.ok || !text) return { ok: false, reason: String(j.error?.message || 'HTTP ' + r.status).slice(0, 200), provider, model };
    return { ok: true, text, provider, model };
  } catch (e) { return { ok: false, reason: String(e.message).slice(0, 200), provider }; }
}

// ---------- structured output: safe JSON extraction, schema validation, one retry ----------
export function extractJson(text) {
  const cleaned = String(text || '').replace(/```json/gi, '').replace(/```/g, '').trim();
  try { const v = JSON.parse(cleaned); if (v && typeof v === 'object' && !Array.isArray(v)) return v; } catch { /* scan below */ }
  let depth = 0, start = -1, quote = false, esc = false;
  for (let i = 0; i < cleaned.length; i++) {
    const ch = cleaned[i];
    if (quote) { if (esc) esc = false; else if (ch === '\\') esc = true; else if (ch === '"') quote = false; continue; }
    if (ch === '"') { quote = true; continue; }
    if (ch === '{') { if (depth === 0) start = i; depth++; }
    else if (ch === '}' && depth > 0) { depth--; if (depth === 0 && start >= 0) { try { const v = JSON.parse(cleaned.slice(start, i + 1)); if (v && typeof v === 'object') return v; } catch { /* keep scanning */ } start = -1; } }
  }
  return null;
}
const str = (v, max) => typeof v === 'string' ? v.replace(/\u0000/g, '').trim().slice(0, max) : '';
const arr = (v, max, n) => (Array.isArray(v) ? v : []).map(x => str(x, max)).filter(Boolean).slice(0, n);
// coach schema: {answer: string, actions: string[], missing_data: string[]}
export function validateCoach(v) {
  if (!v || typeof v !== 'object') return null;
  const answer = str(v.answer, 1500); if (!answer) return null;
  return { answer, actions: arr(v.actions, 200, 5), missing_data: arr(v.missing_data, 160, 6) };
}
export async function runAIJson(env, opts, validate) {
  let last = await runAI(env, opts);
  if (!last.ok) return { ...last, structured: false };
  let parsed = validate(extractJson(last.text));
  if (parsed) return { ok: true, structured: true, data: parsed, provider: last.provider, model: last.model, text: last.text };
  const retry = await runAI(env, { ...opts, user: opts.user + '\n\nYour previous reply was not valid JSON for the required schema. Reply again with ONLY the JSON object.' });
  if (retry.ok) { parsed = validate(extractJson(retry.text)); if (parsed) return { ok: true, structured: true, data: parsed, provider: retry.provider, model: retry.model, text: retry.text, retried: true }; last = retry; }
  return { ok: true, structured: false, text: last.text, provider: last.provider, model: last.model }; // graceful: plain text, flagged as unstructured
}
