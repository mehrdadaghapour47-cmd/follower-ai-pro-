CREATE TABLE IF NOT EXISTS records (
  tbl  TEXT NOT NULL,
  k    TEXT NOT NULL,
  ts   INTEGER NOT NULL,
  data TEXT NOT NULL,
  PRIMARY KEY (tbl, k)
);
CREATE INDEX IF NOT EXISTS idx_records_tbl_ts ON records (tbl, ts);
