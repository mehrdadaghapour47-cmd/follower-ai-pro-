# Follower AI Pro
Separate project (NOT the old fallowerai). Persian Instagram growth engine: real-data analysis, daily plans, reel ideas, optional AI summary (Cloudflare Workers AI), mobile dashboard (PWA), several pages ("accounts") in one deployment.
Missing data is always `DATA NOT AVAILABLE`; nothing is invented.

## Cloudflare resources (new, only for this project)
- Worker `follower-ai-pro`
- D1 `follower-ai-pro-db` (id c9b5a22f-09ec-45c7-bd77-1c0bdcbdc659), table `records` + index `idx_records_tbl_ts` already created and verified.
- Workers AI binding `AI` (no external key)

## Secrets (Cloudflare → Worker → Settings → Variables and Secrets, type Secret)
Required: `ADMIN_KEY` (≥16 chars), `TOKEN_ENC_KEY` (32 bytes base64).
Optional: `META_APP_SECRET`, `META_VERIFY_TOKEN` (webhook), `KEYWORD_RULES` (JSON), `ANTHROPIC_API_KEY`, `IG_ACCESS_TOKEN`, `IG_USER_ID`.
Plain variables: `ALLOWED_ORIGINS` (CORS is closed unless set), `RATE_LIMIT_PER_MIN` (default 20), `AI_MODEL` (default @cf/meta/llama-3.1-8b-instruct).

## Deploy from an Android phone (no pasting)
1. GitHub → New repository `follower-ai-pro` (Private) → upload the 3 flat files from `deploy/`: worker.js, wrangler.toml, schema.sql (README.md optional).
2. Cloudflare → Workers & Pages → Create → Import a repository → choose it. Worker name `follower-ai-pro`, deploy command `npx wrangler deploy`, build command empty.
3. After the first build: add the two required Secrets.
4. Open `/api/health` → `{"ok":true,"worker":"OK","d1":"OK"}`. Open `/` for the dashboard.

## API (header `x-admin-key` required; optional `x-account: username` or `?account=`)
POST /api/audit, /api/strategy, /api/reel-ideas, /api/plan (legacy names/shape) · GET /api/dashboard, /api/system · POST /api/sync, /api/import, /api/coach, /api/ai/analyze, /api/keywords/test · /webhook (Meta, HMAC-verified).

## Not implemented
DM sending, multi-user login/credits/payments, audience demographics, full Instagram OAuth. Instagram token refresh and the daily cron cover only the `main` account.

## Tests
`npm test` (89 core + 34 Pro checks + D1/SQL compatibility). All use local mocks, not real Cloudflare/Instagram.
Rebuild the single file: `python3 tools/bundle.py`, then copy dist/worker.js to deploy/worker.js.
