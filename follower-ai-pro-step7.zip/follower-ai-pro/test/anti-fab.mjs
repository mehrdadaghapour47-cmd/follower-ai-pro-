// Anti-fabrication tests for assistantReply (src/assistant.js + src/integrity.js) and the /api/assistant route.
// The Workers AI binding is a SCRIPTED MOCK: each test decides exactly what the "model" says, including lies. D1 is the project's in-memory store.
// Real-data fixture: the project's own public/seed-public-reels.json normalised like /api/import. Nothing external is contacted (fetch is trapped).
import { readFileSync } from 'node:fs';
import { assistantReply, saveTurn, loadHistory, newSessionId } from '../src/assistant.js';
import { getStore } from '../src/store.js';
import { handle } from '../src/index.js';
import { REDACTED } from '../src/integrity.js';
import { analyzeAll, makePlan, weeklyReport, tehranDate } from '../src/planner.js';
import { coachContext } from '../src/coach.js';
let pass = 0, fail = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };
let fetched = 0; const realFetch = globalThis.fetch; globalThis.fetch = async () => { fetched++; return new Response('{}'); };

const NOW = Date.parse('2026-10-11T09:00:00Z'), DAY = 86400000, KEY = 'a-long-random-test-key-1234';
const seed = JSON.parse(readFileSync(new URL('../public/seed-public-reels.json', import.meta.url))).items;
const n = v => (v == null || v === '' || isNaN(+v)) ? null : +v;
const norm = (it, fetchedAt = NOW) => ({ id: String(it.id), source: 'public-scrape', type: it.type || 'REEL', ts: Date.parse(it.date + 'T12:00:00Z'), hasTime: false, caption: it.caption || '', permalink: null, durationSec: n(it.durationSec), metrics: { views: n(it.views), reach: null, likes: n(it.likes), comments: n(it.comments), shares: n(it.shares), saves: n(it.saves), avgWatchSec: null, totalWatchSec: null }, fetchedAt });
const build = (media, daily = []) => { const A = analyzeAll({ media, daily, stories: [], now: NOW }); const plan = makePlan({ date: tehranDate(NOW), A, pastIdeas: [], prevPlan: null, bestHourInfo: { hour: null }, now: NOW }); const weekly = weeklyReport({ all: A.all, daily, stories: [], profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now: NOW }); return { A, plan, weekly, ctx: coachContext(A, plan, weekly) }; };
const daily10 = Array.from({ length: 10 }, (_, i) => ({ date: new Date(NOW - (9 - i) * DAY).toISOString().slice(0, 10), followers: 5000 + i * 10, reach: 1000, views: 2000, interactions: 100, shares: 5, saves: 9, comments: 4, profileViews: 300, follows: 12 }));
const REAL = build(seed.map(i => norm(i))), EMPTY = build([]), STALE = build(seed.map(i => norm(i, NOW - 10 * DAY))), FEW = build(seed.slice(0, 3).map(i => norm(i))), WITHF = build(seed.map(i => norm(i)), daily10);
const r0 = REAL.ctx.lastReels[0], score0 = REAL.ctx.todayTop[0].score;

// scripted mock model: script(callNumber, input) → string (or throws)
const mk = (script, extra = {}) => { const calls = []; const AI = { run: async (m, input) => { calls.push(input); const r = await script(calls.length, input); return { response: r }; } }; return { env: { AI, ALLOW_MEMORY_STORE: '1', ...extra }, calls }; };
const fresh = () => { globalThis.__ige_mem = undefined; };
const ask = (env, store, sid, message, D = REAL) => assistantReply({ store, env, sid, message, A: D.A, plan: D.plan, weekly: D.weekly, now: NOW });
const sys = c => c.messages[0].content, hist = async (store, sid) => (await loadHistory(store, sid, { limit: 50 })).messages;
const setup = (script, extra) => { fresh(); const m = mk(script, extra); return { ...m, store: getStore(m.env), sid: newSessionId() }; };
const FAKE_FOLLOWERS = 'تو ۵۰۰۰۰ فالوور داری و رشد ماهانه ۱۲٪ است.', CLEAN = 'اطلاعات کافی برای فالوور در دسترس نیست. پیشنهاد: یک ریل ۲۰ ثانیه‌ای بساز.';

console.log('\nA. model invents statistics → one rewrite → clean answer');
{
  const t = setup(c => c === 1 ? FAKE_FOLLOWERS : CLEAN); const r = await ask(t.env, t.store, t.sid, 'برای پیجم برنامه بده');
  ok(r.ok && t.calls.length === 2 && r.verification.status === 'retried' && r.verification.retried === true, 'invented numbers → exactly one rewrite → status "retried"');
  ok(r.reply === CLEAN && !/۵۰۰۰۰|۱۲٪/.test(r.reply), 'the user only sees the clean second answer');
  ok(!sys(t.calls[0]).includes('REJECTED DRAFT') && sys(t.calls[1]).includes('REJECTED DRAFT') && sys(t.calls[1]).includes('۵۰۰۰۰'), 'the rewrite request names the offending numbers; the first request did not');
  ok(sys(t.calls[1]).trimEnd().split('PAGE DATA (JSON): ')[1].startsWith('{'), 'prompt still ends with the page-data JSON');
  const h = await hist(t.store, t.sid); ok(h.length === 2 && h[1].content === CLEAN && !JSON.stringify(h).includes('۵۰۰۰۰'), 'only the clean answer is stored; the invented one never reaches the history');
}

console.log('\nB. model keeps inventing → numbers are removed in code');
{
  const t = setup(() => FAKE_FOLLOWERS); const r = await ask(t.env, t.store, t.sid, 'برای پیجم برنامه بده');
  ok(r.ok && t.calls.length === 2 && r.verification.status === 'redacted' && r.verification.removed === 2, 'both drafts invented → status "redacted", 2 numbers removed');
  ok(!r.reply.includes('۵۰۰۰۰') && !r.reply.includes('۱۲٪') && r.reply.includes(REDACTED) && r.reply.includes('فالوور داری'), 'the numbers are replaced by a marker, the rest of the sentence is kept');
  ok(r.reply.includes('غیرقابل‌تأیید حذف شد'), 'the answer itself says that unverifiable numbers were removed');
  ok(r.verification.violations.every(v => v.type === 'unverified') && r.verification.violations.map(v => v.token).join() === '۵۰۰۰۰,۱۲٪', 'verification report lists what was removed');
  const h = await hist(t.store, t.sid); ok(h[1].content === r.reply && !h[1].content.includes('۵۰۰۰۰'), 'the stored answer equals the sanitised answer');
  const t2 = setup((c) => { if (c === 1) return FAKE_FOLLOWERS; throw new Error('model offline'); }); const r2 = await ask(t2.env, t2.store, t2.sid, 'برای پیجم برنامه بده');
  ok(r2.ok && r2.verification.status === 'redacted' && !r2.reply.includes('۵۰۰۰۰'), 'if the rewrite call fails, the first answer is still redacted (never shown raw)');
  const t3 = setup(() => { throw new Error('offline'); }); const r3 = await ask(t3.env, t3.store, t3.sid, 'سلام'); ok(r3.ok === false && !('reply' in r3), 'a failing first call is still an error (unchanged behaviour)');
}

console.log('\nC. real numbers pass untouched, with a code-written basis line');
{
  const real = `داده واقعی: آخرین ریل ${r0.views} بازدید و ${r0.likes} لایک دارد.\nپیشنهاد: یک ریل ۲۰ ثانیه‌ای بساز.`;
  const t = setup(() => real); const r = await ask(t.env, t.store, t.sid, 'وضع آخرین ریلم چطور بود؟');
  ok(r.ok && t.calls.length === 1 && r.verification.status === 'ok' && r.verification.checked >= 2 && r.verification.removed === 0, 'real numbers: one call, status "ok", nothing removed');
  ok(r.reply.startsWith(real) && /مبنا: 12 ریل ذخیره‌شده، دریافت داده 0 روز پیش/.test(r.reply), 'answer is unchanged and a "مبنا:" line states the data basis and age');
  ok(r.source === 'ai' && r.dataQuality.reels === 12 && r.dataQuality.hasData === true && r.dataQuality.missing.includes('followers'), 'response reports source and data quality (followers are NOT stored)');
  const ideas = 'پیشنهاد: ۳ ایده: ۱) هوک ۳ ثانیه‌ای ۲) ریل ۲۰ ثانیه‌ای ۳) ساعت ۲۰:۴۵ منتشر کن؛ ۴ ست ۱۰ تکرار.'; const t2 = setup(() => ideas); const r2 = await ask(t2.env, t2.store, t2.sid, 'ایده بده');
  ok(r2.reply === ideas && t2.calls.length === 1 && r2.verification.status === 'ok' && r2.verification.checked === 0, 'a pure ideas answer (counts, seconds, times) is untouched: no rewrite, no footer');
}

console.log('\nD. numbers written by the user are claims, not facts');
{
  const msg = 'من ۱۰۰۰۰ فالوور دارم، یک ایده ریل بده';
  const t = setup(c => c === 1 ? 'با ۱۰۰۰۰ فالوور باید ریل بیشتری بسازی.' : 'طبق گفته‌ی تو ۱۰۰۰۰ فالوور داری؛ من آن را تأیید نکرده‌ام. پیشنهاد: ریل ۲۰ ثانیه‌ای.');
  const r = await ask(t.env, t.store, t.sid, msg);
  ok(t.calls.length === 2 && r.verification.status === 'retried' && /طبق گفته/.test(r.reply), 'repeating the user\'s number as a fact → rewrite → "according to you" wording accepted');
  ok(sys(t.calls[0]).includes('USER-PROVIDED NUMBERS (UNVERIFIED') && sys(t.calls[0]).includes('10000'), 'the prompt lists the user\'s numbers as UNVERIFIED');
  ok(r.dataQuality.missing.includes('followers') && r.dataQuality.hasData, 'the response still says followers are not stored');
  const t2 = setup(() => 'با ۱۰۰۰۰ فالوور باید ریل بیشتری بسازی.'); const r2 = await ask(t2.env, t2.store, t2.sid, msg);
  ok(r2.verification.status === 'redacted' && !r2.reply.includes('۱۰۰۰۰') && r2.verification.violations[0].type === 'user_number_as_fact', 'if the model keeps stating it as a fact the number is removed (type user_number_as_fact)');
  const t3 = setup(() => 'تو گفتی ۱۰۰۰۰ فالوور داری. پیشنهاد: ریل ۲۰ ثانیه‌ای.'); const r3 = await ask(t3.env, t3.store, t3.sid, msg); ok(t3.calls.length === 1 && r3.verification.status === 'ok', 'correctly attributed to the user → accepted on the first try');
  const t4 = setup(() => 'ok'); const r4 = await ask(t4.env, t4.store, t4.sid, 'من ' + r0.views + ' بازدید گرفتم، درسته؟ ایده بده'); ok(r4.ok, 'a user number that happens to equal a stored value does not break anything');
}

console.log('\nE. followers / reach questions with nothing stored are answered by code');
{
  for (const [q, must] of [['چند فالوور دارم؟', 'تعداد فالوور'], ['ریچ پیجم چقدر است؟', 'ریچ'], ['فالوور و ریچ پیجم چقدره؟', 'ریچ']]) {
    const t = setup(() => { throw new Error('the model must not be called'); }); const r = await ask(t.env, t.store, t.sid, q);
    ok(r.ok && t.calls.length === 0 && r.source === 'rules' && r.reply.startsWith('اطلاعات کافی در دسترس نیست') && r.reply.includes(must) && r.verification.status === 'not_needed', `"${q}" → answered by code, no model call, says information is not available`);
    ok(!/[0-9۰-۹]{3,}.{0,12}(فالوور|ریچ)/.test(r.reply) && (await hist(t.store, t.sid)).length === 2, `"${q}" → no invented number, and the turn is saved to the history`);
  }
  const t = setup(() => { throw new Error('no'); }); const r = await ask(t.env, t.store, t.sid, 'من ۱۰۰۰۰ فالوور دارم درسته؟ تأیید کن');
  ok(r.source === 'rules' && r.reply.includes('تأییدشده نیست') && r.reply.includes('۱۰۰۰۰') && !/تو ۱۰۰۰۰ فالوور داری/.test(r.reply), 'asking to confirm a number → "not confirmed", the number is quoted as the user\'s claim');
  const t1 = setup(() => 'پاسخ'); await ask(t1.env, t1.store, t1.sid, 'چطور فالوورم را بالا ببرم؟'); ok(t1.calls.length === 1, 'advice about growing followers is NOT intercepted (goes to the model)');
  const t5 = setup(() => 'ایده'); await ask(t5.env, t5.store, t5.sid, 'چند ایده برای ریل بده'); ok(t5.calls.length === 1, '"چند ایده" (how many ideas) is not a metric question');
  const w = setup(c => 'فالوور فعلی ' + '۵۰۹۰ است.'); const rw = await ask(w.env, w.store, w.sid, 'چند فالوور دارم؟', WITHF);
  ok(w.calls.length === 1 && sys(w.calls[0]).includes('followers=5090') && rw.verification.status === 'ok' && rw.source === 'ai', 'when a follower count IS stored the model gets it and may quote it');
  const w2 = setup(() => 'فالوور فعلی ۶۰۰۰ است.'); const rw2 = await ask(w2.env, w2.store, w2.sid, 'چند فالوور دارم؟', WITHF); ok(rw2.verification.status === 'redacted' && !rw2.reply.includes('۶۰۰۰'), 'a different number than the stored one is removed even when followers exist');
}

console.log('\nF. earlier turns do not make numbers true');
{
  const t = setup(c => 'خلاصه: تو ۸۰۰۰ فالوور و ۵۰۰۰۰ فالوور داری.'); await saveTurn(t.store, t.sid, 'من ۸۰۰۰ فالوور دارم', 'خب، ۵۰۰۰۰ فالوور خوب است.', { now: NOW - 5000, env: t.env });
  const r = await ask(t.env, t.store, t.sid, 'خلاصه‌ی حرف‌هایمان چه بود؟');
  const types = r.verification.violations.map(v => v.type).sort().join();
  ok(t.calls.length === 2 && r.verification.status === 'redacted' && !r.reply.includes('۸۰۰۰') && !r.reply.includes('۵۰۰۰۰'), 'a fake number from an earlier assistant turn and an earlier user claim are both removed when repeated as facts');
  ok(types === 'unverified,user_number_as_fact', `violation types: ${types}`);
  ok(sys(t.calls[0]).includes('8000') && sys(t.calls[0]).includes('UNVERIFIED'), 'numbers from EARLIER user turns are listed as unverified too');
  ok(t.calls[0].messages.length === 4 && t.calls[0].messages[3].content.includes('خلاصه') && t.calls[0].messages[1].content === 'من ۸۰۰۰ فالوور دارم', 'the earlier turn is still given to the model as conversation context');
  const t2 = setup(() => `همان ${r0.views} بازدید که قبلاً گفتم درست است.`); await saveTurn(t2.store, t2.sid, 'ریل آخر؟', `آخرین ریل ${r0.views} بازدید دارد.`, { now: NOW - 5000, env: t2.env });
  const r2 = await ask(t2.env, t2.store, t2.sid, 'دوباره بگو'); ok(r2.verification.status === 'ok' && t2.calls.length === 1, 'a real number repeated from an earlier turn is fine (it is still in the stored data)');
  const t3 = setup(() => 'ریل آخر ' + (r0.views + 7) + ' بازدید دارد.'); await saveTurn(t3.store, t3.sid, 'ریل آخر؟', `آخرین ریل ${r0.views + 7} بازدید دارد.`, { now: NOW - 5000, env: t3.env });
  const r3 = await ask(t3.env, t3.store, t3.sid, 'دوباره بگو'); ok(r3.verification.status === 'redacted', 'a number that was once said but is not in the CURRENT data (outdated) is removed');
}

console.log('\nG. estimates are not results');
{
  const noMark = `این ایده ${score0} بازدید می‌گیرد.`, marked = `تخمین: امتیاز این ایده ${score0} از ۱۰۰ است (برآورد ابزار، نه نتیجه‌ی واقعی).`;
  const t = setup(c => c === 1 ? noMark : marked); const r = await ask(t.env, t.store, t.sid, 'ایده‌ی امروز چقدر خوب است؟');
  ok(r.verification.status === 'retried' && r.reply.startsWith(marked) && /مبنا:/.test(r.reply), 'an idea score presented as a result is rewritten into a labelled estimate (and the code-written basis line follows)');
  const t2 = setup(() => noMark); const r2 = await ask(t2.env, t2.store, t2.sid, 'ایده‌ی امروز؟'); ok(r2.verification.status === 'redacted' && r2.verification.violations[0].type === 'estimate_as_fact' && !r2.reply.includes(String(score0)), 'if it stays unlabelled the number is removed');
  ok(sys(t.calls[0]).includes('ESTIMATE') && sys(t.calls[0]).includes('SUGGESTION') && sys(t.calls[0]).includes('«داده واقعی:»'), 'the prompt explains OBSERVED / DERIVED / ESTIMATE / SUGGESTION and the three labels');
}

console.log('\nH. stale and thin data are stated');
{
  const t = setup(() => `آخرین ریل ${r0.views} بازدید دارد.`); const r = await ask(t.env, t.store, t.sid, 'وضع آخرین ریل؟', STALE);
  ok(r.dataQuality.stale === true && r.dataQuality.fetchAgeDays === 10 && sys(t.calls[0]).includes('STALE') && /ممکن است قدیمی باشد/.test(r.reply) && /10 روز پیش/.test(r.reply), 'data fetched 10 days ago: STALE in the prompt, "may be outdated" and the age in the answer');
  const t2 = setup(() => `آخرین ریل ${FEW.ctx.lastReels[0].views} بازدید دارد.`); const r2 = await ask(t2.env, t2.store, t2.sid, 'وضع آخرین ریل؟', FEW);
  ok(r2.dataQuality.sufficientForPatterns === false && sys(t2.calls[0]).includes('enough for pattern claims (8+ reels): no') && /نمونه کم است/.test(r2.reply), 'only 3 reels: the prompt says patterns are not supportable and the answer says the sample is small');
  const t3 = setup(() => 'x'); const r3 = await ask(t3.env, t3.store, t3.sid, 'سلام', REAL); ok(sys(t3.calls[0]).includes('NOT STORED: followers, reach') && r3.dataQuality.sufficientForDiagnosis === (REAL.A.health.score != null), 'the prompt lists what is NOT stored');
}

console.log('\nI. no data at all');
{
  const t = setup(() => 'آمار: ۱۲۰۰ بازدید و ۳۰۰ لایک و رشد ۸٪ داشتی.'); const r = await ask(t.env, t.store, t.sid, 'آمار پیجم چیه؟', EMPTY);
  ok(r.hasData === false && r.verification.status === 'redacted' && r.verification.removed === 3 && !/۱۲۰۰|۳۰۰|۸٪/.test(r.reply), 'with no stored data every statistic the model produces is removed');
  ok(sys(t.calls[0]).includes('NO REEL DATA STORED') && sys(t.calls[0]).includes('OBSERVED ACCOUNT METRICS: none stored'), 'prompt says there is no data');
  const t2 = setup(() => 'پیشنهاد: امروز یک ریل ۲۰ ثانیه‌ای از تمرین ۴ ست ۱۰ تکراری بساز.'); const r2 = await ask(t2.env, t2.store, t2.sid, 'ایده بده', EMPTY);
  ok(r2.verification.status === 'ok' && t2.calls.length === 1 && !/مبنا/.test(r2.reply), 'general ideas still work without data (no footer, no rewrite)');
}

console.log('\nJ. limits and edge cases');
{
  const body = `بازدید ${r0.views} ثبت شده. ` + 'کلمه. '.repeat(400); const t = setup(() => body); const r = await ask(t.env, t.store, t.sid, 'بنویس');
  ok(r.reply.length <= 2000 && /مبنا:/.test(r.reply) && r.reply.includes(String(r0.views)), 'long answer + basis line stay within 2000 characters');
  const t2 = setup(() => 'تو ' + '۱۲۳۴۵۶ فالوور و '.repeat(200)); const r2 = await ask(t2.env, t2.store, t2.sid, 'بنویس'); ok(r2.reply.length <= 2000 && r2.ok, 'many removals still respect the length limit');
  const t3 = setup(() => '   '); const r3 = await ask(t3.env, t3.store, t3.sid, 'سلام'); ok(r3.ok === false && r3.reason === 'EMPTY_RESPONSE', 'empty model answer is still an error');
  const t4 = setup(() => 'پاسخ'); const sid = t4.sid; await ask(t4.env, t4.store, sid, 'یک'); await ask(t4.env, t4.store, sid, 'دو'); ok((await hist(t4.store, sid)).length === 4, 'history keeps working across turns');
  ok(fetched === 0, 'no network request was made by any of this (no paid or external service)');
}

console.log('\nK. HTTP route: old contract kept, new fields added');
{
  fresh(); const calls = []; let mode = 'fake';
  const AI = { run: async (m, input) => { const a = String(input?.messages?.[0]?.content ?? '').startsWith('You are the Persian-speaking assistant'); if (!a) return { response: 'تحلیل آزمایشی' }; calls.push(input); return { response: mode === 'fake' ? FAKE_FOLLOWERS : 'پیشنهاد: ریل ۲۰ ثانیه‌ای.' }; } };
  const env = { ADMIN_KEY: KEY, ALLOW_MEMORY_STORE: '1', AI, RATE_LIMIT_PER_MIN: '100' };
  const go = async (path, body, method = 'POST') => { const r = await handle(new Request('http://x' + path, { method, headers: { 'x-admin-key': KEY }, body: body ? JSON.stringify(body) : undefined }), env, { now: NOW }); return { status: r.status, json: await r.json() }; };
  await go('/api/import', { items: seed });
  let r = await go('/api/assistant', { message: 'برنامه بده' });
  ok(r.status === 200 && r.json.ok === true && /^ses_[0-9a-f]{32}$/.test(r.json.sessionId) && typeof r.json.reply === 'string' && r.json.saved === true && r.json.hasData === true, 'old fields (ok, sessionId, reply, saved, hasData) unchanged');
  ok(r.json.verification.status === 'redacted' && !r.json.reply.includes('۵۰۰۰۰') && r.json.reply.includes(REDACTED) && r.json.source === 'ai' && r.json.dataQuality.reels === 12, 'new fields: verification, source, dataQuality; invented numbers are gone from the HTTP answer');
  const before = calls.length; r = await go('/api/assistant', { message: 'چند فالوور دارم؟' });
  ok(r.status === 200 && r.json.source === 'rules' && calls.length === before && r.json.reply.startsWith('اطلاعات کافی در دسترس نیست') && r.json.verification.status === 'not_needed', 'follower question over HTTP: answered by code, the model is not called');
  const h = await go('/api/assistant/history?sessionId=' + r.json.sessionId, null, 'GET'); ok(h.status === 200 && h.json.messages.length === 2 && !h.json.messages[1].content.includes('۵۰۰۰۰'), 'history endpoint returns the sanitised text');
  mode = 'clean'; r = await go('/api/assistant', { message: 'ایده بده' }); ok(r.json.verification.status === 'ok' && r.json.reply === 'پیشنهاد: ریل ۲۰ ثانیه‌ای.', 'a clean answer passes through exactly');
  const co = await go('/api/coach', { q: 'این هفته چه چیزی را عوض کنم؟' }); ok(co.status === 200 && typeof co.json.answer === 'string', '/api/coach is unaffected');
  const bad = await go('/api/assistant', { message: '' }); ok(bad.status === 400, 'validation is unchanged (empty message → 400)');
}

globalThis.fetch = realFetch;
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
