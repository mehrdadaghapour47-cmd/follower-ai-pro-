// Follower AI Pro: tests for the features added on top of the Growth Engine core (all with local mocks, nothing real).
import { createHmac } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { handle } from '../src/index.js';
let pass = 0, fail = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };
const KEY = 'pro-test-admin-key-0123456789', T0 = Date.parse('2026-10-11T09:00:00Z');
const base = { ADMIN_KEY: KEY, ALLOW_MEMORY_STORE: '1', TIMEZONE_OFFSET_MIN: '210' };
const call = async (path, { method = 'GET', body, key = KEY, e = base, headers = {}, now = T0 } = {}) => {
  const r = await handle(new Request('http://x' + path, { method, headers: { 'x-admin-key': key ?? '', 'content-type': 'application/json', ...headers }, body: body ? JSON.stringify(body) : undefined }), e, { now });
  const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch {} return { status: r.status, text, json, headers: r.headers };
};
const seed = JSON.parse(readFileSync(new URL('../public/seed-public-reels.json', import.meta.url))).items;
const reset = () => { globalThis.__ige_mem = undefined; };

console.log('\nA. Legacy-compatible endpoints');
reset();
for (const p of ['/api/audit', '/api/strategy', '/api/reel-ideas', '/api/plan']) ok((await call(p, { method: 'POST', body: {}, key: 'bad' })).status === 401, `${p} needs auth (old version was open to anyone)`);
let r = await call('/api/audit', { method: 'POST', body: {} });
ok(r.status === 200 && r.json.success && r.json.endpoint === 'audit' && /DATA NOT AVAILABLE/.test(r.json.result.summary), 'audit with no data: summary says DATA NOT AVAILABLE');
ok(!('score' in r.json) && !JSON.stringify(r.json).includes('85'), 'audit returns no invented profile score (old code returned a fixed 85/60)');
r = await call('/api/audit', { method: 'POST', body: { items: seed } });
ok(r.json.result.strengths.length >= 1 && r.json.result.weaknesses.length >= 1 && r.json.result.limitations.length >= 1, 'audit with 12 real public reels: strengths, weaknesses, limitations');
ok(JSON.stringify(r.json).includes('Growth Health') && /تخمینی/.test(r.json.result.summary), 'score is labelled estimated');
r = await call('/api/reel-ideas', { method: 'POST', body: {} }); ok(r.json.result.ideas.length === 5 && r.json.result.ideas.every(i => i.hook && i.cta && i.estimated_score != null), 'reel-ideas: 5 ideas with hook/cta/estimated score');
r = await call('/api/plan', { method: 'POST', body: {} }); ok(r.json.result.days.length === 7 && r.json.result.days.every(d => d.day && d.content_type && d.hook), 'plan: 7 days');
r = await call('/api/strategy', { method: 'POST', body: {} }); ok(r.json.result.hooks.length === 5 && /DATA NOT AVAILABLE/.test(r.json.result.audience), 'strategy: audience = DATA NOT AVAILABLE (not invented)');
ok((await call('/api/test/keyword?token=x&text=hi')).status === 404, 'old unauthenticated-token query endpoint is gone');

console.log('\nB. Multi-account isolation');
reset();
await call('/api/import', { method: 'POST', body: { items: seed }, headers: { 'x-account': 'clientpage' } });
const main = await call('/api/dashboard'), client = await call('/api/dashboard', { headers: { 'x-account': 'clientpage' } });
ok(main.json.status.data.media === 0 && client.json.status.data.media === 12, 'data imported for "clientpage" is invisible to "main"');
ok((await call('/api/dashboard', { headers: { 'x-account': 'bad/../name' } })).status === 400, 'invalid account name rejected');
ok((await call('/api/audit?account=clientpage', { method: 'POST', body: {} })).json.account === 'clientpage', 'account can be chosen by query string');

console.log('\nC. CORS closed by default');
let c = await call('/api/health', { key: null, headers: { origin: 'https://evil.example' } });
ok(!c.headers.get('access-control-allow-origin'), 'no CORS header for unknown origin (old default was *)');
c = await call('/api/health', { key: null, headers: { origin: 'https://app.example' }, e: { ...base, ALLOWED_ORIGINS: 'https://app.example' } });
ok(c.headers.get('access-control-allow-origin') === 'https://app.example', 'listed origin is allowed');
const pre = await handle(new Request('http://x/api/audit', { method: 'OPTIONS', headers: { origin: 'https://app.example' } }), { ...base, ALLOWED_ORIGINS: 'https://app.example' });
ok(pre.status === 204, 'preflight → 204');

console.log('\nD. Webhook (HMAC) and keyword rules');
const W = { ...base, META_APP_SECRET: 'app-secret-test', META_VERIFY_TOKEN: 'verify-token-test', KEYWORD_RULES: JSON.stringify([{ id: 'price', keywords: ['قیمت', 'price'], sendDm: true }]) };
const wh = (body, sig, e = W) => handle(new Request('http://x/webhook', { method: 'POST', headers: { 'x-hub-signature-256': sig }, body }), e, { now: T0 });
let g = await handle(new Request('http://x/webhook?hub.mode=subscribe&hub.verify_token=verify-token-test&hub.challenge=777'), W); ok((await g.text()) === '777' && g.status === 200, 'GET verify with right token → challenge');
g = await handle(new Request('http://x/webhook?hub.mode=subscribe&hub.verify_token=wrong&hub.challenge=777'), W); ok(g.status === 403, 'GET verify with wrong token → 403');
const payload = JSON.stringify({ object: 'instagram', entry: [{ changes: [{ value: { text: 'قیمت چنده؟' } }] }] });
ok((await wh(payload, 'sha256=00')).status === 401, 'POST with bad signature → 401');
ok((await wh(payload, 'sha256=' + createHmac('sha256', 'app-secret-test').update(payload).digest('hex'), { ...W, META_APP_SECRET: undefined })).status === 503, 'POST without META_APP_SECRET → 503');
g = await wh(payload, 'sha256=' + createHmac('sha256', 'app-secret-test').update(payload).digest('hex')); const gj = await g.json();
ok(g.status === 200 && gj.matched === 1 && gj.dmSent === false && !('payload' in gj), 'POST with valid signature: keyword matched, DM NOT sent, payload not echoed');
ok(!!(await globalThis.__ige_mem.list('events')).length, 'event stored');
r = await call('/api/keywords/test', { method: 'POST', body: { text: 'price please' }, e: W }); ok(r.json.matched && r.json.rule.id === 'price', 'authenticated keyword test works');

console.log('\nE. Rate limit');
reset(); let last = 0; for (let i = 0; i < 22; i++) last = (await call('/api/reel-ideas', { method: 'POST', body: {}, e: { ...base, RATE_LIMIT_PER_MIN: '20' } })).status;
ok(last === 429, '22nd AI-route call within a minute → 429');
ok((await call('/api/reel-ideas', { method: 'POST', body: {}, e: { ...base, RATE_LIMIT_PER_MIN: '20' }, now: T0 + 61000 })).status === 200, 'window resets after a minute');

console.log('\nF. Workers AI binding (mock)');
reset(); let ranWith = null;
const AIenv = { ...base, AI: { run: async (model, input) => { ranWith = { model, input }; return { response: 'خلاصه آزمایشی' }; } } };
let sys = await call('/api/system', { e: AIenv }); ok(sys.json.ai.status === 'CONNECTED' && sys.json.ai.provider === 'workers-ai', '/api/system: AI CONNECTED via Workers AI binding');
r = await call('/api/audit', { method: 'POST', body: { items: seed }, e: AIenv });
ok(r.json.ai === true && r.json.result.ai_summary === 'خلاصه آزمایشی' && ranWith.model === '@cf/meta/llama-3.1-8b-instruct', 'audit adds ai_summary separately (default model @cf/meta/llama-3.1-8b-instruct)');
ok(/Never add numbers/.test(ranWith.input.messages[0].content) && ranWith.input.max_tokens === 500, 'AI prompt forbids invented numbers; tokens capped');
ok(r.json.result.strengths.length >= 1, 'data-driven fields unchanged by AI');
reset(); r = await call('/api/audit', { method: 'POST', body: { items: seed }, e: { ...base, AI: { run: async () => { throw new Error('model offline'); } } } });
ok(r.status === 200 && r.json.ai === false && r.json.result.limitations.some(x => /AI summary failed/.test(x)), 'AI failure → audit still returned, failure listed in limitations');
r = await call('/api/coach', { method: 'POST', body: { q: 'امروز چی منتشر کنم؟' }, e: AIenv }); ok(r.json.source === 'workers-ai', 'coach uses Workers AI when bound');
sys = await call('/api/system'); ok(sys.json.ai.status === 'NOT CONNECTED', 'no AI binding and no key → NOT CONNECTED (app still works)');
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
