// Unit tests for src/integrity.js: number extraction, data quality, the allow-list of numbers, reply verification, redaction, metric questions.
// Fixtures: the project's own public/seed-public-reels.json normalised like /api/import. No AI, no network, no randomness.
import { readFileSync } from 'node:fs';
import { normDigits, numbersIn, isStatClaim, numMatch, assess, factSets, viewRatios, userNumbers, verifyReply, redact, metricAsk, REDACTED, STALE_FETCH_DAYS } from '../src/integrity.js';
import { analyzeAll, makePlan, weeklyReport, tehranDate } from '../src/planner.js';
import { coachContext } from '../src/coach.js';
let pass = 0, fail = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };

const NOW = Date.parse('2026-10-11T09:00:00Z'), DAY = 86400000;
const seed = JSON.parse(readFileSync(new URL('../public/seed-public-reels.json', import.meta.url))).items;
const n = v => (v == null || v === '' || isNaN(+v)) ? null : +v;
const norm = (it, fetchedAt = NOW) => ({ id: String(it.id), source: 'public-scrape', type: it.type || 'REEL', ts: Date.parse(it.date + 'T12:00:00Z'), hasTime: false, caption: it.caption || '', permalink: null, durationSec: n(it.durationSec), metrics: { views: n(it.views), reach: null, likes: n(it.likes), comments: n(it.comments), shares: n(it.shares), saves: n(it.saves), avgWatchSec: null, totalWatchSec: null }, fetchedAt });
const build = (media, daily = []) => { const A = analyzeAll({ media, daily, stories: [], now: NOW }); const plan = makePlan({ date: tehranDate(NOW), A, pastIdeas: [], prevPlan: null, bestHourInfo: { hour: null }, now: NOW }); const weekly = weeklyReport({ all: A.all, daily, stories: [], profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now: NOW }); return { A, plan, weekly, ctx: coachContext(A, plan, weekly) }; };
const REAL = build(seed.map(i => norm(i))), EMPTY = build([]);
const Q = assess(REAL.A, NOW), SETS = factSets(REAL.ctx, REAL.A, Q);
const r0 = REAL.ctx.lastReels[0], med = REAL.ctx.overallMedianViews, ratio0 = r0.views / med;
const check = (text, userNums = new Set(), sets = SETS) => verifyReply(text, { sets, userNums });

console.log('\nA. digits and number tokens');
{
  ok(normDigits('۱۲۳٫۵ ٠١٢ ۱٬۲۰۰') === '123.5 012 1,200', 'Persian and Arabic digits and separators are normalised');
  ok(normDigits('abc ۱۲').length === 'abc ۱۲'.length, 'normalisation is 1:1 (offsets stay valid)');
  const t = n => numbersIn(n).map(x => x.value);
  ok(JSON.stringify(t('۱۲٬۵۰۰ بازدید و 3,400 لایک')) === '[12500,3400]', 'thousands separators');
  ok(JSON.stringify(t('۱۲ هزار، 1.5k، ۲ میلیون، 3M')) === '[12000,1500,2000000,3000000]', 'هزار / k / میلیون / M multipliers');
  ok(JSON.stringify(t('10 kg و 3 min')) === '[10,3]', '"kg" and "min" are not multipliers');
  ok(numbersIn('رشد ۵٪ و ۷ درصد').every(x => x.percent), 'percent sign and the word درصد are detected');
  ok(numbersIn('۴۲').length === 1 && numbersIn('abc').length === 0 && numbersIn('').length === 0 && numbersIn(null).length === 0, 'single, none, empty and null inputs');
  const tok = numbersIn('بازدید ۱٬۲۳۴ بود')[0]; ok('بازدید ۱٬۲۳۴ بود'.slice(tok.start, tok.end) === '۱٬۲۳۴', 'start/end offsets point at the original text');
}

console.log('\nB. which numbers count as statistic claims');
{
  const stat = s => { const t = normDigits(s); return numbersIn(s).map(k => isStatClaim(t, k)); };
  for (const s of ['۱۲ هزار فالوور', 'رشد ۵٪', '۳ درصد', '۱٬۲۳۴ بازدید', '۲٫۳ برابر میانه', '۵۰۰۰ نفر', '۱۸۰ لایک', 'نرخ تعامل ۴', '۴۰ ریل منتشر کردی', 'reach 340', '12k'])
    ok(stat(s).includes(true), `claim: "${s}"`);
  for (const s of ['۳ ریل بساز و منتشر کن', '۱) ریل ۲۰ ثانیه‌ای ۲) ریل دوم؛ منتشر کن', 'ساعت 20:45 منتشر کن', 'تاریخ 2026-10-11', 'در ۱۴۰۵/۰۷/۱۹', '۳ ست ۱۰ تکرار', 'ریل ۱۵ ثانیه‌ای', 'هوک ۳ ثانیه‌ای', '۳ ایده بده', '1) هوک 2) کپشن', 'در سال ۲۰۲۶', 'وزنه 10 kg', '۴ روز در هفته'])
    ok(stat(s).every(x => x === false), `not a claim: "${s}"`);
}

console.log('\nC. rounding rules');
{
  const m = (s, f) => numMatch(numbersIn(s)[0], f);
  ok(m('1.2k', 1234) && m('۱٫۲ هزار', 1234) && !m('1.2k', 1400), 'k/هزار claims match at the precision written');
  ok(m('12 هزار', 12345) && !m('12 هزار', 13000), '"12 هزار" ↔ 12 345 but not 13 000');
  ok(m('12%', 12.4) && !m('12%', 13) && m('12.3%', 12.34), 'percent claims match at the precision written');
  ok(m('4488', 4488) && !m('4488', 4489), 'plain integers must match exactly (no silent rounding)');
}

console.log('\nD. data quality (assess)');
{
  ok(Q.hasData && Q.reels === 12 && Q.newestPostDate === '2026-10-07' && Q.fetchAgeDays === 0 && !Q.stale, 'real fixture: 12 reels, newest post 2026-10-07, fetched today, not stale');
  ok(Q.sufficientForPatterns === true && Q.sufficientForDiagnosis === (REAL.A.health.score != null) && Q.sources.join() === 'public-scrape', 'sufficiency flags and source list');
  ok(['followers', 'reach', 'post-times', 'stories', 'watch-time'].every(k => Q.missing.includes(k)) && Q.followersKnown === false, 'public-only data: followers, reach, post times, stories and watch time are reported as NOT stored');
  const E = assess(EMPTY.A, NOW); ok(E.hasData === false && E.reels === 0 && E.newestPostDate === null && E.fetchAgeDays === null && E.stale === false && E.sufficientForPatterns === false, 'no data: hasData=false, no dates, not "stale" (unknown is not stale)');
  const old = assess(build(seed.map(i => norm(i, NOW - 10 * DAY))).A, NOW); ok(old.fetchAgeDays === 10 && old.stale === true && STALE_FETCH_DAYS === 7, 'data fetched 10 days ago → stale (limit 7 days)');
  const edge = assess(build(seed.map(i => norm(i, NOW - 7 * DAY))).A, NOW); ok(edge.fetchAgeDays === 7 && edge.stale === false, 'exactly 7 days is not yet stale');
  const few = assess(build(seed.slice(0, 3).map(i => norm(i))).A, NOW); ok(few.reels === 3 && few.sufficientForPatterns === false, 'fewer than 8 reels → not sufficient for pattern claims');
  const daily = Array.from({ length: 10 }, (_, i) => ({ date: new Date(NOW - (9 - i) * DAY).toISOString().slice(0, 10), followers: 5000 + i * 10, reach: 1000, views: 2000, interactions: 100, shares: 5, saves: 9, comments: 4, profileViews: 300, follows: 12 }));
  const D = build(seed.map(i => norm(i)), daily); const dq = assess(D.A, NOW);
  ok(dq.followersKnown === true && !dq.missing.includes('followers') && !dq.missing.includes('reach'), 'with daily snapshots followers and reach are known');
  ok(JSON.stringify(assess({}, NOW).reels) === '0' && assess(undefined, NOW).hasData === false, 'malformed input does not throw');
}

console.log('\nE. the allow-list of numbers (factSets)');
{
  ok(SETS.fact.has(r0.views) && SETS.fact.has(r0.likes) && SETS.fact.has(r0.comments) && SETS.fact.has(med), 'stored reel metrics and the median are facts');
  ok(SETS.fact.has(Q.reels) && SETS.fact.has(REAL.A.pat.n), 'the reel count is a fact');
  const tt = REAL.ctx.todayTop.map(i => i.score); // coachContext already flattens score to a number ok(tt.every(v => SETS.estimate.has(v)), 'planner idea scores are ESTIMATES');
  ok(tt.length > 0 && tt.every(v => Number.isFinite(v)) && SETS.estimate.size >= 1, 'coachContext gives plain numeric idea scores and the estimate set is non-empty');
  const durs = REAL.ctx.todayTop.map(i => i.dur).filter(d => !SETS.fact.has(d)); ok(durs.every(d => !SETS.estimate.has(d)), 'suggested durations are neither facts nor estimates');
  const ids = viewRatios(REAL.ctx); ok(ids.length > 0 && ids.every(x => SETS.ratio.has(x.ratio) && SETS.fact.has(x.ratio)) && Math.abs(ids[0].ratio - ratio0) < 1e-12, 'views ÷ median ratios are computed by code and allowed');
  ok(SETS.pct.has(REAL.ctx.health.coverage) && [...SETS.pct].some(v => Math.abs(v - ratio0 * 100) < 1e-9), 'percent set: health coverage and ratios × 100');
  ok(![...SETS.pct].some(v => v === 7) || REAL.ctx.health.coverage === 7, 'an unrelated "7" (as in "7 days") is not an allowed percentage');
  const proxyCtx = { ...REAL.ctx, problems: [{ id: 'x', title: 't', evidence: 'نرخ تعامل x0.61 (reel-level proxy)' }] }; const ps = factSets(proxyCtx, REAL.A, Q); ok(ps.estimate.has(0.61) && !ps.fact.has(0.61), 'a "(reel-level proxy)" evidence number is an ESTIMATE, not a fact');
  const fl = build(seed.map(i => norm(i)), Array.from({ length: 10 }, (_, i) => ({ date: new Date(NOW - (9 - i) * DAY).toISOString().slice(0, 10), followers: 5000 + i * 10, reach: 1000, views: 2000, interactions: 100, shares: 5, saves: 9, comments: 4, profileViews: 300, follows: 12 })));
  const fs = factSets(fl.ctx, fl.A, assess(fl.A, NOW)); ok(fs.fact.has(5090), 'a stored follower count becomes a fact');
  ok(factSets(undefined, undefined, undefined).fact.size === 0, 'no input → empty sets, no exception');
  ok(userNumbers(['من ۱۰۰۰۰ فالوور دارم', 'و ۵٪ رشد']).has(10000) && userNumbers(['من ۱۰۰۰۰ فالوور دارم', 'و ۵٪ رشد']).has(5), 'user-provided numbers are collected separately');
}

console.log('\nF. verification: real numbers pass');
{
  const valid = [
    `آخرین ریل ${r0.views} بازدید گرفت؛ میانه‌ی بازدیدها ${Math.round(med)} است.`,
    `داده واقعی: آخرین ریل ${r0.views} بازدید، ${r0.likes} لایک و ${r0.comments} کامنت دارد.`,
    `بازدید آخرین ریل حدود ${ratio0.toFixed(1)} برابر میانه است.`, `بازدید آخرین ریل حدود ${Math.round(ratio0)} برابر میانه است.`,
    `بازدید آخرین ریل ${Math.round(ratio0 * 100)}٪ میانه است.`, `از ${Q.reels} ریل ذخیره‌شده، آخرین ریل بالاتر از میانه است.`,
    `بازدید ${Math.round(r0.views / 1000 * 10) / 10} هزار تا ثبت شده.`, normDigits(`بازدید ${r0.views}`).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]) + ' ثبت شده است.',
    `پوشش داده ${REAL.ctx.health.coverage}٪ است.`, `${REAL.ctx.problems[0] ? REAL.ctx.problems[0].evidence : 'مشکلی نیست'}`,
  ];
  valid.forEach((t, i) => { const v = check(t); ok(v.ok, `valid reply #${i + 1} accepted`, v.violations.map(x => x.token).join()); });
  const ideas = ['۳ ایده بده: ۱) هوک ۲) کپشن ۳) CTA.', 'یک ریل ۲۰ ثانیه‌ای با هوک ۳ ثانیه‌ای بساز و ساعت ۲۰:۴۵ منتشر کن.', 'تمرین: ۴ ست ۱۰ تکراری، ۶۰ ثانیه استراحت.', 'تاریخ انتشار 2026-10-12 در سال ۲۰۲۶.'];
  ideas.forEach((t, i) => ok(check(t).ok && check(t).checked === 0, `suggestion text #${i + 1}: accepted and nothing was even treated as a statistic`));
  const est = `تخمین: امتیاز ایده‌ی امروز ${REAL.ctx.todayTop[0].score} است.`; ok(check(est).ok, 'an estimate number is accepted when the sentence says it is an estimate');
}

console.log('\nG. verification: invented numbers are caught');
{
  const fake = ['تو ۵۰۰۰۰ فالوور داری.', 'نرخ تعامل پیج تو ۸٫۵٪ است.', 'ریچ هفتگی ۱۲۰ هزار بود.', 'آخرین ریل ۹۹۹۹۹ بازدید گرفت.', 'حدود ۳۰۰۰ فالوور جدید در ماه گرفتی.', 'میانگین لایک‌ها ۴۵۰ است.', 'نرخ ذخیره ۳٫۲٪ از ریچ است.', '۴۰ ریل منتشر کردی.', 'رشد فالوور ۷ درصد شد.', 'حدود ۲۰۰۰ نفر استوری را دیدند.', 'رشد ۱۲ درصد داشتی.', 'نرخ تعامل ۴ درصد است.', 'فالوورها ۲۵٪ بیشتر شدند.', 'You have 12k followers.', 'Your reach is 1,200,000.', 'engagement rate is 6.5%', 'تعداد ویو 2.5 میلیون است.'];
  fake.forEach((t, i) => { const v = check(t); ok(!v.ok && v.violations[0].type === 'unverified', `invented #${i + 1} blocked: ${t}`); });
  ok(!check(`آخرین ریل ${r0.views + 1} بازدید گرفت.`).ok, 'a real number off by one is not accepted');
  ok(!check('۱۲ هزار فالوور').ok && !check('۱۲٬۰۰۰ فالوور').ok && !check('١٢٠٠٠ فالوور').ok, 'the same invented number in other notations is caught too');
  const v = check('تو ۵۰۰۰۰ فالوور داری و ۴۰ ریل منتشر کردی و رشد ۱۲٪ است.'); ok(v.violations.length === 3, 'all invented numbers in one reply are reported');
  const none = check(`با ${Q.reels} ریل ثبت‌شده شروع کن.`); ok(none.ok, 'counts of stored items are fine');
}

console.log('\nH. numbers from the user, from earlier turns and from estimates');
{
  const U = userNumbers(['من ۱۰۰۰۰ فالوور دارم']);
  let v = check('تو ۱۰۰۰۰ فالوور داری.', U); ok(!v.ok && v.violations[0].type === 'user_number_as_fact', "the user's number is NOT accepted as a fact");
  for (const s of ['طبق گفته‌ی تو ۱۰۰۰۰ فالوور داری.', 'تو گفتی ۱۰۰۰۰ فالوور داری.', 'اگر ۱۰۰۰۰ فالوور داشته باشی، می‌توانی شروع کنی.', 'عددی که تو نوشتی (۱۰۰۰۰ فالوور) تأیید نشده است.', 'You said 10,000 followers.']) { v = check(s, U); ok(v.ok, `quoted as the user's claim → accepted: ${s}`); }
  ok(!check('تو ۱۰۰۰۰ فالوور داری.', new Set()).ok && check('تو ۱۰۰۰۰ فالوور داری.', new Set()).violations[0].type === 'unverified', 'without the user having said it, the same sentence is simply unverified');
  const earlier = check('پیش‌تر گفتم ۵۰۰۰۰ فالوور داری.'); ok(!earlier.ok, 'a number that only appeared in an earlier ASSISTANT turn is not trusted (nothing carries over unless the data has it)');
  const real = REAL.ctx.todayTop[0].score, noMark = check(`این ایده ${real} بازدید می‌گیرد.`); ok(!noMark.ok && noMark.violations[0].type === 'estimate_as_fact', 'an idea score presented as a result is blocked');
  ok(check(`برآورد: امتیاز ${real} برای این ایده.`).ok && check(`تخمینی ${real} بازدید.`).ok, 'the same number is fine when it is labelled as an estimate');
  const coincide = new Set([4488]); ok(check('آخرین ریل ۴۴۸۸ بازدید.', new Set([4488]), { fact: new Set(), estimate: new Set(), ratio: new Set(), pct: new Set() }).ok === false, 'a user number that equals nothing in the data does not become a fact because the user repeats it');
}

console.log('\nI. redaction');
{
  const t = 'تو ۵۰۰۰۰ فالوور داری و آخرین ریل ' + r0.views + ' بازدید گرفت و رشد ۱۲٪ است.'; const v = check(t); const out = redact(t, v.violations);
  ok(v.violations.length === 2 && !out.includes('۵۰۰۰۰') && !out.includes('۱۲٪') && out.includes(String(r0.views)) && out.split(REDACTED).length - 1 === 2, 'only the unverifiable numbers are replaced; real ones stay');
  ok(out.startsWith('تو ' + REDACTED + ' فالوور داری') && out.endsWith('است.'), 'the rest of the sentence is untouched');
  ok(redact('سلام', []) === 'سلام' && check(redact(t, v.violations)).ok, 'no violations → unchanged; and the redacted text passes verification');
  const k = 'تو 12k فالوور داری و 3,400 لایک'; ok(!redact(k, check(k).violations).match(/12k|3,400/), 'Latin digits, k and separators are removed completely');
}

console.log('\nJ. questions about metrics');
{
  const a = m => metricAsk(m).join();
  ok(a('چند فالوور دارم؟') === 'followers' && a('تعداد فالوورهام چقدره') === 'followers' && a('how many followers do I have') === 'followers', 'follower count questions');
  ok(a('ریچ پیجم چقدر است') === 'reach' && a('what is my reach') === 'reach' && a('بازدید پروفایل چند تاست') === 'reach', 'reach / impressions / profile-visit questions');
  ok(a('من ۱۰۰۰۰ فالوور دارم درسته؟') === 'followers' && a('فالوورم ۸۰۰۰ شده، تأیید کن') === 'followers', 'asking to confirm a number counts');
  ok(a('من ۱۰۰۰۰ فالوور دارم، یک ایده ریل بده') === '' && a('با ۵۰۰۰ فالوور چه محتوایی بسازم') === '', 'a user number inside a request for ideas does not turn it into a metric lookup')
  ok(a('چطور فالوورم را بالا ببرم؟') === '' && a('چرا رشد نمی‌کنم') === '' && a('یک کپشن بنویس') === '' && a('') === '', 'advice / diagnosis / ideas are NOT metric lookups (they go to the model)');
  ok(a('فالوور و ریچ پیجم چقدره؟') === 'followers,reach', 'both at once');
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
