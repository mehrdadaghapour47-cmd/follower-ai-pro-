// Tests for runChat() in src/ai.js (multi-turn chat). Local mocks only: no real Cloudflare, no network.
import { runChat, runAI, runAIJson, extractJson, validateCoach, aiProvider, AI_DEFAULT_MODEL, CHAT_MAX_MESSAGES, CHAT_MAX_MESSAGE_CHARS, CHAT_MAX_TOKENS } from '../src/ai.js';
let pass = 0, fail = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };

// mock Workers AI binding that records every call
const mkEnv = (impl, extra = {}) => { const calls = []; const AI = { run: async (model, input) => { calls.push({ model, input }); return impl ? impl(model, input) : { response: 'پاسخ آزمایشی' }; } }; return { env: { AI, ...extra }, calls }; };
const H = [{ role: 'user', content: 'سلام' }, { role: 'assistant', content: 'سلام! چه کمکی می‌خوای؟' }, { role: 'user', content: 'ایده ریل بده' }];
const SYS = 'You are a Persian Instagram coach. Never invent numbers.';

console.log('\nA. connection and sending');
{
  const env0 = {}; const r0 = await runChat(env0, { system: SYS, messages: H });
  ok(r0.ok === false && r0.reason === 'NOT_CONNECTED' && !('text' in r0), 'no AI binding → NOT_CONNECTED, no text');
  const { env, calls } = mkEnv();
  const r = await runChat(env, { system: SYS, messages: H });
  ok(r.ok === true && r.text === 'پاسخ آزمایشی' && r.provider === 'workers-ai' && r.model === AI_DEFAULT_MODEL, 'valid call returns text, provider and default model');
  ok(calls.length === 1, 'exactly one model call (no hidden retry)');
  const sent = calls[0].input.messages;
  ok(sent.length === 4 && sent[0].role === 'system' && sent[0].content === SYS, 'first message is the system prompt');
  ok(JSON.stringify(sent.slice(1)) === JSON.stringify(H), 'history is sent in order with roles and content intact');
  ok(calls[0].input.max_tokens === 700, 'default max_tokens = 700');
  const e2 = mkEnv(null, { AI_MODEL: '@cf/test/model' }); await runChat(e2.env, { system: SYS, messages: H });
  ok(e2.calls[0].model === '@cf/test/model', 'AI_MODEL variable overrides the default model');
  const frozen = Object.freeze(H.map(m => Object.freeze({ ...m }))); const e3 = mkEnv();
  const r3 = await runChat(e3.env, { system: SYS, messages: frozen });
  ok(r3.ok === true, 'frozen (immutable) input accepted: input is not mutated');
  const e4 = mkEnv(); await runChat(e4.env, { system: '  ' + SYS + '\n', messages: [{ role: 'user', content: '  سلام\u0000  ' }] });
  ok(e4.calls[0].input.messages[0].content === SYS && e4.calls[0].input.messages[1].content === 'سلام', 'system/content are trimmed and NUL characters removed');
}

console.log('\nB. maxTokens');
{
  const a = mkEnv(); await runChat(a.env, { system: SYS, messages: H, maxTokens: 123 });
  ok(a.calls[0].input.max_tokens === 123, 'maxTokens=123 is passed as max_tokens');
  const b = mkEnv(); await runChat(b.env, { system: SYS, messages: H, maxTokens: 999999 });
  ok(b.calls[0].input.max_tokens === CHAT_MAX_TOKENS && CHAT_MAX_TOKENS === 2000, 'huge maxTokens is capped at 2000');
  for (const bad of [0, -5, 1.5, '50', NaN, null, Infinity]) {
    const c = mkEnv(); const r = await runChat(c.env, { system: SYS, messages: H, maxTokens: bad });
    ok(r.ok === false && /^INVALID_INPUT/.test(r.reason) && c.calls.length === 0, `maxTokens=${String(bad)} rejected before calling the model`);
  }
}

console.log('\nC. empty or invalid model replies (never invent an answer)');
for (const [name, val] of [['empty string', { response: '' }], ['whitespace only', { response: '  \n ' }], ['null reply', null], ['empty object', {}], ['response is an object', { response: { a: 1 } }], ['response is a number', { response: 123 }], ['undefined', undefined]]) {
  const { env } = mkEnv(() => val); const r = await runChat(env, { system: SYS, messages: H });
  ok(r.ok === false && r.reason === 'EMPTY_RESPONSE' && !('text' in r), `${name} → EMPTY_RESPONSE, no text`);
}
{
  const a = mkEnv(() => 'متن خام'); ok((await runChat(a.env, { system: SYS, messages: H })).text === 'متن خام', 'plain string reply is accepted');
  const b = mkEnv(() => ({ result: { response: 'از result' } })); ok((await runChat(b.env, { system: SYS, messages: H })).text === 'از result', 'result.response shape is accepted');
  const c = mkEnv(() => ({ response: '  trimmed  ' })); ok((await runChat(c.env, { system: SYS, messages: H })).text === 'trimmed', 'reply text is trimmed');
}

console.log('\nD. AI errors');
{
  const { env, calls } = mkEnv(() => { throw new Error('model offline'); });
  const r = await runChat(env, { system: SYS, messages: H });
  ok(r.ok === false && /model offline/.test(r.reason) && !('text' in r), 'thrown error → ok:false with reason, no fake answer');
  ok(calls.length === 1, 'no retry after an error');
  const e2 = mkEnv(() => { throw new Error('x'.repeat(500)); }); const r2 = await runChat(e2.env, { system: SYS, messages: H });
  ok(r2.reason.length <= 200, 'error reason is capped at 200 characters');
  const e3 = mkEnv(() => { throw 'plain string failure'; }); const r3 = await runChat(e3.env, { system: SYS, messages: H });
  ok(r3.ok === false && r3.reason === 'plain string failure', 'non-Error throw is handled');
  const e4 = mkEnv(() => { throw { message: 'boom', token: 'TOPSECRET' }; });
  const r4 = await runChat(e4.env, { system: SYS, messages: H }); ok(!JSON.stringify(r4).includes('TOPSECRET'), 'only the error message is returned, not other fields');
}

console.log('\nE. invalid input (model is never called)');
{
  const long = 'ا'.repeat(CHAT_MAX_MESSAGE_CHARS + 1), many = Array.from({ length: CHAT_MAX_MESSAGES + 1 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'm' + i }));
  const cases = [
    ['messages missing', { system: SYS }], ['messages not an array', { system: SYS, messages: 'hi' }], ['messages empty', { system: SYS, messages: [] }],
    ['too many messages', { system: SYS, messages: many }], ['null element', { system: SYS, messages: [null] }], ['string element', { system: SYS, messages: ['hi'] }],
    ['role system inside history', { system: SYS, messages: [{ role: 'system', content: 'x' }, { role: 'user', content: 'y' }] }],
    ['role tool', { system: SYS, messages: [{ role: 'tool', content: 'x' }] }], ['role missing', { system: SYS, messages: [{ content: 'x' }] }],
    ['content missing', { system: SYS, messages: [{ role: 'user' }] }], ['content not a string', { system: SYS, messages: [{ role: 'user', content: 42 }] }],
    ['content whitespace only', { system: SYS, messages: [{ role: 'user', content: '   ' }] }], ['content too long', { system: SYS, messages: [{ role: 'user', content: long }] }],
    ['last message from assistant', { system: SYS, messages: [{ role: 'user', content: 'a' }, { role: 'assistant', content: 'b' }] }],
    ['system missing', { messages: H }], ['system blank', { system: '   ', messages: H }], ['system not a string', { system: 5, messages: H }],
    ['system too long', { system: 'x'.repeat(8001), messages: H }],
  ];
  for (const [name, args] of cases) { const { env, calls } = mkEnv(); const r = await runChat(env, args); ok(r.ok === false && /^INVALID_INPUT/.test(r.reason) && calls.length === 0 && !('text' in r), `${name} → INVALID_INPUT`); }
  const { env, calls } = mkEnv(); const r = await runChat(env); ok(r.ok === false && /^INVALID_INPUT/.test(r.reason) && calls.length === 0, 'called with no options object → INVALID_INPUT');
  const ok1 = mkEnv(); const exact = await runChat(ok1.env, { system: SYS, messages: [{ role: 'user', content: 'ا'.repeat(CHAT_MAX_MESSAGE_CHARS) }] });
  ok(exact.ok === true, 'message of exactly the maximum length is accepted');
  const ok2 = mkEnv(); const maxN = Array.from({ length: CHAT_MAX_MESSAGES }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'm' + i })); maxN[maxN.length - 1].role = 'user';
  ok((await runChat(ok2.env, { system: SYS, messages: maxN })).ok === true, 'exactly the maximum number of messages is accepted');
}

console.log('\nF. no paid API is ever used');
{
  let fetched = 0; const realFetch = globalThis.fetch; globalThis.fetch = async () => { fetched++; return new Response('{}'); };
  const r = await runChat({ ANTHROPIC_API_KEY: 'sk-test-not-real' }, { system: SYS, messages: H });
  ok(r.ok === false && /^UNSUPPORTED_PROVIDER/.test(r.reason) && fetched === 0, 'Anthropic-only env → UNSUPPORTED_PROVIDER, no network request');
  const r2 = await runChat({ AI_PROVIDER: 'anthropic', ANTHROPIC_API_KEY: 'sk-test-not-real', AI: { run: async () => ({ response: 'x' }) } }, { system: SYS, messages: H });
  ok(r2.ok === false && /^UNSUPPORTED_PROVIDER/.test(r2.reason) && fetched === 0, 'AI_PROVIDER=anthropic → UNSUPPORTED_PROVIDER, no network request');
  globalThis.fetch = realFetch;
}

console.log('\nG. existing behaviour is unchanged');
{
  const { env, calls } = mkEnv(() => ({ response: 'پاسخ' }));
  const r = await runAI(env, { system: 'S', user: 'U', maxTokens: 321 });
  ok(r.ok === true && r.text === 'پاسخ' && r.provider === 'workers-ai' && r.model === AI_DEFAULT_MODEL, 'runAI: same result shape as before');
  ok(JSON.stringify(calls[0].input) === JSON.stringify({ messages: [{ role: 'system', content: 'S' }, { role: 'user', content: 'U' }], max_tokens: 321 }), 'runAI: exact same payload sent to the model as before');
  ok((await runAI({}, { system: 'S', user: 'U' })).reason === 'NOT_CONNECTED', 'runAI: NOT_CONNECTED without a provider');
  const j = mkEnv(() => ({ response: '{"answer":"سلام","actions":["الف"],"missing_data":[]}' }));
  const rj = await runAIJson(j.env, { system: 'S', user: 'U' }, validateCoach);
  ok(rj.ok === true && rj.structured === true && rj.data.answer === 'سلام' && j.calls.length === 1, 'runAIJson: structured parse works, single call');
  const jr = mkEnv((m, i) => ({ response: i.messages[1].content.includes('previous reply was not valid JSON') ? '{"answer":"دوم"}' : 'not json' }));
  const rr = await runAIJson(jr.env, { system: 'S', user: 'U' }, validateCoach);
  ok(rr.structured === true && rr.retried === true && jr.calls.length === 2, 'runAIJson: retry-once behaviour unchanged');
  ok(JSON.stringify(extractJson('x {"a":1} y')) === '{"a":1}' && aiProvider({ AI: { run() {} } }) === 'workers-ai' && aiProvider({}) === null, 'extractJson and aiProvider unchanged');
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
