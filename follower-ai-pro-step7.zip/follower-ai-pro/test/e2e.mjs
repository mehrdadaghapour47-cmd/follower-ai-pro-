// End-to-end test. Instagram Graph API is replaced by a LOCAL MOCK (clearly synthetic) – nothing here touches real Instagram.
import { readFileSync } from 'node:fs';
import { handle, keyProblems, refreshToken } from '../src/index.js';
import { analyzeAll, makePlan, TEMPLATES } from '../src/planner.js';
import { DNA } from '../src/analysis.js';

let pass = 0, fail = 0;
const ok = (c, name, extra = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + name + (c ? '' : '  ' + extra)); };
const KEY = 'test-admin-key-0123456789';
const SECRET_TOKEN = 'FAKE_TEST_TOKEN_NOT_REAL_123456789';
const env = { ADMIN_KEY: KEY, TOKEN_ENC_KEY: Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64'), TIMEZONE_OFFSET_MIN: '210', ALLOW_MEMORY_STORE: '1' };
const T0 = Date.parse('2026-10-08T09:00:00Z'), DAY = 86400000;
const call = async (path, { method = 'GET', body, key = KEY, now = T0, fetchFn, e = env } = {}) => {
  const r = await handle(new Request('http://x' + path, { method, headers: { 'x-admin-key': key ?? '', 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined }), e, { now, fetchFn });
  const text = await r.text(); return { status: r.status, text, json: JSON.parse(text) };
};

// ---- LOCAL MOCK of graph.instagram.com (synthetic, test only) ----
const mockReels = Array.from({ length: 14 }, (_, i) => ({ id: '9000' + i, sc: i < 3 ? ['DeM3ze3hKxJ', 'DeAB3GdhFZB', 'Dd9bJLlhoCZ'][i] : 'MOCK' + i, daysAgo: i * 1.5 + 0.2, views: i < 3 ? 6000 - i * 500 : 3000 + i * 40, wr: 9 }));
function graph(urlStr) {
  const u = new URL(urlStr), p = u.pathname.replace(/^\/v\d+\.0\//, ''), q = u.searchParams;
  if (q.get('access_token') !== SECRET_TOKEN) return [400, { error: { message: 'Invalid OAuth access token', code: 190 } }];
  const R = (data) => [200, { data }];
  if (p === 'refresh_access_token' || p === '/refresh_access_token') return [200, { access_token: SECRET_TOKEN, token_type: 'bearer', expires_in: 5184000 }];
  if (p === 'me' || p === '1784') return [200, { id: '1784', username: 'mock_user', followers_count: 2200, follows_count: 700, media_count: 54 }];
  if (p === '1784/media') return R(mockReels.map(r => ({ id: r.id, caption: 'کپشن آزمایشی ' + r.id, media_type: 'VIDEO', media_product_type: 'REELS', timestamp: new Date(T0 - r.daysAgo * DAY).toISOString(), like_count: 100, comments_count: 20, permalink: `https://www.instagram.com/reel/${r.sc}/` })));
  if (p === '1784/stories') return R([{ id: 'st1', timestamp: new Date(T0 - 3600e3).toISOString(), media_type: 'IMAGE', permalink: 'https://x/s1' }]);
  if (p === '1784/insights') {
    const names = q.get('metric').split(',');
    if (names.includes('follows_and_unfollows') && names.length > 1) return [400, { error: { message: '(#10) Permission denied for follows_and_unfollows', code: 10 } }];
    if (names[0] === 'follows_and_unfollows') return [400, { error: { message: '(#10) Permission denied', code: 10 } }];
    const v = { reach: 900, views: 2500, profile_views: 120, accounts_engaged: 80, total_interactions: 150, likes: 100, comments: 20, shares: 15, saves: 25 }[names[0]];
    return R([{ name: names[0], total_value: { value: v } }]);
  }
  if (p.endsWith('/insights')) {
    const id = p.split('/')[0], names = q.get('metric').split(',');
    const r = mockReels.find(x => x.id === id);
    if (id === 'st1') return R(names.map(n => ({ name: n, total_value: { value: { reach: 60, views: 70, replies: 3, shares: 1, total_interactions: 4 }[n] } })));
    const val = { reach: r.views * 0.8, views: r.views, likes: 100, comments: 20, shares: 12, saved: 30, total_interactions: 162, ig_reels_avg_watch_time: r.wr * 1000, ig_reels_video_view_total_time: r.views * 9000 };
    return R(names.map(n => ({ name: n, total_value: { value: val[n] } })));
  }
  return [404, { error: { message: 'not found', code: 100 } }];
}
const mockFetch = async (url, opts) => {
  if (String(url).startsWith('https://api.anthropic.com')) return new Response(JSON.stringify({ content: [{ type: 'text', text: 'پاسخ آزمایشی Claude' }] }), { status: 200 });
  const [s, b] = graph(String(url)); return new Response(JSON.stringify(b), { status: s });
};

console.log('\n1. Security');
ok((await call('/api/status', { key: 'wrong' })).status === 401, 'wrong admin key → 401');
ok((await call('/api/status', { e: { ...env, ADMIN_KEY: undefined } })).status === 503, 'no ADMIN_KEY configured → 503 (secure by default)');
ok((await call('/api/health', { key: null })).status === 200, '/api/health is public');

ok((await call('/api/status', { e: { ...env, ADMIN_KEY: 'short' } })).status === 503, 'ADMIN_KEY shorter than 16 chars → 503');
ok((await call('/api/dashboard', { e: { ADMIN_KEY: KEY } })).status === 503, 'no D1 binding and no test flag → 503 D1 NOT CONFIGURED (no silent memory fallback)');
let h = await call('/api/health', { key: null });
ok(h.json.worker === 'OK' && h.json.d1 && !h.text.includes(KEY), '/api/health reports worker + d1, leaks nothing');
let sy = await call('/api/system');
ok(sy.json.worker === 'OK' && sy.json.instagram.status === 'NOT CONNECTED' && sy.json.instagram.data === DNA, '/api/system: Instagram NOT CONNECTED + DATA NOT AVAILABLE');
ok(sy.json.ai.status === 'NOT CONNECTED', '/api/system: AI NOT CONNECTED without key');
ok(sy.json.secrets.TOKEN_ENC_KEY === 'SET (valid)' && !sy.text.includes(env.TOKEN_ENC_KEY) && !sy.text.includes(KEY), '/api/system shows secret STATE only, never values');
ok((await call('/api/system', { key: 'nope' })).status === 401, '/api/system requires admin key');
// fake D1 to verify OK / missing-table paths
const fakeDB = ok2 => ({ prepare: sql => ({ bind() { return this; }, first: async () => { if (!ok2) throw new Error('no such table: records'); return sql.startsWith('SELECT 1') ? { 1: 1 } : null; } }) });
ok((await call('/api/system', { e: { ...env, ALLOW_MEMORY_STORE: undefined, DB: fakeDB(true) } })).json.d1.status === 'OK', 'D1 OK detected');
const bad = await call('/api/system', { e: { ...env, ALLOW_MEMORY_STORE: undefined, DB: fakeDB(false) } });
ok(bad.json.d1.status === 'ERROR' && /schema\.sql/.test(bad.json.d1.detail), 'missing table → ERROR with "run schema.sql"');

console.log('\n2. Empty system: no fake data');
let r = await call('/api/dashboard');
ok(r.status === 200, 'dashboard loads with zero data', r.text.slice(0, 200));
ok(r.json.growthHealth.score === null, 'Growth Health = null (DATA NOT AVAILABLE) with no data');
ok(r.json.followerGrowth.followers === DNA, 'followers = DATA NOT AVAILABLE');
ok(r.json.status.instagram.connected === false && r.json.system.instagram.status === 'NOT CONNECTED', 'status: Instagram NOT connected');
ok(r.json.status.instagram.requiredPermissions.length >= 2, 'status lists required permissions');
ok(r.json.todaysReels.length === 5 && r.json.todaysStories.length >= 5, 'still produces 5 reels + 5-8 stories for today');

console.log('\n3. Real public data import (seed from @mehrdad_mokamel.fit)');
const seed = JSON.parse(readFileSync(new URL('../public/seed-public-reels.json', import.meta.url)));
r = await call('/api/import', { method: 'POST', body: { items: seed.items } });
ok(r.json.imported === 12, 'imported 12 public reels', r.text);
r = await call('/api/plan/regenerate', { method: 'POST' });
r = await call('/api/dashboard');
const d = r.json;
ok(d.growthHealth.score !== null && d.growthHealth.coverage < 70, `partial Growth Health computed (${d.growthHealth.score}, coverage ${d.growthHealth.coverage}%)`);
ok(d.growthHealth.components.some(c => c.detail === DNA), 'unmeasurable components say DATA NOT AVAILABLE');
ok(d.stuck.notEvaluable.length >= 3, `stuck detector refuses to guess (${d.stuck.notEvaluable.length} rules not evaluable)`);
ok(d.stuck.problems.some(p => p.id === 'too_similar' || p.id === 'cta_weak' || p.id === 'topic_repeated'), 'detects real problems from public captions: ' + d.stuck.problems.map(p => p.id).join(','));
ok(d.bestContent[0].id === 'DbWHcvYoM9Z', 'best content = the 40K reel');
ok(d.patterns.n === 12, 'patterns computed from 12 reels');
ok(d.todaysReels.every(i => ['PRIORITY', 'STRONG', 'TEST', 'REWORK'].includes(i.score.tier)), 'every idea has a tier');
ok(d.todaysReels.every(i => i.hook && i.scenario && i.onCamera && i.overlay && i.dur && i.cta && i.caption && i.goal && i.score.viralEstimate != null && i.score.followEstimate != null), 'every reel idea has all 11 required fields');
ok(d.todaysReels.every(i => i.score.maxSimilarity < 50), 'no idea is similar to existing captions');
ok(d.mission.steps.length === 7 && d.mission.timeSource.startsWith('default'), 'TODAY\'S MISSION has 7 steps; times flagged as default (no post-time data)');
ok(d.weekly.bestPostingTime.includes(DNA), 'best posting time = DATA NOT AVAILABLE (public data has no time)');

console.log('\n4. Token: connect, encryption, never leaked');
r = await call('/api/token', { method: 'POST', body: { token: 'bad' }, fetchFn: mockFetch });
ok(r.status === 400, 'invalid token rejected (not stored)');
r = await call('/api/token', { method: 'POST', body: { token: SECRET_TOKEN }, fetchFn: mockFetch });
ok(r.json.ok && !r.text.includes(SECRET_TOKEN), 'valid token accepted; response has no token');
const stored = await globalThis.__ige_mem.get('kv', 'token');
ok(stored && !JSON.stringify(stored).includes(SECRET_TOKEN), 'token stored ENCRYPTED (ciphertext only)');

console.log('\n5. Sync against MOCK Instagram API');
r = await call('/api/sync', { method: 'POST', fetchFn: mockFetch });
ok(r.json.ok && r.json.media === 14 && r.json.stories === 1, `sync ok: ${r.json.media} media, ${r.json.stories} stories, ${r.json.daysFetched} days, ${r.json.apiCalls} calls`, r.text.slice(0, 300));
ok(r.json.errors.some(e => e.code === 10) && r.json.explain.missingPermissions.includes('instagram_business_manage_insights'), 'permission error (code 10) → reported as missing permission');
ok(!r.text.includes(SECRET_TOKEN), 'sync response has no token');
r = await call('/api/dashboard', { now: T0 + 1000 });
ok(!r.text.includes(SECRET_TOKEN), 'dashboard has no token');
ok(r.json.status.data.bySource['graph-api'] === 14 && !r.json.status.data.bySource['public-scrape'] === false || r.json.status.data.bySource['graph-api'] === 14, 'graph-api data replaces public items with same shortcode', JSON.stringify(r.json.status.data.bySource));
ok(r.json.followerGrowth.followers === 2200, 'followers come from API snapshot');
ok(r.json.growthHealth.coverage > 34, `coverage grew with API data (${r.json.growthHealth.coverage}%)`);
const d2 = await globalThis.__ige_mem.get('media', 'DeAB3GdhFZB');
ok(d2.source === 'graph-api' && d2.durationSec === 128, 'media upgraded to graph-api while keeping known duration');
ok(r.json.stuck.problems.every(p => p.evidence), 'every problem has evidence');

console.log('\n6. Anti-repeat over 7 days + adaptivity');
const seenKeys = new Set(), seenHooks = [];
let dup = 0;
for (let i = 0; i < 7; i++) {
  const now = T0 + (i + 1) * DAY;
  await call('/api/plan/regenerate', { method: 'POST', now });
  const dd = (await call('/api/dashboard', { now })).json;
  for (const idea of dd.todaysReels) { if (seenKeys.has(idea.key)) dup++; seenKeys.add(idea.key); seenHooks.push(idea.hook); }
}
ok(dup === 0, `35 ideas over 7 days: ${dup} repeated keys`);
ok(new Set(seenHooks).size === seenHooks.length, 'no identical hooks across 7 days');

const base = Array.from({ length: 12 }, (_, i) => ({ id: 'b' + i, source: 'test', type: 'REEL', ts: T0 - (20 - i) * DAY, caption: 'تمرین چالش ' + i, durationSec: 20, metrics: { views: 5000, likes: 100, comments: 10 } }));
const weak = ['mindset شعار بدون ساختار', 'mindset اراده بهانه نیست', 'mindset غیرت و مرام'].map((c, i) => ({ id: 'w' + i, source: 'test', type: 'REEL', ts: T0 - (3 - i) * DAY, caption: c, durationSec: 20, metrics: { views: 1000, likes: 10, comments: 1 } }));
const A = analyzeAll({ media: [...base, ...weak], daily: [], stories: [], now: T0 });
const plan = makePlan({ date: '2026-10-09', A, pastIdeas: [], prevPlan: null, bestHourInfo: { hour: null }, now: T0 });
ok(plan.strategy.mode === 'PIVOT', 'last 3 reels weak → strategy PIVOT');
ok(!plan.ideas.some(i => plan.strategy.avoid.includes(i.topic)), 'PIVOT: avoids topics of the weak reels');

console.log('\n7. Learning loop (yesterday → today)');
const day = T0 + 20 * DAY;
await call('/api/plan/regenerate', { method: 'POST', now: day });
await call('/api/published', { method: 'POST', body: { mediaId: 'DeM3ze3hKxJ' }, now: day });
await call('/api/plan/regenerate', { method: 'POST', now: day + DAY });
const nd = (await call('/api/dashboard', { now: day + DAY })).json;
ok(nd.mission.yesterday && ['WIN', 'OK', 'WEAK'].includes(nd.mission.yesterday.status), 'yesterday result measured: ' + nd.mission.yesterday?.status + ' x' + nd.mission.yesterday?.ratio);

console.log('\n8. Coach');
for (const q of ['چرا این ریل نگرفت؟', 'امروز چی منتشر کنم؟', 'چرا فالوور اضافه نمی‌شود؟', 'برای امشب استوری بده', 'این هفته چه چیزی را تغییر بدهم؟', 'منتشر کنم یا نه «۳ ست بدون استراحت. تا آخر ببین»']) {
  const c = await call('/api/coach', { method: 'POST', body: { q }, now: day + DAY });
  ok(c.status === 200 && c.json.answer && c.json.source === 'rules', `rules answer: ${q}`, c.text.slice(0, 120));
}
const cc = await call('/api/coach', { method: 'POST', body: { q: 'x' }, now: day + DAY, e: { ...env, ANTHROPIC_API_KEY: 'k' }, fetchFn: mockFetch });
ok(cc.json.source === 'claude', 'optional Claude path works when ANTHROPIC_API_KEY is set');

console.log('\n9. Scoring weights');
ok(TEMPLATES.length >= 12, TEMPLATES.length + ' idea templates');

console.log('\n10. Deploy-readiness checks');
const hc = await call('/api/health', { key: null });
ok(hc.json.ok && hc.json.worker === 'OK' && hc.json.d1 === 'NOT CONFIGURED', 'health: worker OK, D1 reported honestly (no binding in test)', hc.text);
const fresh = { ADMIN_KEY: KEY, TIMEZONE_OFFSET_MIN: '210' };
globalThis.__ige_mem = undefined;
const st = (await call('/api/status', { e: fresh })).json;
ok(st.system.worker === 'OK' && st.system.instagram === 'NOT CONNECTED' && st.system.ai === 'NOT CONNECTED' && st.system.instagramData === 'DATA NOT AVAILABLE', 'status: Instagram/AI NOT CONNECTED, data = DATA NOT AVAILABLE', JSON.stringify(st.system));
ok(st.system.configProblems.some(x => x.includes('TOKEN_ENC_KEY')), 'status flags missing TOKEN_ENC_KEY');
ok(keyProblems({ ADMIN_KEY: 'short' }).some(x => x.includes('shorter than 16')) && keyProblems({ ADMIN_KEY: KEY, TOKEN_ENC_KEY: 'c2hvcnQ=' }).some(x => x.includes('32 bytes')), 'keyProblems flags short ADMIN_KEY and wrong-size TOKEN_ENC_KEY');
const badKey = await call('/api/token', { method: 'POST', body: { token: SECRET_TOKEN }, fetchFn: mockFetch, e: { ...fresh, ALLOW_MEMORY_STORE: '1', TOKEN_ENC_KEY: 'c2hvcnQ=' } });
ok(badKey.status === 500 && !badKey.text.includes(SECRET_TOKEN), 'wrong-size TOKEN_ENC_KEY refuses to store token', badKey.text);
const d1ok = { ...fresh, DB: { prepare: () => ({ first: async () => ({ n: 0 }), bind() { return this; } }) } };
ok((await call('/api/health', { key: null, e: d1ok })).json.d1 === 'OK', 'health: D1 OK when query succeeds');
const d1missing = { ...fresh, DB: { prepare: () => ({ first: async () => { throw new Error('no such table: records'); } }) } };
ok((await call('/api/status', { e: d1missing })).json.system.d1 === 'ERROR', 'status: D1 ERROR when schema missing');
ok((await call('/api/dashboard', { e: { ...fresh, ALLOW_MEMORY_STORE: '1', DB: undefined } })).json.growthHealth.score === null, 'no data → Growth Health = null, nothing invented');


console.log('\n11. Input validation, refresh, API version');
{
  const E = { ...env, ALLOW_MEMORY_STORE: '1' };
  const c2 = (path, body, extra = {}) => call(path, { method: 'POST', body, e: E, fetchFn: mockFetch, ...extra });
  ok((await c2('/api/token', { token: 'short' })).status === 400, 'token with bad format rejected (400)');
  ok((await c2('/api/token', { token: 'a b c d e f g h i j k l m n' })).status === 400, 'token with spaces rejected');
  ok((await c2('/api/token', { token: SECRET_TOKEN, userId: 'abc; DROP' })).status === 400, 'non-numeric userId rejected');
  ok((await c2('/api/import', { items: 'x' })).status === 400, 'import: items must be an array');
  ok((await c2('/api/import', { items: Array.from({ length: 201 }, (_, i) => ({ id: 'x' + i })) })).status === 413, 'import: >200 items rejected (413)');
  ok((await c2('/api/coach', { q: 'x'.repeat(501) })).status === 400, 'coach: question >500 chars rejected');
  ok((await c2('/api/coach', {})).status === 400, 'coach: missing question rejected');
  ok((await c2('/api/published', { mediaId: "x'; --" })).status === 400, 'published: bad mediaId rejected');
  const big = await handle(new Request('http://x/api/import', { method: 'POST', headers: { 'x-admin-key': KEY }, body: JSON.stringify({ items: [{ id: 'a'.repeat(300000) }] }) }), E);
  ok(big.status === 413, 'oversized body rejected (413)');
  const badJson = await handle(new Request('http://x/api/import', { method: 'POST', headers: { 'x-admin-key': KEY }, body: '{oops' }), E);
  ok(badJson.status === 400, 'malformed JSON → 400, not 500');
  // refresh: token stored in D1-like store gets re-encrypted; secret never leaks
  await c2('/api/token', { token: SECRET_TOKEN });
  const rec0 = await globalThis.__ige_mem.get('kv', 'token');
  const rr = await refreshToken(E, globalThis.__ige_mem, { now: T0 + 25 * DAY, fetchFn: mockFetch });
  const rec1 = await globalThis.__ige_mem.get('kv', 'token');
  ok(rr.refreshed && rec1.enc !== rec0.enc && rec1.refreshedAt && !JSON.stringify(rec1).includes(SECRET_TOKEN), 'token refreshed after 25 days; stored encrypted again');
  const rr2 = await refreshToken(E, globalThis.__ige_mem, { now: T0 + 26 * DAY, fetchFn: mockFetch });
  ok(rr2.skipped === true, 'recent token is not refreshed again');
  const rr3 = await c2('/api/token/refresh', {});
  ok(rr3.status === 200 && !rr3.text.includes(SECRET_TOKEN), 'manual refresh endpoint works and never returns the token');
  // API version is v25.0 by default
  let seen = null; const spy = async u => { seen = String(u); return mockFetch(u); };
  await c2('/api/sync', {}, { fetchFn: spy });
  ok(/graph\.instagram\.com\/v25\.0\//.test(seen), 'default Graph API version is v25.0 (' + seen.split('?')[0] + ')');
  // logs never contain secrets: no console.* in src
  const { readdirSync, readFileSync: rf } = await import('node:fs');
  const src = readdirSync(new URL('../src/', import.meta.url)).map(f => rf(new URL('../src/' + f, import.meta.url), 'utf8')).join('\n');
  ok(!/console\./.test(src), 'no console.* calls in src (nothing can leak into logs)');
  ok(!/(IGAA|EAA[A-Za-z0-9]{20,}|sk-ant-)/.test(src + rf(new URL('../public/index.html', import.meta.url), 'utf8') + rf(new URL('../wrangler.toml', import.meta.url), 'utf8')), 'no token-like secrets in src, frontend or wrangler.toml');
}

console.log('\n12. AI analysis layer, Cron handler, published-link retention');
{
  const mod = (await import('../src/index.js')).default;
  const { tehranDate } = await import('../src/planner.js');
  globalThis.__ige_mem = undefined;
  const E = { ...env, ALLOW_MEMORY_STORE: '1' };
  await call('/api/import', { method: 'POST', body: { items: seed.items }, e: E });
  // no key
  let r = await call('/api/ai/analyze', { method: 'POST', body: {}, e: E, fetchFn: mockFetch });
  ok(r.json.status === 'NOT CONNECTED', 'AI: no ANTHROPIC_API_KEY → NOT CONNECTED (app keeps working)');
  // key + success
  let sent = null; const aiFetch = async (u, o) => { sent = JSON.parse(o.body); return new Response(JSON.stringify({ content: [{ type: 'text', text: '۱) آزمایشی' }] }), { status: 200 }); };
  const EK = { ...E, ANTHROPIC_API_KEY: 'fake-key-for-test' };
  r = await call('/api/ai/analyze', { method: 'POST', body: {}, e: EK, fetchFn: aiFetch });
  ok(r.json.status === 'OK' && r.json.text.includes('آزمایشی'), 'AI: key set → analysis stored (mock Anthropic response)');
  ok(sent && /DATA NOT AVAILABLE/.test(sent.system) && sent.max_tokens === 700 && !JSON.stringify(sent).includes('fake-key-for-test'), 'AI request: forbids invention, caps tokens, key not in body');
  let d = (await call('/api/dashboard', { e: EK })).json; ok(d.ai.status === 'OK', 'dashboard exposes ai.status separately from rule-based plan');
  // Anthropic error must not break anything
  const failFetch = async () => new Response(JSON.stringify({ error: { message: 'invalid x-api-key' } }), { status: 401 });
  r = await call('/api/ai/analyze', { method: 'POST', body: {}, e: EK, fetchFn: failFetch });
  ok(r.json.status === 'ERROR' && !r.text.includes('fake-key-for-test'), 'AI: API error → status ERROR, no secret leaked');
  d = (await call('/api/dashboard', { e: EK })).json; ok(d.todaysReels.length === 5, 'rule-based plan unaffected by AI error');
  // published link survives regenerate
  await call('/api/published', { method: 'POST', body: { mediaId: 'DeM3ze3hKxJ' }, e: E });
  await call('/api/plan/regenerate', { method: 'POST', body: {}, e: E });
  const today = tehranDate(T0, 210), planNow = await globalThis.__ige_mem.get('plans', today);
  ok(planNow.publishedMediaId === 'DeM3ze3hKxJ', 'regenerating today\'s plan keeps the published-reel link');
  // Cron handler (real function, memory store, no Instagram token)
  globalThis.__ige_mem = undefined; const pending = [];
  await mod.scheduled({ cron: '30 2 * * *' }, E, { waitUntil: p => pending.push(p) });
  await Promise.all(pending);
  const tNow = tehranDate(Date.now(), 210);
  ok(pending.length === 1 && !!(await globalThis.__ige_mem.get('plans', tNow)), 'cron: scheduled() builds today\'s plan without a token, no exception');
  ok((await globalThis.__ige_mem.get('kv', 'lastSync')) === null, 'cron: no Instagram token → nothing fetched, nothing invented');
  // cron with broken D1 must not throw
  let threw = false; try { await mod.scheduled({}, { ADMIN_KEY: KEY }, { waitUntil: () => {} }); } catch { threw = true; }
  ok(!threw, 'cron: missing D1 binding does not throw');
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
