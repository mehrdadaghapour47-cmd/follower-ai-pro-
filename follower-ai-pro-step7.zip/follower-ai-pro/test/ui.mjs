// UI tests for the "دستیار" tab in public/index.html.
// Part 1 (always runs): static checks on public/index.html, public/sw.js and the bundle.
// Part 2 (needs Playwright + Chromium): the REAL page is loaded in headless Chromium (Android-sized viewport) and served by the REAL bundle
// (dist/worker.js) over a local HTTP server. Workers AI is a mock and D1 is the in-memory store: nothing real (Cloudflare, Instagram) is contacted.
// If Playwright/Chromium is missing, Part 2 prints SKIPPED (it is never counted as passed).
import http from 'node:http';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
let pass = 0, fail = 0, skipped = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };
const section = async (name, fn) => { console.log('\n' + name); try { await fn(); } catch (e) { fail++; console.log('  FAIL section crashed: ' + String(e.message).split('\n')[0]); } };
const pub = f => readFileSync(new URL('../public/' + f, import.meta.url), 'utf8');
const KEY = 'a-long-random-test-key-1234', NOW_SEED = JSON.parse(pub('seed-public-reels.json')).items;
const html = pub('index.html'), sw = pub('sw.js');
const mod = await import('../dist/worker.js'), STATIC_ENV = { ADMIN_KEY: KEY, ALLOW_MEMORY_STORE: '1' };

await section('A. static checks (no browser needed)', async () => {
  const tabs = ['today', 'analysis', 'reels', 'stories', 'coach'];
  ok(tabs.every(t => html.includes(`data-t="${t}"`) && html.includes(`id="t-${t}"`)), 'the five existing tabs are still there (today, analysis, reels, stories, coach)');
  ok(html.includes('data-t="assistant"') && html.includes('id="t-assistant"') && /<nav[\s\S]*data-t="assistant"[\s\S]*<\/nav>/.test(html), 'new tab: nav button + section "t-assistant"');
  ok(/dir="rtl"/.test(html) && /lang="fa"/.test(html) && /viewport/.test(html), 'still Persian, RTL, mobile viewport');
  const block = html.split('/* ===== assistant tab')[1]?.split('/* ===== /assistant tab')[0] ?? '';
  ok(block.length > 2000, 'assistant script block found');
  ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(|new Function/.test(block), 'assistant code never uses innerHTML / eval: message text can only enter the page via textContent');
  ok(/\.textContent=text|d\.textContent=text/.test(block) && /pb\.textContent=j\.reply/.test(block), 'user text and AI reply are inserted with textContent');
  ok(!/localStorage/.test(html), 'no localStorage anywhere in the page');
  ok(!/x-admin-key/i.test(block) && !/fetch\(/.test(block) && /api\('\/api\/assistant/.test(block), 'assistant code reuses api() (no own fetch, no key handling)');
  ok(!/ADMIN_KEY\s*=|TOKEN_ENC_KEY\s*=|IG_ACCESS_TOKEN|sk-ant-|IGAA/.test(html + sw), 'no secrets in the page or the service worker');
  ok(/'fap-static-v3'/.test(sw) && !/fap-static-v2/.test(sw), 'service worker cache version bumped to v3');
  ok(/pathname\.startsWith\('\/api\/'\)/.test(sw) && /return; \/\/ network only/.test(sw) && !/put\(/.test(sw), 'service worker still never caches /api/*');
  const r = await mod.default.fetch(new Request('http://x/'), STATIC_ENV); const served = await r.text();
  ok(r.status === 200 && served === html, 'the bundle (dist/worker.js) serves exactly public/index.html: bundle is up to date');
  const r2 = await mod.default.fetch(new Request('http://x/sw.js'), STATIC_ENV); ok((await r2.text()) === sw, 'the bundle serves exactly public/sw.js');
});

// ---------- Part 2: real browser ----------
let pw = null, browser = null;
let whyNot = '';
try { pw = createRequire(import.meta.url)('playwright'); browser = await pw.chromium.launch({ args: ['--no-sandbox'] }); } catch (e) { pw = null; whyNot = String(e.message).split('\n')[0]; }
if (!browser) { skipped = 1; console.log('\nB. browser tests: SKIPPED (Playwright/Chromium not available: ' + whyNot + '). Not counted as passed.'); }
else {
  const mkAI = beh => ({ run: async (model, input) => {
    const isA = String(input?.messages?.[0]?.content ?? '').startsWith('You are the Persian-speaking assistant');
    if (!isA) return { response: 'تحلیل آزمایشی' };
    beh.calls.push(input); if (beh.delay) await new Promise(r => setTimeout(r, beh.delay));
    if (beh.mode === 'throw') throw new Error('model offline ' + KEY);
    if (beh.mode === 'empty') return { response: '  ' };
    if (beh.mode === 'fake') return { response: 'تو ۵۰۰۰۰ فالوور داری و رشد ماهانه ۱۲٪ است. پیشنهاد: ریل ۲۰ ثانیه‌ای بساز.' };
    return { response: beh.reply ?? 'پاسخ ' + beh.calls.length };
  } });
  const beh = { calls: [], delay: 0, mode: 'ok', reply: null };
  const env = { ADMIN_KEY: KEY, ALLOW_MEMORY_STORE: '1', RATE_LIMIT_PER_MIN: '1000', AI: mkAI(beh) };
  const stats = { assistantPosts: 0 }; globalThis.__ige_mem = undefined;
  const server = http.createServer(async (req, res) => {
    const chunks = []; for await (const c of req) chunks.push(c);
    const h = {}; for (const k of ['x-admin-key', 'x-account', 'content-type']) if (req.headers[k] !== undefined) h[k] = req.headers[k];
    if (req.method === 'POST' && req.url.split('?')[0] === '/api/assistant') stats.assistantPosts++;
    const r = await mod.default.fetch(new Request('http://localhost' + req.url, { method: req.method, headers: h, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) }), env);
    res.writeHead(r.status, Object.fromEntries(r.headers)); res.end(Buffer.from(await r.arrayBuffer()));
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r)); const BASE = 'http://127.0.0.1:' + server.address().port;
  const raw = async (path, { method = 'GET', body, account } = {}) => { const r = await fetch(BASE + path, { method, headers: { 'x-admin-key': KEY, 'content-type': 'application/json', ...(account ? { 'x-account': account } : {}) }, body: body ? JSON.stringify(body) : undefined }); return { status: r.status, json: await r.json().catch(() => null) }; };
  await raw('/api/import', { method: 'POST', body: { items: NOW_SEED } }); // real stored page data for account "main"
  const SID = n => 'ses_' + String(n).repeat(32).slice(0, 32);

  const newPage = async (w = 360, h = 740, init) => { const ctx = await browser.newContext({ viewport: { width: w, height: h }, serviceWorkers: 'block', locale: 'fa-IR' }); const page = await ctx.newPage(); page.setDefaultTimeout(8000); page.dialogs = []; page.on('dialog', d => { page.dialogs.push(d.message()); d.accept(); }); if (init) await page.addInitScript(init.fn, init.arg); return page; };
  const login = async page => { await page.goto(BASE + '/'); await page.fill('#key', KEY); await page.click('#go'); await page.waitForSelector('#nav:not([hidden])'); };
  const openAs = async page => { await page.click('nav button[data-t="assistant"]'); await page.waitForSelector('#t-assistant.on'); };
  const msgs = page => page.$$eval('#as-log .am', els => els.map(e => ({ cls: e.className.replace('am ', ''), text: e.textContent })));
  const note = page => page.$$eval('#as-log .asn', els => els.map(e => e.textContent).join(' | '));
  const send = async (page, text) => { await page.fill('#as-in', text); await page.click('#as-send'); };
  const waitAnswer = (page, n = 1) => page.waitForFunction(k => document.querySelectorAll('#as-log .am.a:not(.pend)').length >= k, n);
  const switchAcct = async (page, a) => { await page.click('nav button[data-t="analysis"]'); await page.fill('#acct', a); await page.click('#acctBtn'); await page.waitForFunction(x => document.querySelector('#acct')?.value !== undefined && sessionStorage.getItem('ige-acct') === x, a); await page.waitForSelector('#nav:not([hidden])'); await page.waitForTimeout(250); };

  await section('B. tabs, RTL and small Android screens', async () => {
    for (const [w, h] of [[360, 740], [320, 640]]) {
      const page = await newPage(w, h); await login(page);
      const info = await page.evaluate(() => ({ dir: document.documentElement.dir, lang: document.documentElement.lang, sw: document.documentElement.scrollWidth, iw: innerWidth, btns: [...document.querySelectorAll('nav button')].map(b => { const r = b.getBoundingClientRect(); return { t: b.dataset.t, l: r.left, r: r.right, w: r.width, clipped: b.scrollWidth > b.clientWidth + 1 }; }) }));
      ok(info.dir === 'rtl' && info.lang === 'fa', `${w}px: page is RTL + Persian`);
      ok(info.btns.map(b => b.t).join() === 'today,analysis,reels,stories,coach,assistant', `${w}px: six nav buttons in order, new one last`);
      ok(info.btns.every(b => b.l >= -0.5 && b.r <= w + 0.5 && b.w >= 44 && !b.clipped), `${w}px: every nav button fits inside the screen, is ≥ 44px wide and its label is not clipped`);
      await openAs(page); const i2 = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: innerWidth, dir: getComputedStyle(document.querySelector('#t-assistant')).direction, send: document.querySelector('#as-send').getBoundingClientRect().toJSON(), inp: document.querySelector('#as-in').getBoundingClientRect().toJSON() }));
      ok(i2.sw <= i2.iw && i2.dir === 'rtl', `${w}px: assistant tab has no horizontal scroll and is right-to-left`);
      ok(i2.send.left >= 0 && i2.send.right <= w && i2.inp.left >= 0 && i2.inp.right <= w, `${w}px: input and send button are fully on screen`);
      await page.context().close();
    }
    const page = await newPage(); await login(page);
    for (const t of ['today', 'analysis', 'reels', 'stories']) { await page.click(`nav button[data-t="${t}"]`); const r = await page.$eval('#t-' + t, e => ({ on: e.classList.contains('on'), vis: e.offsetParent !== null, len: e.textContent.trim().length })); ok(r.on && r.vis && r.len > 20, `old tab "${t}" still opens and has content`); }
    await page.click('nav button[data-t="coach"]'); await page.fill('#q', 'این هفته چه چیزی را تغییر بدهم؟'); await page.click('#ask'); await page.waitForFunction(() => { const a = document.querySelector('#log .a'); return a && a.textContent.trim() && a.textContent.trim() !== '…'; });
    ok(((await page.$eval('#log .a', e => e.textContent)).length > 5), 'old coach tab still answers');
    await openAs(page); ok(await page.$eval('#t-coach', e => !e.classList.contains('on')) && await page.$eval('#t-assistant', e => e.classList.contains('on')), 'switching to the assistant hides the other tabs');
    await page.context().close();
  });

  await section('C. send a message and show the answer (+ pending state, no double send)', async () => {
    beh.calls = []; beh.delay = 600; beh.mode = 'ok'; beh.reply = null; const page = await newPage(); await login(page); await openAs(page);
    ok(await page.$('#as-empty') !== null && (await page.$eval('#as-empty', e => e.textContent)).includes('داده‌های واقعی'), 'empty state explains that only real stored data is used');
    const before = stats.assistantPosts; await send(page, 'سلام دستیار');
    await page.waitForSelector('#as-log .am.pend'); const mid = await msgs(page);
    ok(mid.length === 2 && mid[0].cls === 'u' && mid[0].text === 'سلام دستیار' && mid[1].cls.includes('pend') && mid[1].text === 'در حال نوشتن…', 'while waiting: user bubble + "در حال نوشتن…" bubble');
    ok(await page.$eval('#as-send', b => b.disabled) && await page.$eval('#as-clear', b => b.disabled) && await page.$$eval('#as-chips button', bs => bs.every(b => b.disabled)), 'send, clear and the quick buttons are disabled while the request runs');
    await page.evaluate(() => { const b = document.querySelector('#as-send'); b.click(); b.click(); document.querySelector('#as-chips button').click(); asSend('دوباره'); asSend('و دوباره'); }); // every way of sending again
    await waitAnswer(page); await page.waitForTimeout(300);
    ok(stats.assistantPosts - before === 1 && beh.calls.length === 1, 'only ONE request reached the server although send was triggered 6 times');
    const done = await msgs(page); ok(done.length === 2 && done[1].cls === 'a' && done[1].text === 'پاسخ 1', 'the answer replaces the pending bubble');
    ok(!(await page.$eval('#as-send', b => b.disabled)) && !(await page.$eval('#as-clear', b => b.disabled)), 'controls are enabled again afterwards');
    const store = await page.evaluate(() => ({ keys: Object.keys(sessionStorage).sort(), ls: localStorage.length, sid: sessionStorage.getItem('ige-asid:main') }));
    ok(/^ses_[0-9a-f]{32}$/.test(store.sid) && store.ls === 0, 'server-issued session id kept per account in sessionStorage; localStorage stays empty');
    ok(await page.$eval('#as-data', e => e.textContent) === 'داده واقعی پیج: موجود', 'status line says real page data exists (account has imported reels)');
    ok(beh.calls[0].messages[0].content.includes('reels with stored stats') && !beh.calls[0].messages[0].content.includes(KEY), 'the model got real stored data and no secret');
    await send(page, 'ایده بده'); await waitAnswer(page, 2); const two = await msgs(page); ok(two.map(m => m.text).join('|') === 'سلام دستیار|پاسخ 1|ایده بده|پاسخ 2', 'second turn appended in order');
    ok(beh.calls[1].messages.length === 1 + 2 + 1, 'the second request carried the first turn as history');
    await page.context().close(); beh.delay = 0;
  });

  await section('D. history reload, order and clear', async () => {
    beh.calls = []; beh.delay = 0; const sid = SID(5);
    for (const t of ['اول', 'دوم', 'سوم']) await raw('/api/assistant', { method: 'POST', body: { message: t, sessionId: sid } });
    const page = await newPage(360, 740, { fn: s => { if (!sessionStorage.getItem('ige-asid:main')) sessionStorage.setItem('ige-asid:main', s); }, arg: sid });
    await login(page); await openAs(page); await page.waitForSelector('#as-log .am');
    const old = await msgs(page); ok(old.length === 6 && old.map(m => m.cls).join() === 'u,a,u,a,u,a' && old.filter(m => m.cls === 'u').map(m => m.text).join('|') === 'اول|دوم|سوم', 'stored history loads oldest → newest with the right roles');
    ok(old[0].text === 'اول' && old[5].text.startsWith('پاسخ'), 'first and last bubbles are the oldest and newest');
    await send(page, 'جدید'); await waitAnswer(page, 4); const all = await msgs(page); ok(all.length === 8 && all[6].text === 'جدید' && all[7].cls === 'a', 'a new message goes after the old ones');
    await page.reload(); await page.waitForSelector('#nav:not([hidden])'); await openAs(page); await page.waitForSelector('#as-log .am'); const again = await msgs(page);
    ok(again.length === 8 && again.map(m => m.text).join('|') === all.map(m => m.text).join('|'), 'after a page reload the same 8 messages come back in the same order');
    page.dialogs.length = 0; page.removeAllListeners('dialog'); page.on('dialog', d => { page.dialogs.push(d.message()); d.dismiss(); });
    await page.click('#as-clear'); await page.waitForTimeout(300); ok(page.dialogs.length === 1 && (await msgs(page)).length === 8 && (await raw('/api/assistant/history?sessionId=' + sid)).json.messages.length === 8, 'clear asks for confirmation; cancelling deletes nothing');
    page.removeAllListeners('dialog'); page.on('dialog', d => d.accept());
    await page.route('**/api/assistant/clear', r => r.abort()); await page.click('#as-clear'); await page.waitForTimeout(400);
    ok((await msgs(page)).length === 8 && (await note(page)).includes('پاک‌کردن انجام نشد') && (await raw('/api/assistant/history?sessionId=' + sid)).json.messages.length === 8 && await page.evaluate(() => !!sessionStorage.getItem('ige-asid:main')), 'a failed clear (network) keeps the conversation on screen, on the server and in sessionStorage');
    await page.unroute('**/api/assistant/clear'); await page.click('#as-clear'); await page.waitForFunction(() => !document.querySelector('#as-log .am'));
    ok((await page.$eval('#as-empty', e => e.textContent)).length > 10 && await page.evaluate(() => !sessionStorage.getItem('ige-asid:main')) && (await raw('/api/assistant/history?sessionId=' + sid)).json.messages.length === 0, 'confirmed clear: screen empty, session forgotten, server history really empty');
    await send(page, 'بعد از پاک‌کردن'); await waitAnswer(page); const fresh = await page.evaluate(() => sessionStorage.getItem('ige-asid:main')); ok(fresh && fresh !== sid && (await msgs(page)).length === 2, 'after clear a NEW session starts');
    await page.context().close();
  });

  await section('E. accounts: no history of the previous account is shown', async () => {
    beh.calls = []; beh.delay = 0; beh.mode = 'ok'; const page = await newPage(); await login(page); await openAs(page);
    await send(page, 'پیام حساب اصلی'); await waitAnswer(page); const mainSid = await page.evaluate(() => sessionStorage.getItem('ige-asid:main'));
    await switchAcct(page, 'second'); await openAs(page);
    ok((await msgs(page)).length === 0 && await page.$eval('#as-acct', e => e.textContent) === 'second', 'after switching account the log is empty and shows the new account name');
    ok(!(await page.$eval('#t-assistant', e => e.textContent)).includes('پیام حساب اصلی'), 'nothing from the previous account is anywhere in the tab');
    await send(page, 'پیام حساب دوم'); await waitAnswer(page);
    ok(beh.calls.at(-1).messages.length === 2 && !JSON.stringify(beh.calls.at(-1)).includes('پیام حساب اصلی'), 'the second account\'s request carries none of the first account\'s history');
    ok(await page.$eval('#as-data', e => e.textContent) === 'داده واقعی پیج: موجود نیست' && (await note(page)).includes('هیچ آماری ندارد'), 'account without imported data: the UI says real data is missing and that the answer has no statistics');
    const secondSid = await page.evaluate(() => sessionStorage.getItem('ige-asid:second')); ok(secondSid && secondSid !== mainSid, 'each account has its own session id');
    await switchAcct(page, 'main'); await openAs(page); await page.waitForSelector('#as-log .am'); const back = await msgs(page);
    ok(back.length === 2 && back[0].text === 'پیام حساب اصلی' && !back.some(m => m.text === 'پیام حساب دوم'), 'switching back shows only the main account\'s conversation');
    const crossHist = await raw('/api/assistant/history?sessionId=' + mainSid, { account: 'second' }); ok(crossHist.json.messages.length === 0, 'server: the main session id read as account "second" returns nothing');
    // answer that arrives after the user switched account must not appear in the other account's screen
    beh.delay = 900; await send(page, 'آهسته'); await page.waitForTimeout(150); await switchAcct(page, 'second'); await openAs(page); await page.waitForTimeout(1300);
    const stale = await msgs(page); ok(stale.length === 2 && !stale.some(m => m.text === 'آهسته') && !(await note(page)).includes('نوشتن'), 'a slow answer that arrives after switching account is not shown in the new account (and its pending bubble is gone)');
    ok(await page.$eval('#as-data', e => e.textContent) === '' && await page.$eval('#as-status', e => e.textContent) === '', 'the late answer also does not touch the other account\'s data-status / status lines');
    beh.delay = 700; beh.mode = 'throw'; await switchAcct(page, 'main'); await openAs(page); await page.waitForSelector('#as-log .am'); await send(page, 'آهسته و خراب'); await page.waitForTimeout(150); await switchAcct(page, 'second'); await openAs(page); await page.waitForTimeout(1100);
    ok((await note(page)) === '' || !(await note(page)).includes('سر جایش'), 'a late ERROR from the previous account is not shown in the new account either'); beh.mode = 'ok';
    beh.delay = 0; await switchAcct(page, 'main'); await openAs(page); await page.waitForSelector('#as-log .am');
    ok((await msgs(page)).map(m => m.text).includes('آهسته') && !(await page.$eval('#as-send', b => b.disabled)), 'back on main the slow turn is there (it was saved) and sending is enabled');
    await page.context().close();
  });

  await section('F. API / network errors: controlled messages, nothing lost', async () => {
    beh.calls = []; beh.delay = 0; beh.mode = 'ok'; const page = await newPage(); await login(page); await openAs(page);
    await send(page, 'پیام سالم'); await waitAnswer(page); const sid = await page.evaluate(() => sessionStorage.getItem('ige-asid:main')); const good = await msgs(page);
    const serverCount = async () => (await raw('/api/assistant/history?sessionId=' + sid)).json.messages.length;
    const fails = async (name, textPart) => { const m = await msgs(page); ok(m.length === good.length && m.every((x, i) => x.text === good[i].text), `${name}: bubbles unchanged (failed message removed, nothing cleared)`); ok((await note(page)).includes(textPart), `${name}: shows "${textPart}"`); ok((await page.$eval('#as-in', e => e.value)) === 'پیام ناموفق' && !(await page.$eval('#as-send', b => b.disabled)), `${name}: the text is back in the input and sending is enabled`); ok((await serverCount()) === good.length, `${name}: server history unchanged`); };
    beh.mode = 'throw'; await send(page, 'پیام ناموفق'); await page.waitForSelector('#as-log .asn.err'); await fails('AI error', 'ذخیره نشد'); ok(!(await page.content()).includes('model offline') && !(await note(page)).includes(KEY), 'AI error: raw error text / key never shown'); beh.mode = 'ok';
    beh.mode = 'empty'; await page.fill('#as-in', ''); await send(page, 'پیام ناموفق'); await page.waitForSelector('#as-log .asn.err'); await fails('empty AI answer', 'پاسخی از هوش مصنوعی نرسید'); beh.mode = 'ok';
    await page.route('**/api/assistant', r => r.abort()); await page.fill('#as-in', ''); await send(page, 'پیام ناموفق'); await page.waitForSelector('#as-log .asn.err'); await fails('network failure', 'اتصال برقرار نشد'); await page.unroute('**/api/assistant');
    await page.route('**/api/assistant', r => r.fulfill({ status: 502, contentType: 'text/html', body: '<html>Bad gateway</html>' })); await page.fill('#as-in', ''); await send(page, 'پیام ناموفق'); await page.waitForSelector('#as-log .asn.err'); await fails('non-JSON 502 from a proxy', 'پاسخی از هوش مصنوعی نرسید'); await page.unroute('**/api/assistant');
    const savedAI = env.AI; delete env.AI; await page.fill('#as-in', ''); await send(page, 'پیام ناموفق'); await page.waitForSelector('#as-log .asn.err'); await fails('AI not connected (503)', 'هوش مصنوعی متصل نیست');
    ok(await page.$eval('#gate', e => e.hidden) && await page.evaluate(() => !!sessionStorage.getItem('ige-key')), 'AI not connected (503) does NOT log the user out (api() calls every 503 "auth"; the known assistant 503 texts are told apart)'); env.AI = savedAI;
    await page.fill('#as-in', ''); await send(page, 'بعد از رفع خطا'); await waitAnswer(page, 2); ok((await msgs(page)).length === 4 && (await page.$$eval('#as-log .asn.err', e => e.length)) === 0, 'after the error is fixed, sending works again and the old error line is gone');
    const sid2 = await page.evaluate(() => sessionStorage.getItem('ige-asid:main')); ok(sid2 === sid, 'the same session continues after errors');
    env.RATE_LIMIT_PER_MIN = '1'; let rateSeen = false; for (let i = 0; i < 4 && !rateSeen; i++) { await page.fill('#as-in', ''); await send(page, 'سقف ' + i); await page.waitForFunction(() => !document.querySelector('#as-log .pend')); rateSeen = (await note(page)).includes('سقف درخواست'); } env.RATE_LIMIT_PER_MIN = '1000';
    ok(rateSeen, 'rate limit (429) → "سقف درخواست در دقیقه پر شده"');
    const long = 'ا'.repeat(2000); await page.fill('#as-in', ''); await page.evaluate(t => { document.querySelector('#as-in').removeAttribute('maxlength'); document.querySelector('#as-in').value = t + 'ب'; }, long); const posts = stats.assistantPosts; await page.click('#as-send');
    ok(stats.assistantPosts === posts && (await note(page)).includes('بیش از ۲۰۰۰'), 'message over 2000 chars is stopped in the browser (no request) with a message');
    ok(await page.$eval('#as-in', e => e.getAttribute('maxlength')) === null, '(maxlength was removed by the test to reach that check)'); 
    await page.context().close();
    const p2 = await newPage(); await login(p2); await openAs(p2); await send(p2, 'x'); await waitAnswer(p2); const sid3 = await p2.evaluate(() => sessionStorage.getItem('ige-asid:main'));
    await p2.evaluate(() => { KEY = 'wrong-key-wrong-key-123'; }); await send(p2, 'با کلید خراب'); await p2.waitForFunction(() => !document.querySelector('#gate').hidden);
    ok((await p2.$eval('#gerr', e => e.textContent)).includes('کلید نادرست') && (await raw('/api/assistant/history?sessionId=' + sid3)).json.messages.length === 2, 'wrong key (401): the existing login gate appears, server history is untouched');
    ok((await msgs(p2)).length === 2, 'wrong key: the earlier conversation is still on screen'); await p2.context().close();
  });

  await section('G. history load failure never wipes anything', async () => {
    beh.mode = 'ok'; const sid = SID(7); await raw('/api/assistant', { method: 'POST', body: { message: 'ذخیره‌شده', sessionId: sid } });
    const page = await newPage(360, 740, { fn: s => { if (!sessionStorage.getItem('ige-asid:main')) sessionStorage.setItem('ige-asid:main', s); }, arg: sid });
    await page.route('**/api/assistant/history**', r => r.fulfill({ status: 500, contentType: 'application/json', body: '{"error":"boom"}' }));
    await login(page); await openAs(page); await page.waitForSelector('#as-log .asn.err');
    ok((await note(page)).includes('تاریخچه بارگذاری نشد') && (await raw('/api/assistant/history?sessionId=' + sid)).json.messages.length === 2 && await page.evaluate(() => !!sessionStorage.getItem('ige-asid:main')), 'failed history load: error shown, server history and session id are kept');
    await page.unroute('**/api/assistant/history**'); await page.evaluate(() => load()); await page.waitForSelector('#as-log .am'); ok((await msgs(page)).length === 2, 'the next load() retries and shows the stored conversation');
    await page.context().close();
  });

  await section('H. injected HTML is shown as text and never runs', async () => {
    beh.mode = 'ok'; beh.delay = 0; const evil = '<img src=x onerror="window.__xss=1;alert(1)"><script>window.__xss=2</script><svg onload="window.__xss=4"></svg> <b>غلیظ</b> "\'&';
    beh.reply = '<img src=x onerror="window.__xss=3;alert(3)"><a href="javascript:window.__xss=5">لینک</a><b>پاسخ</b>\nخط دوم';
    const page = await newPage(); await login(page); await openAs(page); await send(page, evil); await waitAnswer(page); await page.waitForTimeout(400);
    const m = await msgs(page); ok(m[0].text === evil && m[1].text === beh.reply, 'user text and AI reply are displayed literally (characters, not markup)');
    const dom = await page.evaluate(() => ({ xss: window.__xss, tags: document.querySelectorAll('#as-log img, #as-log script, #as-log svg, #as-log a, #as-log b, #as-log iframe').length, kids: [...document.querySelectorAll('#as-log .am')].map(e => e.children.length), ws: getComputedStyle(document.querySelector('#as-log .am.a')).whiteSpace, dir: document.querySelector('#as-log .am').getAttribute('dir') }));
    ok(dom.xss === undefined && page.dialogs.length === 0, 'no script ran: window.__xss is undefined and no alert() appeared');
    ok(dom.tags === 0 && dom.kids.every(k => k === 0), 'no injected element exists inside the messages');
    ok(dom.ws === 'pre-wrap' && dom.dir === 'auto', 'line breaks are kept (pre-wrap) and mixed Persian/Latin text uses dir="auto"');
    await page.reload(); await page.waitForSelector('#nav:not([hidden])'); await openAs(page); await page.waitForSelector('#as-log .am'); await page.waitForTimeout(400);
    const dom2 = await page.evaluate(() => ({ xss: window.__xss, tags: document.querySelectorAll('#as-log img, #as-log script, #as-log svg, #as-log a, #as-log b').length })); const h = await msgs(page);
    ok(dom2.xss === undefined && dom2.tags === 0 && page.dialogs.length === 0 && h[0].text === evil, 'the same payload loaded back from stored history is also inert');
    const raw2 = await page.content(); ok(!raw2.includes(KEY), 'the admin key is not in the page HTML'); beh.reply = null;
    await page.context().close();
  });

  await section('I. secrets and storage', async () => {
    beh.mode = 'ok'; const page = await newPage(); await login(page); await openAs(page); await send(page, 'سلام'); await waitAnswer(page);
    const st = await page.evaluate(() => ({ ls: localStorage.length, ss: Object.keys(sessionStorage).sort() }));
    ok(st.ls === 0, 'localStorage is empty (nothing new stored there)'); ok(st.ss.every(k => ['ige-key', 'ige-acct', 'ige-tab'].includes(k) || /^ige-asid:[a-z0-9._]+$/.test(k)), `sessionStorage only holds the existing keys + ige-asid:<account> (${st.ss.join(', ')})`);
    ok(!JSON.stringify(beh.calls).includes(KEY), 'the key never reached the model'); ok((await page.evaluate(() => document.documentElement.outerHTML)).includes(KEY) === false, 'the key is not present in the DOM');
    await page.context().close();
  });

  await section('J. invented statistics never reach the screen', async () => {
    beh.calls = []; beh.delay = 0; beh.mode = 'fake'; const page = await newPage(); await login(page); await openAs(page);
    await send(page, 'برای پیجم برنامه بده'); await waitAnswer(page); const m = await msgs(page); const text = m[1].text;
    ok(!/۵۰۰۰۰|50000|۱۲٪/.test(text) && text.includes('[عدد نامعتبر]') && text.includes('ریل ۲۰ ثانیه‌ای') && beh.calls.length === 2, 'the invented follower count and growth % are replaced by a marker; the useful suggestion stays (one rewrite was attempted)');
    ok((await note(page)).includes('غیرقابل‌تأیید') && !/۵۰۰۰۰/.test(await page.$eval('#t-assistant', e => e.textContent)), 'the screen explains that unverifiable numbers were removed and shows none of them anywhere');
    await page.reload(); await page.waitForSelector('#nav:not([hidden])'); await openAs(page); await page.waitForSelector('#as-log .am');
    ok(!(await page.$eval('#as-log', e => e.textContent)).includes('۵۰۰۰۰') && (await msgs(page))[1].text === text, 'after reload the stored (sanitised) answer is shown, not the original');
    beh.mode = 'ok'; const before = beh.calls.length; await send(page, 'چند فالوور دارم؟'); await waitAnswer(page, 2); const m2 = await msgs(page);
    ok(beh.calls.length === before && m2[3].text.startsWith('اطلاعات کافی در دسترس نیست') && m2[3].text.includes('تعداد فالوور'), 'a follower-count question is answered by code: the model is not called and the answer says the data is not available');
    await send(page, 'من ۱۰۰۰۰ فالوور دارم درسته؟ تأیید کن'); await waitAnswer(page, 3); const m3 = await msgs(page);
    ok(m3[5].text.includes('تأییدشده نیست') && !/تو ۱۰۰۰۰ فالوور داری/.test(m3[5].text), 'a number typed by the user is reported as unconfirmed, not echoed as fact');
    await page.route('**/api/assistant', async r => { if (r.request().method() !== 'POST') return r.continue(); const resp = await r.fetch(); const j = await resp.json(); j.dataQuality = { ...j.dataQuality, stale: true }; await r.fulfill({ response: resp, json: j }); });
    await send(page, 'ایده بده'); await waitAnswer(page, 4); ok((await note(page)).includes('قدیمی‌اند'), 'when the API says the data is stale the screen warns about it'); await page.unroute('**/api/assistant');
    ok(await page.$eval('#as-send', b => !b.disabled) && await page.$eval('#as-clear', b => !b.disabled), 'controls are enabled after all of this');
    await page.context().close(); beh.mode = 'ok';
  });

  await browser.close(); server.close();
}

console.log(`\n${pass} passed, ${fail} failed${skipped ? ' (browser tests SKIPPED: no Playwright/Chromium)' : ''}`);
process.exit(fail ? 1 : 0);
