// HTTP-level tests for POST /api/assistant, GET /api/assistant/history, POST /api/assistant/clear (src/index.js + src/assistant.js).
// LOCAL ONLY: the Workers AI binding is a mock; D1 is the project's in-memory store or a real SQLite engine (node:sqlite) behind a D1-shaped adapter.
// Page data comes from the project's own public/seed-public-reels.json through the real POST /api/import route. No Cloudflare, no Instagram, no network.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { handle } from '../src/index.js';
import { getStore, D1Store, MemoryStore } from '../src/store.js';
let pass = 0, fail = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };

const KEY = 'a-long-random-test-key-1234';
const SECRETS = { ADMIN_KEY: KEY, TOKEN_ENC_KEY: 'sec-enc-key-0p9o8i7u6y5t4r3e', META_APP_SECRET: 'sec-meta-app-1q2w3e4r5t6y7u', IG_ACCESS_TOKEN: 'sec-ig-token-a1b2c3d4e5f6g7h8i9j0' };
const NOW = Date.parse('2026-10-11T09:00:00Z');
const seed = JSON.parse(readFileSync(new URL('../public/seed-public-reels.json', import.meta.url))).items;
const seedViews = new Set(seed.map(i => +i.views));
const SID_RE = /^ses_[0-9a-f]{32}$/;
const resetMem = () => { globalThis.__ige_mem = undefined; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

// mock Workers AI binding. The planner also calls AI when it builds the daily plan, so `calls` records only ASSISTANT calls (identified by the
// assistant system prompt) and `other` records the rest. `impl` (if given) is applied to both kinds, so failures are realistic.
const isAssistantCall = input => String(input?.messages?.[0]?.content ?? '').startsWith('You are the Persian-speaking assistant');
const mkEnv = (impl, extra = {}) => { const calls = [], other = []; const AI = { run: async (model, input) => { const a = isAssistantCall(input); (a ? calls : other).push({ model, input }); return impl ? await impl(model, input, (a ? calls : other).length) : { response: a ? 'پاسخ ' + calls.length : 'تحلیل آزمایشی' }; } }; return { env: { ...SECRETS, AI, ALLOW_MEMORY_STORE: '1', ...extra }, calls, other }; };
const call = async (env, path, { method = 'GET', body, key = KEY, headers = {}, now = NOW, raw } = {}) => {
  const h = { ...headers }; if (key !== null) h['x-admin-key'] = key;
  const r = await handle(new Request('http://x' + path, { method, headers: h, body: raw ?? (body === undefined ? undefined : JSON.stringify(body)) }), env, { now });
  const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: r.status, json, text };
};
const post = (env, path, body, o = {}) => call(env, path, { method: 'POST', body, ...o });
const importSeed = (env, o = {}) => post(env, '/api/import', { items: seed }, o);
const rowsOf = () => [...(globalThis.__ige_mem?.m.values() ?? [])];
const assistantRows = () => rowsOf().filter(v => v.t.startsWith('assistant.'));
const sysOf = c => c.input.messages[0].content;
const dataJson = c => { try { return JSON.parse(sysOf(c).split('PAGE DATA (JSON): ')[1]); } catch { return null; } }; // null = the prompt tail is not clean JSON

console.log('\n1. authentication: every assistant route sits behind it');
{
  resetMem(); const { env, calls } = mkEnv(); const sid = 'ses_' + 'a'.repeat(32);
  for (const [name, args] of [['no key', { key: null }], ['wrong key', { key: 'wrong-key-wrong-key-123' }], ['empty key', { key: '' }], ['key with different case', { key: KEY.toUpperCase() }], ['key + extra char', { key: KEY + 'x' }]]) {
    const a = await post(env, '/api/assistant', { message: 'سلام' }, args), b = await call(env, '/api/assistant/history?sessionId=' + sid, args), c = await post(env, '/api/assistant/clear', { sessionId: sid }, args);
    ok(a.status === 401 && b.status === 401 && c.status === 401, `${name}: POST /api/assistant, GET history and POST clear all → 401`);
  }
  ok(calls.length === 0 && assistantRows().length === 0 && rowsOf().length === 0, 'unauthenticated requests never reached the AI and wrote nothing to storage');
  let r = await post(mkEnv(null, { ADMIN_KEY: undefined }).env, '/api/assistant', { message: 'سلام' }); ok(r.status === 503, 'ADMIN_KEY not configured → 503 (not open access)');
  r = await post(mkEnv(null, { ADMIN_KEY: 'short' }).env, '/api/assistant', { message: 'سلام' }); ok(r.status === 503, 'ADMIN_KEY shorter than 16 chars → 503');
  r = await post(env, '/api/assistant', { message: 'سلام' }); ok(r.status === 200 && r.json.ok === true, 'correct key → 200');
  ok((await call(env, '/api/health', { key: null })).status === 200, '/api/health is still public (unchanged)');
}

console.log('\n2. happy path with real stored data');
{
  resetMem(); const { env, calls } = mkEnv(); await importSeed(env);
  let r = await post(env, '/api/assistant', { message: 'چرا ریلزم دیده نمی‌شود؟' });
  ok(r.status === 200 && r.json.ok && SID_RE.test(r.json.sessionId) && r.json.reply === 'پاسخ 1' && r.json.saved === true && r.json.hasData === true, 'first message: reply + server-issued random sessionId + hasData=true');
  const sid = r.json.sessionId;
  r = await post(env, '/api/assistant', { message: 'ایده بده', sessionId: sid });
  ok(r.json.sessionId === sid && calls[1].input.messages.length === 4, 'second message with the same sessionId carries the first turn to the model');
  const h = await call(env, '/api/assistant/history?sessionId=' + sid);
  ok(h.status === 200 && h.json.messages.length === 4 && h.json.messages.map(m => m.role).join() === 'user,assistant,user,assistant' && h.json.messages[3].content === 'پاسخ 2', 'GET history returns the conversation in order');
  const cl = await post(env, '/api/assistant/clear', { sessionId: sid }); const h2 = await call(env, '/api/assistant/history?sessionId=' + sid);
  ok(cl.status === 200 && cl.json.ok === true && h2.json.messages.length === 0, 'POST clear empties it');
  const r2 = await post(env, '/api/assistant', { message: 'ایده بده' }); ok(r2.json.sessionId !== sid, 'without sessionId a NEW random id is issued each time');
  const co = await post(env, '/api/coach', { q: 'این هفته چه تغییری بدهم؟' }); ok(co.status === 200 && typeof co.json.answer === 'string', 'existing /api/coach still works');
  const dash = await call(env, '/api/dashboard'); ok(dash.status === 200 && dash.json.todaysReels?.length === 5, 'existing /api/dashboard still works');
}

console.log('\n3. accounts and sessions are isolated (account comes only from the existing scoped() mechanism)');
{
  resetMem(); const { env, calls } = mkEnv(); await importSeed(env, { headers: { 'x-account': 'acc1' } });
  const sid = 'ses_' + 'b'.repeat(32);
  await post(env, '/api/assistant', { message: 'حساب یک', sessionId: sid }, { headers: { 'x-account': 'acc1' } });
  await post(env, '/api/assistant', { message: 'حساب دو', sessionId: sid }, { headers: { 'x-account': 'acc2' } });
  await post(env, '/api/assistant', { message: 'حساب اصلی', sessionId: sid });
  const hist = async (acct, how = 'header') => (await call(env, '/api/assistant/history?sessionId=' + sid + (how === 'query' ? '&account=' + acct : ''), { headers: how === 'header' && acct ? { 'x-account': acct } : {} })).json.messages.map(m => m.content);
  ok((await hist('acc1')).join('|').startsWith('حساب یک'), 'account 1 history (x-account header)');
  ok((await hist('acc2')).join('|').startsWith('حساب دو') && !(await hist('acc2')).includes('حساب یک'), 'account 2 with the SAME session id sees only its own turn');
  ok((await hist('acc1', 'query')).join('|').startsWith('حساب یک'), 'account can also come from ?account= (existing mechanism)');
  ok((await hist(null)).includes('حساب اصلی') && !(await hist(null)).includes('حساب یک') && !(await hist(null)).includes('حساب دو'), 'main account is separate from both');
  ok((await hist('acc3')).length === 0, 'a third account guessing the session id gets an empty history');
  const tbls = assistantRows().map(v => v.t).sort(); ok(tbls.includes(`assistant.${sid}@acc1`) && tbls.includes(`assistant.${sid}@acc2`) && tbls.includes(`assistant.${sid}`), 'rows are stored under assistant.<session>@<account> (unsuffixed for main)');
  await post(env, '/api/assistant/clear', { sessionId: sid }, { headers: { 'x-account': 'acc1' } });
  ok((await hist('acc1')).length === 0 && (await hist('acc2')).length > 0 && (await hist(null)).length > 0, 'clear on account 1 does not touch account 2 or main');
  const other = await post(env, '/api/assistant', { message: 'نشست دیگر', sessionId: 'ses_' + 'c'.repeat(32) }, { headers: { 'x-account': 'acc2' } });
  ok(other.status === 200 && calls.at(-1).input.messages.length === 2, 'a different session of the same account starts with an empty history');
  const before = assistantRows().length; const hack = await post(env, '/api/assistant', { message: 'x', sessionId: 'ses_' + 'a'.repeat(31) + '@acc1' }); ok(hack.status === 400 && assistantRows().length === before, 'a session id cannot carry an account name (@acc1) → 400');
  const badAcct = await post(env, '/api/assistant', { message: 'x' }, { headers: { 'x-account': '../etc;DROP' } }); ok(badAcct.status === 400, 'invalid account name → 400 (existing validation)');
  ok(dataJson(calls[0])?.lastReels?.length > 0, 'account 1 (imported data) → prompt has real reels');
  const nd = calls[1]; ok(dataJson(nd)?.lastReels?.length === 0, 'account 2 never saw account 1\'s imported reels (page data is scoped too)');
}

console.log('\n4. rate limit (shared with /api/coach, applied only when an answer would be generated)');
{
  resetMem(); let { env, calls } = mkEnv(null, { RATE_LIMIT_PER_MIN: '3' });
  for (let i = 0; i < 5; i++) await post(env, '/api/assistant', { message: '   ' }); // invalid → must not consume budget
  const r = []; for (let i = 0; i < 4; i++) r.push(await post(env, '/api/assistant', { message: 'سلام ' + i }));
  ok(r.slice(0, 3).every(x => x.status === 200) && r[3].status === 429 && /rate limit/.test(r[3].json.error), 'limit 3/min: 3 answers, the 4th → 429 (invalid requests did not use up the budget)');
  ok(calls.length === 3, 'the 429 request never reached the AI');
  const sid = r[0].json?.sessionId;
  ok((await call(env, '/api/assistant/history?sessionId=' + sid)).status === 200 && (await post(env, '/api/assistant/clear', { sessionId: sid })).status === 200, 'history and clear are not rate limited');
  const later = await post(env, '/api/assistant', { message: 'بعد از یک دقیقه' }, { now: NOW + 61000 }); ok(later.status === 200, 'budget resets in the next minute');
  resetMem(); ({ env, calls } = mkEnv(null, { RATE_LIMIT_PER_MIN: '2' })); await importSeed(env);
  await post(env, '/api/coach', { q: 'این هفته' }); await post(env, '/api/assistant', { message: 'a' }); const third = await post(env, '/api/assistant', { message: 'b' });
  ok(third.status === 429, 'coach + assistant share one AI budget (same kv/rl:ai record)');
}

console.log('\n5. invalid input, long messages, big bodies');
{
  resetMem(); const { env, calls } = mkEnv(); const base = { sessionId: 'ses_' + 'd'.repeat(32) };
  for (const [name, body] of [['no message', {}], ['empty message', { message: '' }], ['whitespace message', { message: ' \n\t ' }], ['number message', { message: 5 }], ['array message', { message: ['a'] }], ['null message', { message: null }], ['object message', { message: { a: 1 } }], ['2001 chars', { message: 'ا'.repeat(2001) }], ['150k chars (below body cap)', { message: 'ا'.repeat(150000) }]]) {
    const x = await post(env, '/api/assistant', { ...base, ...body }); ok(x.status === 400 && !!x.json?.error, `${name} → 400`);
  }
  ok(calls.length === 0 && assistantRows().length === 0, 'none of them reached the AI or wrote history');
  ok((await post(env, '/api/assistant', { ...base, message: 'ا'.repeat(2000) })).status === 200, 'exactly 2000 chars accepted');
  for (const bad of [null, 5, '', 'ses_1', 'x'.repeat(36), 'SES_' + 'a'.repeat(32), 'ses_' + 'A'.repeat(32), ['ses_' + 'a'.repeat(32)], { a: 1 }, 'ses_' + 'a'.repeat(32) + '/../x']) {
    const x = await post(env, '/api/assistant', { message: 'سلام', sessionId: bad }), y = await post(env, '/api/assistant/clear', { sessionId: bad });
    ok(x.status === 400 && y.status === 400, `sessionId ${JSON.stringify(bad)} → 400 on assistant and clear`);
  }
  ok((await call(env, '/api/assistant/history')).status === 400 && (await call(env, '/api/assistant/history?sessionId=bad')).status === 400, 'history without / with bad sessionId → 400');
  ok((await post(env, '/api/assistant/clear', {})).status === 400, 'clear without sessionId → 400');
  ok((await post(env, '/api/assistant', undefined, { raw: '{not json' })).status === 400, 'invalid JSON → 400');
  ok((await post(env, '/api/assistant', undefined, { raw: '[1,2]' })).status === 400 && (await post(env, '/api/assistant', undefined, { raw: 'null' })).status === 400, 'JSON array / null body → 400');
  const big = await post(env, '/api/assistant', undefined, { raw: JSON.stringify({ message: 'ا'.repeat(250000) }) }); ok(big.status === 413, 'body over MAX_BODY (200 000) → 413');
  for (const [m, p] of [['GET', '/api/assistant'], ['PUT', '/api/assistant'], ['DELETE', '/api/assistant'], ['POST', '/api/assistant/history'], ['GET', '/api/assistant/clear'], ['POST', '/api/assistant/other']]) { const x = await call(env, p, { method: m, body: m === 'GET' ? undefined : {} }); ok(x.status === 404, `${m} ${p} → 404`); }
  ok(calls.length === 1, 'still only the one valid request reached the AI');
}

console.log('\n6. AI errors');
{
  resetMem(); let { env, calls } = mkEnv(() => { throw new Error('model offline sk-leaked-1234567890 ' + KEY); });
  let r = await post(env, '/api/assistant', { message: 'سلام', sessionId: 'ses_' + 'e'.repeat(32) });
  ok(r.status === 502 && r.json.code === 'AI_ERROR' && r.json.error === 'AI request failed', 'AI throws → 502 AI_ERROR, controlled message');
  ok(!r.text.includes('sk-leaked') && !r.text.includes('model offline') && !r.text.includes(KEY), 'the raw AI error text is never forwarded');
  ok(assistantRows().length === 0, 'nothing is stored after an AI failure');
  ({ env } = mkEnv(() => ({ response: '  ' }))); r = await post(env, '/api/assistant', { message: 'سلام' }); ok(r.status === 502 && r.json.code === 'EMPTY_RESPONSE' && !('reply' in r.json), 'empty AI answer → 502 EMPTY_RESPONSE, no invented reply');
  ({ env } = mkEnv(() => ({ response: { weird: 1 } }))); r = await post(env, '/api/assistant', { message: 'سلام' }); ok(r.status === 502 && !('reply' in r.json), 'malformed AI answer → 502, no reply');
  const noAI = mkEnv().env; delete noAI.AI; r = await post(noAI, '/api/assistant', { message: 'سلام' }); ok(r.status === 503 && r.json.code === 'NOT_CONNECTED' && r.json.error === 'AI NOT CONNECTED', 'no AI binding → 503 NOT_CONNECTED');
  let fetched = 0; const rf = globalThis.fetch; globalThis.fetch = async () => { fetched++; return new Response('{}'); };
  const paid = mkEnv(null, { ANTHROPIC_API_KEY: 'sk-test-not-real' }).env; delete paid.AI; r = await post(paid, '/api/assistant', { message: 'سلام' }); globalThis.fetch = rf;
  ok(r.status === 503 && r.json.code === 'UNSUPPORTED_PROVIDER' && fetched === 0, 'Anthropic-only env → 503, no paid API request is made');
  const longSys = mkEnv(() => ({ response: 'کلمه. '.repeat(700) })).env; r = await post(longSys, '/api/assistant', { message: 'سلام' }); ok(r.status === 200 && r.json.reply.length <= 2000, 'over-long AI answer is cut to ≤ 2000 chars');
}

console.log('\n7. D1 errors (real SQL engine behind a D1-shaped adapter with injected failures)');
{
  const db = new DatabaseSync(':memory:'); db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
  const f = { assistantList: false, assistantPut: false, assistantDel: false, all: false };
  const wrap = { prepare(sql) { if (f.all) throw new Error('simulated total outage ' + KEY); const st = db.prepare(sql); let args = []; const isA = () => String(args[0] ?? '').startsWith('assistant.'); const o = { bind(...a) { args = a; return o; },
    async run() { if ((f.assistantPut && /^INSERT/.test(sql) && isA()) || (f.assistantDel && /^DELETE/.test(sql) && isA())) throw new Error('simulated write failure /secret/path'); st.run(...args); return { success: true }; },
    async first() { return st.get(...args) ?? null; }, async all() { if (f.assistantList && isA()) throw new Error('simulated read failure /secret/path'); return { results: st.all(...args) }; } }; return o; } };
  const { env, calls } = mkEnv(null, { DB: wrap, ALLOW_MEMORY_STORE: undefined }); const sid = 'ses_' + 'f'.repeat(32);
  await post(env, '/api/import', { items: seed }); let r = await post(env, '/api/assistant', { message: 'سلام', sessionId: sid });
  ok(r.status === 200 && r.json.saved === true, 'baseline on the real SQL engine works (plan + history persisted)');
  f.assistantList = true; r = await post(env, '/api/assistant', { message: 'دوباره', sessionId: sid });
  ok(r.status === 503 && r.json.code === 'D1_ERROR' && r.json.error === 'history storage error' && calls.length === 1 && !r.text.includes('secret/path'), 'history read failure → 503, AI not called, no raw error text');
  const h = await call(env, '/api/assistant/history?sessionId=' + sid); ok(h.status === 503 && h.json.code === 'D1_ERROR' && !h.text.includes('secret/path'), 'GET history on read failure → 503 controlled');
  f.assistantList = false; f.assistantPut = true; r = await post(env, '/api/assistant', { message: 'ذخیره نمی‌شود', sessionId: sid });
  ok(r.status === 200 && r.json.saved === false && /not saved/.test(r.json.warning) && r.json.reply === 'پاسخ 2' && !r.text.includes('secret/path'), 'save failure → the answer is still delivered, saved:false + warning, no raw error');
  f.assistantPut = false; f.assistantDel = true; const c = await post(env, '/api/assistant/clear', { sessionId: sid });
  ok(c.status === 503 && c.json.code === 'D1_ERROR' && !c.text.includes('secret/path') && db.prepare('SELECT COUNT(*) c FROM records WHERE tbl=?').get('assistant.' + sid).c === 1, 'delete failure → 503, history is still there (no false "cleared")');
  f.assistantDel = false; f.all = true;
  for (const [n, x] of [['assistant', await post(env, '/api/assistant', { message: 'x', sessionId: sid })], ['history', await call(env, '/api/assistant/history?sessionId=' + sid)], ['clear', await post(env, '/api/assistant/clear', { sessionId: sid })]])
    ok(x.status >= 500 && x.status < 600 && x.json && !x.text.includes(KEY), `total D1 outage on ${n} → controlled JSON 5xx, no ADMIN_KEY in the body`);
  const a = await post(env, '/api/assistant', { message: 'x', sessionId: sid }); ok(a.status === 503 && a.json.code === 'D1_ERROR' && !a.text.includes('simulated'), 'POST /api/assistant under a total outage is a clean 503 (no raw error text)');
  f.all = false; ok((await post(env, '/api/assistant', { message: 'برگشت', sessionId: sid })).status === 200, 'service recovers when D1 recovers');
}

console.log('\n8. no invented statistics');
{
  resetMem(); const { env, calls } = mkEnv(); await importSeed(env, { headers: { 'x-account': 'withdata' } });
  const a = await post(env, '/api/assistant', { message: 'آمار پیجم چیه؟' }, { headers: { 'x-account': 'withdata' } }), b = await post(env, '/api/assistant', { message: 'آمار پیجم چیه؟' }, { headers: { 'x-account': 'nodata' } });
  ok(a.json.hasData === true && b.json.hasData === false, 'hasData reflects whether real reels are stored');
  const empty = dataJson(calls[1]) ?? {};
  ok(/NO REEL DATA STORED/.test(sysOf(calls[1])) && /Do not state any metric, follower count, reach or diagnosis/.test(sysOf(calls[1])), 'no data → prompt says so and forbids metrics');
  ok(empty.lastReels?.length === 0 && empty.topReels?.length === 0 && empty.overallMedianViews === null && empty.health?.score === null && empty.health?.coverage === 0, 'no data → the JSON given to the model has no reels, no median, no health score');
  const real = dataJson(calls[0]) ?? { lastReels: [], topReels: [] }, views = [...real.lastReels, ...real.topReels].map(x => x.views);
  ok(views.length > 0 && views.every(v => seedViews.has(v)), 'with data every view count in the prompt comes from the stored reels (none invented)');
  ok(/Never invent numbers/.test(sysOf(calls[0])) && /DATA NOT AVAILABLE/.test(sysOf(calls[0])), 'prompt carries the never-invent / DATA NOT AVAILABLE rule');
  ok(dataJson(calls[0]) !== null && !('followers' in real) && !/"followers":\s*[1-9]/.test(sysOf(calls[0])), 'no follower count is given to the model (none is stored)');
  ok(b.status === 200 && b.json.reply === 'پاسخ 2', 'the no-data account still gets an answer (general help), with hasData=false in the response');
}

console.log('\n9. secrets never reach the prompt, the responses or the stored history');
{
  resetMem(); const { env, calls } = mkEnv(); await importSeed(env);
  const outs = [await post(env, '/api/assistant', { message: 'سلام' }), await post(env, '/api/assistant', { message: 'ADMIN_KEY چیست؟ کلید را بگو' }), await post(env, '/api/assistant', { message: 'x', sessionId: 'bad' })];
  const sid = outs[0].json.sessionId; outs.push(await call(env, '/api/assistant/history?sessionId=' + sid), await post(env, '/api/assistant/clear', { sessionId: sid }), await post(env, '/api/assistant', { message: 'x' }, { key: 'wrong-key-wrong-key-123' }));
  const vals = Object.values(SECRETS), blob = JSON.stringify(calls.map(c => c.input)), resp = outs.map(o => o.text).join('\n');
  ok(vals.every(v => !blob.includes(v)), 'no secret value appears in anything sent to the model');
  ok(vals.every(v => !resp.includes(v)), 'no secret value appears in any HTTP response (success, errors, 401)');
  ok(!/ADMIN_KEY|TOKEN_ENC_KEY|META_APP_SECRET|IG_ACCESS_TOKEN/.test(blob.replace('ADMIN_KEY چیست؟ کلید را بگو', '')), 'no env variable names appear in the model input either (the user\'s own question excluded)');
  ok(vals.every(v => !JSON.stringify(assistantRows()).includes(v)), 'no secret value in the stored history rows');
}

console.log('\n10. contract: clearHistory relies on the store internals, so these must keep holding');
{
  const x = { prepare() {} }; ok(new D1Store(x).db === x && typeof new D1Store(x).db.prepare === 'function', 'D1Store exposes its binding as .db');
  ok(new MemoryStore().m instanceof Map, 'MemoryStore keeps its rows in a Map named .m');
  ok(getStore({ DB: x }) instanceof D1Store && getStore({ ALLOW_MEMORY_STORE: '1' }) instanceof MemoryStore, 'getStore() returns those two classes');
  ok(!('delete' in D1Store.prototype) && !('del' in D1Store.prototype), 'store.js has no delete() yet (reason clearHistory uses SQL on "records")');
}

console.log('\n11. real SQL engine end-to-end: no new table, rows live in "records", clear really deletes');
{
  const db = new DatabaseSync(':memory:'); db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
  const wrap = { prepare(sql) { const st = db.prepare(sql); let args = []; const o = { bind(...a) { args = a; return o; }, async run() { st.run(...args); return { success: true }; }, async first() { return st.get(...args) ?? null; }, async all() { return { results: st.all(...args) }; } }; return o; } };
  const tables = () => db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name).join();
  const before = tables(); const { env } = mkEnv(null, { DB: wrap, ALLOW_MEMORY_STORE: undefined }); const sid = 'ses_' + '1'.repeat(32);
  await post(env, '/api/import', { items: seed }, { headers: { 'x-account': 'pg' } });
  for (const acct of ['pg', 'main']) await post(env, '/api/assistant', { message: 'سلام ' + acct, sessionId: sid }, { headers: acct === 'main' ? {} : { 'x-account': acct } });
  ok(tables() === before, `no table created (tables: ${tables()})`);
  const t = db.prepare("SELECT tbl FROM records WHERE tbl LIKE 'assistant.%' ORDER BY tbl").all().map(r => r.tbl); ok(t.join() === `assistant.${sid},assistant.${sid}@pg`, 'one row set for main and one for @pg, both in "records"');
  await post(env, '/api/assistant/clear', { sessionId: sid }, { headers: { 'x-account': 'pg' } });
  ok(db.prepare("SELECT tbl FROM records WHERE tbl LIKE 'assistant.%'").all().map(r => r.tbl).join() === `assistant.${sid}`, 'clear deletes the @pg rows and leaves main\'s');
  ok(db.prepare("SELECT COUNT(*) c FROM records WHERE tbl NOT LIKE 'assistant.%'").get().c > 0, 'other project data is untouched');
}

console.log('\n12. single-file bundle (dist/worker.js) behaves the same');
{
  resetMem(); const mod = await import('../dist/worker.js'); const { env, calls } = mkEnv();
  const go = async (path, o = {}) => { const h = { ...(o.key === null ? {} : { 'x-admin-key': KEY }) }; const r = await mod.default.fetch(new Request('http://x' + path, { method: o.method || 'GET', headers: h, body: o.body ? JSON.stringify(o.body) : undefined }), env); const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch { /* */ } return { status: r.status, json, text }; };
  ok((await go('/api/assistant', { method: 'POST', body: { message: 'سلام' }, key: null })).status === 401, 'bundle: no key → 401');
  await go('/api/import', { method: 'POST', body: { items: seed } }); const r = await go('/api/assistant', { method: 'POST', body: { message: 'سلام' } });
  ok(r.status === 200 && SID_RE.test(r.json?.sessionId) && r.json?.hasData === true && r.json?.reply === 'پاسخ 1', 'bundle: assistant answers with real stored data');
  const h = await go('/api/assistant/history?sessionId=' + r.json?.sessionId); ok(h.json?.messages?.length === 2, 'bundle: history works');
  ok((await go('/api/assistant/clear', { method: 'POST', body: { sessionId: r.json?.sessionId } })).json?.ok === true, 'bundle: clear works');
  ok(calls.length === 1 && !JSON.stringify(calls[0].input).includes(KEY), 'bundle: one AI call, no secret in the prompt');
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
