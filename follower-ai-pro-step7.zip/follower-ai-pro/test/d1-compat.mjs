// Verifies schema.sql + D1Store SQL against a real SQLite engine through a D1-shaped adapter.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { D1Store } from '../src/store.js';
import { handle } from '../src/index.js';
const db = new DatabaseSync(':memory:');
const wrap = {
  prepare(sql) { const st = db.prepare(sql); let args = []; const o = {
    bind(...a) { args = a; return o; },
    async run() { st.run(...args); return { success: true }; },
    async first() { return st.get(...args) ?? null; },
    async all() { return { results: st.all(...args) }; } }; return o; },
};
let fail = 0; const ok = (c, n) => { console.log((c ? '  PASS ' : '  FAIL ') + n); if (!c) fail++; };
const s = new D1Store(wrap);
ok((await s.check()).ok === false, 'check() reports missing table before schema');
db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
db.exec(readFileSync(new URL('../migrations/0001_init.sql', import.meta.url), 'utf8')); // idempotent
ok((await s.check()).ok === true, 'check() OK after schema.sql');
await s.put('media', 'a', { x: 1 }, 5); await s.put('media', 'a', { x: 2 }, 6); await s.put('media', 'b', { x: 3 }, 7);
ok((await s.get('media', 'a')).x === 2, 'upsert overwrites same key');
ok((await s.list('media')).map(r => r.x).join() === '3,2', 'list ordered by ts DESC');
ok((await s.get('media', 'zzz')) === null, 'missing key → null');
const env = { ADMIN_KEY: 'a-long-random-test-key-1234', DB: wrap };
const call = async p => { const r = await handle(new Request('http://x' + p, { headers: { 'x-admin-key': 'a-long-random-test-key-1234' } }), env); return r.json(); };
const h = await call('/api/health'); ok(h.worker === 'OK' && h.d1 === 'OK', 'health: Worker OK, D1 OK');
const sys = await call('/api/system');
ok(sys.d1.status === 'OK' && sys.instagram.status === 'NOT CONNECTED' && sys.instagram.data === 'DATA NOT AVAILABLE' && sys.ai.status === 'NOT CONNECTED', 'system: IG NOT CONNECTED + DATA NOT AVAILABLE, AI NOT CONNECTED');
const dash = await call('/api/dashboard'); if (!dash.growthHealth) console.log(JSON.stringify(dash).slice(0,300)); ok(dash.growthHealth.score === null && dash.todaysReels.length === 5, 'dashboard on real SQL engine works with empty data');
const dash2 = await call('/api/dashboard'); ok(dash2.mission.headline === dash.mission.headline, 'plan persisted in D1 (stable on reload)');
console.log(fail ? 'D1 COMPAT FAILED' : 'D1 COMPAT OK'); process.exit(fail ? 1 : 0);
