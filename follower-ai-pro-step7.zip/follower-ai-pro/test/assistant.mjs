// Tests for src/assistant.js. Everything is LOCAL: the Workers AI binding is a mock, D1 is either the project's in-memory store
// or a real SQLite engine (node:sqlite) behind a D1-shaped adapter, as in test/d1-compat.mjs. Nothing real (Cloudflare, Instagram) is contacted.
// Page data fixtures: the project's own public/seed-public-reels.json, normalised like /api/import does. No numbers are invented here.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { newSessionId, isSessionId, loadHistory, saveTurn, clearHistory, assistantReply, ASSISTANT_MAX_CHARS, ASSISTANT_KEEP_TURNS, ASSISTANT_HISTORY_MESSAGES } from '../src/assistant.js';
import { getStore, scoped } from '../src/store.js';
import { analyzeAll, makePlan, weeklyReport, tehranDate } from '../src/planner.js';
let pass = 0, fail = 0; const ok = (c, n, x = '') => { c ? pass++ : fail++; console.log((c ? '  PASS ' : '  FAIL ') + n + (c ? '' : '  ' + x)); };

const NOW = Date.parse('2026-10-11T09:00:00Z');
const seed = JSON.parse(readFileSync(new URL('../public/seed-public-reels.json', import.meta.url))).items;
const n = v => (v == null || v === '' || isNaN(+v)) ? null : +v;
const norm = it => ({ id: String(it.id), source: 'public-scrape', type: it.type || 'REEL', ts: Date.parse(it.date + 'T12:00:00Z'), hasTime: false, caption: it.caption || '', permalink: null, durationSec: n(it.durationSec), metrics: { views: n(it.views), reach: n(it.reach), likes: n(it.likes), comments: n(it.comments), shares: n(it.shares), saves: n(it.saves), avgWatchSec: null, totalWatchSec: null }, fetchedAt: NOW });
const build = media => { const A = analyzeAll({ media, daily: [], stories: [], now: NOW }); const plan = makePlan({ date: tehranDate(NOW), A, pastIdeas: [], prevPlan: null, bestHourInfo: { hour: null }, now: NOW }); const weekly = weeklyReport({ all: A.all, daily: [], stories: [], profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now: NOW }); return { A, plan, weekly }; };
const REAL = build(seed.map(norm)), EMPTY = build([]);
const maxViews = Math.max(...seed.map(i => +i.views));

// mock Workers AI binding (records calls, tracks parallelism)
const mkEnv = (impl, extra = {}) => { const calls = []; const st = { inflight: 0, max: 0 }; const AI = { run: async (model, input) => { calls.push({ model, input }); st.inflight++; st.max = Math.max(st.max, st.inflight); try { return impl ? await impl(model, input, calls.length) : { response: 'پاسخ ' + calls.length }; } finally { st.inflight--; } } }; return { env: { AI, ALLOW_MEMORY_STORE: '1', ...extra }, calls, st }; };
const resetMem = () => { globalThis.__ige_mem = undefined; };
const ctxArgs = (D = REAL) => ({ A: D.A, plan: D.plan, weekly: D.weekly });
const ask = (store, env, sid, message, D = REAL, now = NOW) => assistantReply({ store, env, sid, message, ...ctxArgs(D), now });
const sleep = ms => new Promise(r => setTimeout(r, ms));

console.log('\nA. session ids');
{
  const ids = new Set(Array.from({ length: 2000 }, newSessionId));
  ok(ids.size === 2000 && [...ids].every(isSessionId), '2000 generated ids are all unique and valid');
  const s = newSessionId(); ok(/^ses_[0-9a-f]{32}$/.test(s), 'format ses_ + 32 hex chars (128 random bits)');
  for (const bad of [null, undefined, 42, '', 'ses_1', 'ses_' + 'A'.repeat(32), 'ses_' + 'a'.repeat(31), 'ses_' + 'a'.repeat(33), 'x_' + 'a'.repeat(32), 'ses_' + 'a'.repeat(31) + '/', '../' + s, s + '\n', ' ' + s])
    ok(!isSessionId(bad), `rejected as session id: ${JSON.stringify(bad)}`);
  resetMem(); const { env } = mkEnv(); const store = getStore(env);
  for (const bad of ['ses_1', null, 'x']) { const r = await loadHistory(store, bad); ok(r.ok === false && r.reason === 'INVALID_SESSION', `loadHistory(${JSON.stringify(bad)}) → INVALID_SESSION`); }
}

console.log('\nB. context comes from real stored data');
{
  const SECRETS = { ADMIN_KEY: 'sec-admin-key-9f8e7d6c5b4a', IG_ACCESS_TOKEN: 'sec-ig-token-1a2b3c4d5e6f', TOKEN_ENC_KEY: 'sec-enc-key-0p9o8i7u6y5t' };
  resetMem(); const { env, calls } = mkEnv(null, SECRETS); const store = getStore(env), sid = newSessionId();
  ok(REAL.A.reels.length > 0, `fixture: ${REAL.A.reels.length} reels from the project seed file`);
  const r = await ask(store, env, sid, 'چرا ریلزم دیده نمی‌شود؟');
  ok(r.ok === true && r.hasData === true && r.reply === 'پاسخ 1' && r.sessionId === sid && r.saved === true, 'reply returned and saved with real data');
  const sys = calls[0].input.messages[0];
  ok(sys.role === 'system' && sys.content.includes(REAL.A.reels.length + ' reels with stored stats'), 'system prompt states how many reels are stored');
  ok(sys.content.includes('"views":' + maxViews), 'system prompt contains the real top view count from stored data');
  ok(/Never invent numbers/.test(sys.content) && /DATA NOT AVAILABLE/.test(sys.content), 'system prompt forbids invented numbers');
  ok(Object.values(SECRETS).every(v => !JSON.stringify(calls[0].input).includes(v)), 'none of the env secret VALUES (admin key, IG token, encryption key) appear anywhere in what is sent to the model');
  ok(!/ADMIN_KEY|IG_ACCESS_TOKEN|TOKEN_ENC_KEY|ALLOW_MEMORY_STORE/.test(JSON.stringify(calls[0].input)), 'no env variable names appear in the prompt either');
  ok(calls[0].input.max_tokens === 500, 'model output capped (max_tokens 500)');
  ok(!/\b[Ff]ollowers?\b.{0,20}\d{3,}/.test(JSON.stringify(calls[0].input.messages[0].content).replace(/"followers":null/g, '')), 'no follower count appears in the prompt (none is stored)');
}

console.log('\nC. no real data → declared as missing, nothing made up');
{
  resetMem(); const { env, calls } = mkEnv(); const store = getStore(env), sid = newSessionId();
  const r = await ask(store, env, sid, 'تحلیل پیجم چیه؟', EMPTY);
  ok(r.ok === true && r.hasData === false, 'works without data and reports hasData=false');
  const sys = calls[0].input.messages[0].content;
  ok(/NO REEL DATA STORED/.test(sys) && /Do not state any metric, follower count, reach or diagnosis/.test(sys), 'system prompt tells the model there is no data and forbids metrics');
  ok(!/stored stats/.test(sys), 'no "reels with stored stats" claim when there are none');
}

console.log('\nD. history save and restore');
{
  resetMem(); const { env, calls } = mkEnv(); const store = getStore(env), sid = newSessionId();
  await ask(store, env, sid, 'سلام', REAL, NOW); await ask(store, env, sid, 'ایده ریل بده', REAL, NOW + 1000);
  const sent = calls[1].input.messages;
  ok(sent.length === 4 && sent[0].role === 'system' && JSON.stringify(sent.slice(1)) === JSON.stringify([{ role: 'user', content: 'سلام' }, { role: 'assistant', content: 'پاسخ 1' }, { role: 'user', content: 'ایده ریل بده' }]), 'second call carries system + first turn + new question, in order');
  const h = await loadHistory(store, sid);
  ok(h.ok && h.messages.length === 4 && h.messages.map(m => m.role).join() === 'user,assistant,user,assistant' && h.messages[3].content === 'پاسخ 2', 'loadHistory returns both turns, oldest first');
  const empty = await loadHistory(store, newSessionId()); ok(empty.ok && empty.messages.length === 0, 'unknown session → empty history');
  const c = await clearHistory(store, env, sid); const h2 = await loadHistory(store, sid);
  ok(c.ok && h2.ok && h2.messages.length === 0, 'clearHistory removes the conversation');
  await ask(store, env, sid, 'دوباره', REAL, NOW + 5000); ok(calls[2].input.messages.length === 2, 'after clear the model gets no old history');
}

console.log('\nE. history window: max 12 previous messages');
{
  resetMem(); const { env, calls } = mkEnv(); const store = getStore(env), sid = newSessionId();
  for (let i = 0; i < 10; i++) await saveTurn(store, sid, 'q' + i, 'a' + i, { now: NOW + i * 1000 });
  const h = await loadHistory(store, sid); ok(h.ok && h.messages.length === ASSISTANT_HISTORY_MESSAGES && ASSISTANT_HISTORY_MESSAGES === 12, 'loadHistory default returns at most 12 messages');
  ok(h.messages[0].content === 'q4' && h.messages[11].content === 'a9', 'it returns the NEWEST 12 (q4 … a9)');
  const wide = await loadHistory(store, sid, { limit: 50 }); ok(wide.messages.length === 20, 'limit 50 returns all 20 stored messages');
  for (const bad of [0, -1, 51, 1.5, '12', NaN]) { const r = await loadHistory(store, sid, { limit: bad }); ok(r.ok === false && /^INVALID_INPUT/.test(r.reason), `loadHistory limit=${String(bad)} rejected`); }
  await ask(store, env, sid, 'سؤال جدید', REAL, NOW + 99000);
  const sent = calls[0].input.messages; ok(sent.length === 1 + 12 + 1 && sent[1].content === 'q4' && sent[sent.length - 1].content === 'سؤال جدید', 'model receives system + 12 history messages + new question');
  const odd = await loadHistory(store, sid, { limit: 3 }); ok(odd.messages.length === 3 && odd.messages[0].role === 'assistant', 'odd limit works (3 newest messages)');
}

console.log('\nF. length limits and output validation');
{
  resetMem(); let { env, calls } = mkEnv(); let store = getStore(env), sid = newSessionId();
  let r = await ask(store, env, sid, 'ا'.repeat(2001)); ok(r.ok === false && /^INVALID_INPUT: message too long/.test(r.reason) && calls.length === 0, '2001-char message rejected, model not called');
  ok((await loadHistory(store, sid)).messages.length === 0, 'rejected message is not stored');
  r = await ask(store, env, sid, 'ا'.repeat(2000)); ok(r.ok === true, 'exactly 2000 chars accepted');
  for (const bad of ['', '   \n ', null, undefined, 5, {}]) { const x = await ask(store, env, newSessionId(), bad); ok(x.ok === false && /^INVALID_INPUT/.test(x.reason), `message ${JSON.stringify(bad) ?? 'undefined'} rejected`); }
  ok(calls.length === 1, 'invalid messages never reached the model');

  resetMem(); ({ env, calls } = mkEnv(() => ({ response: 'کلمه. '.repeat(600) }))); store = getStore(env); sid = newSessionId();
  r = await ask(store, env, sid, 'بنویس'); const saved = (await loadHistory(store, sid)).messages[1]?.content;
  ok(r.ok && r.reply.length <= ASSISTANT_MAX_CHARS && r.reply.length > 1200 && r.reply === saved, 'over-long model output is cut to ≤2000 chars and the saved text equals the returned text');
  ok(r.reply.endsWith('.'), 'cut happens at a sentence end');
  resetMem(); ({ env } = mkEnv(() => ({ response: 'a'.repeat(5000) }))); store = getStore(env);
  r = await ask(store, env, newSessionId(), 'x'); ok(r.ok && r.reply.length === ASSISTANT_MAX_CHARS && r.reply.endsWith('…'), 'no sentence end → hard cut with an ellipsis, exactly 2000 chars');
  resetMem(); ({ env } = mkEnv(() => ({ response: 'سلام\u0000\u0007 دنیا' }))); store = getStore(env);
  r = await ask(store, env, newSessionId(), 'x'); ok(r.ok && r.reply === 'سلام دنیا', 'control characters are stripped from model output');
  resetMem(); ({ env } = mkEnv(() => ({ response: '   ' }))); store = getStore(env); sid = newSessionId();
  r = await ask(store, env, sid, 'x'); ok(r.ok === false && r.reason === 'EMPTY_RESPONSE' && !('reply' in r) && (await loadHistory(store, sid)).messages.length === 0, 'empty model output → error, no reply, nothing saved');
}

console.log('\nG. accounts and sessions are isolated');
{
  resetMem(); const { env, calls } = mkEnv(); const base = getStore(env), a1 = scoped(base, 'acc1'), a2 = scoped(base, 'acc2');
  const sid = newSessionId(), sid2 = newSessionId();
  await ask(a1, env, sid, 'پیام حساب یک'); await ask(a2, env, sid, 'پیام حساب دو'); await ask(base, env, sid, 'پیام حساب اصلی'); await ask(a1, env, sid2, 'نشست دیگر');
  const h1 = await loadHistory(a1, sid), h2 = await loadHistory(a2, sid), hm = await loadHistory(base, sid), hs = await loadHistory(a1, sid2);
  ok(h1.messages.length === 2 && h1.messages[0].content === 'پیام حساب یک', 'account 1 sees only its own turn');
  ok(h2.messages.length === 2 && h2.messages[0].content === 'پیام حساب دو', 'account 2 with the SAME session id sees only its own turn');
  ok(hm.messages.length === 2 && hm.messages[0].content === 'پیام حساب اصلی', 'main account (unscoped) is separate too');
  ok(hs.messages.length === 2 && hs.messages[0].content === 'نشست دیگر' && h1.messages.every(m => m.content !== 'نشست دیگر'), 'a different session of the same account is separate');
  ok(calls.every(c => c.input.messages.length === 2), 'no call received another conversation as history');
  ok((await loadHistory(scoped(base, 'acc3'), sid)).messages.length === 0, 'guessing the session id from another account reveals nothing');
  const rows = [...base.m.values()].map(v => v.t).filter(t => t.startsWith('assistant.')); ok(rows.length === 4 && new Set(rows).size === 4 && rows.includes(`assistant.${sid}@acc1`) && rows.includes(`assistant.${sid}@acc2`) && rows.includes(`assistant.${sid}`), 'stored under assistant.<session>@<account> (unsuffixed for main)');
  await clearHistory(a1, env, sid);
  ok((await loadHistory(a1, sid)).messages.length === 0 && (await loadHistory(a2, sid)).messages.length === 2 && (await loadHistory(base, sid)).messages.length === 2 && (await loadHistory(a1, sid2)).messages.length === 2, 'clearHistory touches only that account + session');
}

console.log('\nH. concurrent requests');
{
  resetMem(); let { env, calls, st } = mkEnv(async (m, i, k) => { await sleep(25); return { response: 'پاسخ ' + k }; }); let store = getStore(env), sid = newSessionId();
  const [r1, r2, r3] = await Promise.all([ask(store, env, sid, 'اول', REAL, NOW), ask(store, env, sid, 'دوم', REAL, NOW), ask(store, env, sid, 'سوم', REAL, NOW)]);
  ok(st.max === 1, 'three requests on one session run one at a time');
  ok(r1.ok && r2.ok && r3.ok && calls[1].input.messages.length === 4 && calls[2].input.messages.length === 6, 'each later request sees the earlier turns (no lost context)');
  const h = await loadHistory(store, sid, { limit: 50 }); ok(h.messages.length === 6 && h.messages.map(m => m.content).join('|') === 'اول|پاسخ 1|دوم|پاسخ 2|سوم|پاسخ 3', 'all three turns stored, in order, even with an identical timestamp');
  resetMem(); ({ env, calls, st } = mkEnv(async () => { await sleep(25); return { response: 'ok' }; })); store = getStore(env);
  await Promise.all([ask(store, env, newSessionId(), 'a'), ask(store, env, newSessionId(), 'b'), ask(scoped(store, 'x'), env, newSessionId(), 'c')]);
  ok(st.max === 3, 'different sessions / accounts do not block each other');
  resetMem(); ({ env, st } = mkEnv(async () => { await sleep(10); throw new Error('boom'); })); store = getStore(env); sid = newSessionId();
  const f1 = await Promise.all([ask(store, env, sid, 'a'), ask(store, env, sid, 'b')]); const f2 = await ask(store, env, sid, 'c');
  ok(f1.every(x => x.ok === false) && f2.ok === false && st.max === 1, 'a failing request does not leave the session locked');
  resetMem(); ({ env } = mkEnv(async () => { await sleep(15); return { response: 'x' }; })); store = getStore(env); sid = newSessionId();
  const [rr, cc] = await Promise.all([ask(store, env, sid, 'q'), clearHistory(store, env, sid)]); const after = await loadHistory(store, sid);
  ok(rr.ok && cc.ok && after.messages.length === 0, 'clearHistory queued behind a running reply wins (history is empty afterwards)');
}

console.log('\nI. real SQL engine (node:sqlite behind a D1-shaped adapter)');
{
  const db = new DatabaseSync(':memory:'); db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
  const wrap = { prepare(sql) { const st = db.prepare(sql); let args = []; const o = { bind(...a) { args = a; return o; }, async run() { st.run(...args); return { success: true }; }, async first() { return st.get(...args) ?? null; }, async all() { return { results: st.all(...args) }; } }; return o; } };
  const tables = () => db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name).join();
  const before = tables(); const { env, calls } = mkEnv(null, { DB: wrap, ALLOW_MEMORY_STORE: undefined });
  const store = getStore(env), acc = scoped(store, 'pageA'), sid = newSessionId();
  ok(store.kind === 'cloudflare-d1', 'using the real D1Store code path');
  await ask(store, env, sid, 'سلام'); await ask(acc, env, sid, 'سلام حساب'); await ask(store, env, sid, 'ادامه', REAL, NOW + 2000);
  ok(tables() === before && before.includes('records'), `no table created or changed (tables: ${tables()})`);
  const rowsT = db.prepare("SELECT tbl, COUNT(*) c FROM records WHERE tbl LIKE 'assistant.%' GROUP BY tbl ORDER BY tbl").all();
  ok(rowsT.length === 2 && rowsT.find(r => r.tbl === 'assistant.' + sid).c === 2 && rowsT.find(r => r.tbl === `assistant.${sid}@pageA`).c === 1, 'rows live in "records": 2 turns for main, 1 for pageA');
  const h = await loadHistory(store, sid); ok(h.messages.length === 4 && h.messages[2].content === 'ادامه', 'history restored from SQL');
  ok(calls[2].input.messages.length === 4, 'third call received the stored first turn from SQL');
  await ask(store, env, newSessionId(), 'سشن دیگر');
  await clearHistory(store, env, sid);
  const left = db.prepare("SELECT tbl FROM records WHERE tbl LIKE 'assistant.%' ORDER BY tbl").all().map(r => r.tbl);
  ok(!left.includes('assistant.' + sid) && left.includes(`assistant.${sid}@pageA`) && left.length === 2, 'clearHistory really DELETEs rows for that session only (other account/session untouched)');
  const sid3 = newSessionId(); for (let i = 0; i < ASSISTANT_KEEP_TURNS + 5; i++) await saveTurn(store, sid3, 'q' + i, 'a' + i, { now: NOW + i * 1000, env });
  const cnt = db.prepare('SELECT COUNT(*) c, MIN(ts) mn FROM records WHERE tbl=?').get('assistant.' + sid3);
  ok(ASSISTANT_KEEP_TURNS === 60 && cnt.c === 60 && cnt.mn === NOW + 5 * 1000, 'pruning keeps the newest 60 turns per session');
  const last = await loadHistory(store, sid3); ok(last.messages.at(-1).content === 'a64', 'newest turn is still there after pruning');
  const other = db.prepare("SELECT COUNT(*) c FROM records WHERE tbl NOT LIKE 'assistant.%'").get().c; ok(other === 0, 'no non-assistant rows were touched');
}

console.log('\nJ. D1 errors');
{
  const db = new DatabaseSync(':memory:'); db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
  const flags = { list: false, put: false, del: false };
  const wrap = { prepare(sql) { const st = db.prepare(sql); let args = []; const o = { bind(...a) { args = a; return o; },
    async run() { if ((flags.put && /^INSERT/.test(sql)) || (flags.del && /^DELETE/.test(sql))) throw new Error('D1_ERROR: simulated write failure'); st.run(...args); return { success: true }; },
    async first() { return st.get(...args) ?? null; }, async all() { if (flags.list) throw new Error('D1_ERROR: simulated read failure'); return { results: st.all(...args) }; } }; return o; } };
  const { env, calls } = mkEnv(null, { DB: wrap, ALLOW_MEMORY_STORE: undefined }); const store = getStore(env), sid = newSessionId();
  flags.list = true; let r = await ask(store, env, sid, 'سلام');
  ok(r.ok === false && /^D1_ERROR/.test(r.reason) && calls.length === 0 && !('reply' in r), 'history read failure → D1_ERROR, model not called, no made-up answer');
  const lh = await loadHistory(store, sid); ok(lh.ok === false && /^D1_ERROR/.test(lh.reason), 'loadHistory reports the D1 error');
  flags.list = false; flags.put = true; r = await ask(store, env, sid, 'سلام');
  ok(r.ok === true && r.saved === false && /^D1_ERROR/.test(r.saveError) && r.reply === 'پاسخ 1', 'save failure → the answer is still returned, flagged saved:false with the error');
  const sv = await saveTurn(store, sid, 'a', 'b'); ok(sv.ok === false && /^D1_ERROR/.test(sv.reason), 'saveTurn reports the D1 error');
  flags.put = false; await ask(store, env, sid, 'سلام دوباره'); flags.del = true;
  const cl = await clearHistory(store, env, sid); ok(cl.ok === false && /^D1_ERROR/.test(cl.reason), 'clearHistory reports the D1 error and does not claim success');
  const stillThere = db.prepare('SELECT COUNT(*) c FROM records WHERE tbl=?').get('assistant.' + sid).c; ok(stillThere === 1, 'after a failed delete the data is still there');
  flags.del = false; db.prepare("INSERT INTO records(tbl,k,ts,data) VALUES(?,?,?,?)").run('assistant.' + sid, 'bad1', NOW + 10, JSON.stringify({ v: 1, ts: NOW + 10, user: 5, assistant: null }));
  db.prepare("INSERT INTO records(tbl,k,ts,data) VALUES(?,?,?,?)").run('assistant.' + sid, 'bad2', NOW + 11, JSON.stringify(['junk']));
  const hh = await loadHistory(store, sid); ok(hh.ok && hh.skipped === 2 && hh.messages.length === 2 && hh.messages.every(m => typeof m.content === 'string'), 'malformed stored records are skipped and counted, valid ones still load');
  db.prepare("INSERT INTO records(tbl,k,ts,data) VALUES(?,?,?,?)").run('assistant.' + sid, 'bad3', NOW + 12, '{not json');
  const hb = await loadHistory(store, sid); ok(hb.ok === false && /^D1_ERROR/.test(hb.reason), 'unparseable JSON in D1 → D1_ERROR instead of a crash');
  const noDb = await clearHistory(store, {}, sid); ok(noDb.ok === false && /^D1_ERROR/.test(noDb.reason), 'clearHistory without any D1 binding → D1_ERROR');
}

console.log('\nK. AI and context errors');
{
  resetMem(); let { env, calls } = mkEnv(() => { throw new Error('model offline'); }); let store = getStore(env), sid = newSessionId();
  let r = await ask(store, env, sid, 'سلام'); ok(r.ok === false && /model offline/.test(r.reason) && !('reply' in r) && (await loadHistory(store, sid)).messages.length === 0, 'AI error → ok:false, nothing saved, no invented reply');
  r = await ask(store, { ALLOW_MEMORY_STORE: '1' }, sid, 'سلام'); ok(r.ok === false && r.reason === 'NOT_CONNECTED', 'no AI binding → NOT_CONNECTED');
  let fetched = 0; const rf = globalThis.fetch; globalThis.fetch = async () => { fetched++; return new Response('{}'); };
  r = await ask(store, { ALLOW_MEMORY_STORE: '1', ANTHROPIC_API_KEY: 'sk-test-not-real' }, sid, 'سلام'); globalThis.fetch = rf;
  ok(r.ok === false && /^UNSUPPORTED_PROVIDER/.test(r.reason) && fetched === 0, 'Anthropic-only env → refused, no paid API call');
  resetMem(); ({ env, calls } = mkEnv()); store = getStore(env);
  for (const [name, args] of [['A missing', { A: undefined, plan: REAL.plan, weekly: REAL.weekly }], ['A not an object', { A: 5, plan: REAL.plan, weekly: REAL.weekly }], ['A.reels missing', { A: { ...REAL.A, reels: undefined }, plan: REAL.plan, weekly: REAL.weekly }]]) {
    const x = await assistantReply({ store, env, sid, message: 'سلام', ...args }); ok(x.ok === false && /^INVALID_CONTEXT/.test(x.reason) && calls.length === 0, `${name} → INVALID_CONTEXT, model not called`);
  }
  r = await assistantReply({ store, env, sid, message: 'سلام', A: REAL.A, plan: null, weekly: null }); ok(r.ok === true, 'plan/weekly may be missing: assistant still answers from analysis alone');
  const big = { ...REAL.weekly, huge: 'ب'.repeat(7000) }; r = await assistantReply({ store, env, sid: newSessionId(), message: 'سلام', A: REAL.A, plan: REAL.plan, weekly: big });
  ok(r.ok === true && r.contextTrimmed === true && calls.at(-1).input.messages[0].content.length <= 8000 && !calls.at(-1).input.messages[0].content.includes('ببببب'), 'oversized context is trimmed step by step (weekly dropped first), prompt stays ≤ 8000 chars');
  const huge = { ...REAL.A, stuck: { ...REAL.A.stuck, problems: [{ id: 'x', title: 'ب'.repeat(7000) }] } }; r = await assistantReply({ store, env, sid: newSessionId(), message: 'سلام', A: huge, plan: REAL.plan, weekly: REAL.weekly });
  ok(r.ok === false && /^INVALID_CONTEXT: page data too large/.test(r.reason), 'impossible-to-shrink context → INVALID_CONTEXT, never cut mid-JSON');
  for (const [name, args] of [['no store', { store: undefined }], ['bad sid', { sid: 'ses_1' }], ['bad now', { now: NaN }]]) { const x = await assistantReply({ store, env, sid, message: 'سلام', ...ctxArgs(), now: NOW, ...args }); ok(x.ok === false && /^INVALID_(INPUT|SESSION)/.test(x.reason), `${name} rejected`); }
  const none = await assistantReply(); ok(none.ok === false && /^INVALID_/.test(none.reason), 'called with no arguments → INVALID_*, no exception');
  const sv = await saveTurn(store, sid, 'x'.repeat(2001), 'y'); ok(sv.ok === false && /^INVALID_INPUT/.test(sv.reason), 'saveTurn enforces the 2000-char limit too');
  const sv2 = await saveTurn(store, sid, ' ', 'y'); ok(sv2.ok === false, 'saveTurn rejects empty text');
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
