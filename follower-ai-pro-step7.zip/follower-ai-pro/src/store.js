// Storage abstraction. Tables used: media, daily, stories, ideas, plans, decisions, kv
export class MemoryStore {
  kind = 'memory (NOT persistent)';
  constructor() { this.m = new Map(); }
  async put(t, k, d, ts = Date.now()) { this.m.set(t + '\u0000' + k, { t, k, ts, d }); }
  async get(t, k) { const r = this.m.get(t + '\u0000' + k); return r ? r.d : null; }
  async check() { return { ok: false, reason: 'D1 binding "DB" is missing: data is kept in memory only and is lost on restart' }; }
  async list(t, { limit = 1000 } = {}) {
    return [...this.m.values()].filter(r => r.t === t).sort((a, b) => b.ts - a.ts).slice(0, limit).map(r => r.d);
  }
}

export class D1Store {
  kind = 'cloudflare-d1';
  constructor(db) { this.db = db; }
  async put(t, k, d, ts = Date.now()) {
    await this.db.prepare(
      'INSERT INTO records(tbl,k,ts,data) VALUES(?,?,?,?) ON CONFLICT(tbl,k) DO UPDATE SET ts=excluded.ts,data=excluded.data'
    ).bind(t, k, ts, JSON.stringify(d)).run();
  }
  async check() {
    try {
      const r = await this.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='records'").first();
      return r ? { ok: true } : { ok: false, reason: 'D1 is bound but table "records" is missing. Run: wrangler d1 execute follower-ai-pro-db --remote --file=schema.sql' };
    } catch (e) { return { ok: false, reason: 'D1 query failed: ' + e.message }; }
  }
  async get(t, k) {
    const r = await this.db.prepare('SELECT data FROM records WHERE tbl=? AND k=?').bind(t, k).first();
    return r ? JSON.parse(r.data) : null;
  }
  async list(t, { limit = 1000 } = {}) {
    const { results } = await this.db.prepare('SELECT data FROM records WHERE tbl=? ORDER BY ts DESC LIMIT ?').bind(t, limit).all();
    return results.map(r => JSON.parse(r.data));
  }
}

export function getStore(env) {
  if (env.DB) return new D1Store(env.DB);
  // Production must use D1. The in-memory fallback exists ONLY for local tests (ALLOW_MEMORY_STORE=1).
  if (env.ALLOW_MEMORY_STORE === '1') {
    if (!globalThis.__ige_mem) globalThis.__ige_mem = new MemoryStore();
    return globalThis.__ige_mem;
  }
  throw new Error('D1 binding "DB" is missing. Create the D1 database follower-ai-pro-db and set its database_id in wrangler.toml');
}

// Per-account namespace: every table name gets "@account" appended, so several Instagram pages can live in the same D1 table.
export function scoped(store, account) {
  const t = tbl => `${tbl}@${account}`;
  return { kind: store.kind, account, check: () => store.check(),
    put: (tbl, k, d, ts) => store.put(t(tbl), k, d, ts), get: (tbl, k) => store.get(t(tbl), k), list: (tbl, o) => store.list(t(tbl), o) };
}
