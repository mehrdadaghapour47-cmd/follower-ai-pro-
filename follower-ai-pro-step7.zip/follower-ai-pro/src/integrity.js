// DATA INTEGRITY / ANTI-FABRICATION. Pure functions, no I/O, no AI.
// What it does for the assistant:
//  1. assess(): how much REAL data exists, how old it is, what is missing.
//  2. factSets(): every number the model is allowed to quote, split by provenance
//     (fact = stored or computed from stored data; estimate = heuristic scores / proxies).
//  3. verifyReply(): finds "statistic-looking" numbers in a reply and checks each one against those sets.
//     A number that comes only from the user's message, from an earlier assistant turn, or from nowhere is NOT accepted as a fact.
//  4. redact(): removes numbers that could not be verified.
//  5. metricAsk(): detects "how many followers / what is my reach" questions so unavailable metrics are answered by code, not by the model.
// LIMITS (by design, not hidden): numbers written in words, numbers with no metric word nearby and below 1000, and arithmetic the model does
// itself are outside what a text check can decide with certainty. See the report for the full list.

const DAY = 86400000;
export const STALE_FETCH_DAYS = 7, MIN_REELS_PATTERNS = 8, REDACTED = '[عدد نامعتبر]';

// ---------- digits: 1:1 character mapping, so offsets in the normalised text are valid in the original ----------
const FA = '۰۱۲۳۴۵۶۷۸۹', AR = '٠١٢٣٤٥٦٧٨٩';
export const normDigits = s => String(s ?? '').replace(/[۰-۹٠-٩]/g, c => { const i = FA.indexOf(c); return String(i >= 0 ? i : AR.indexOf(c)); }).replace(/٫/g, '.').replace(/٬/g, ',');

const MULT = { 'هزار': 1e3, 'میلیون': 1e6, 'میلیارد': 1e9, k: 1e3, m: 1e6, b: 1e9 };
const NUM = () => /(?<![\d.,])(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d+))?(?:\s?(هزار|میلیون|میلیارد|[kKmMbB])(?![A-Za-z]))?(\s?(?:%|٪|درصد))?(?!\d)/g;

// every numeric token of a text: { raw, start, end, value, decimals, mult, percent }
export function numbersIn(text) {
  const t = normDigits(text), out = [];
  for (const m of t.matchAll(NUM())) {
    const mult = m[3] ? MULT[m[3].toLowerCase()] ?? MULT[m[3]] : 1;
    const value = parseFloat(m[1].replace(/,/g, '') + (m[2] ? '.' + m[2] : '')) * mult;
    if (!Number.isFinite(value)) continue;
    out.push({ raw: String(text).slice(m.index, m.index + m[0].length), start: m.index, end: m.index + m[0].length, value, decimals: m[2] ? m[2].length : 0, mult, hasMult: !!m[3], percent: !!m[4] });
  }
  return out;
}

// ---------- context classification ----------
const METRIC_RE = /فالوور|فالوئر|دنبال[\s‌]?کننده|follower|بازدید|ویو|\bviews?\b|لایک|\blikes?\b|کامنت|comment|ذخیره|\bsaves?\b|اشتراک|\bshares?\b|ریچ|reach|دسترسی|ایمپرشن|impression|تعامل|engagement|رشد|growth|برابر|میانه|میانگین|median|average|\bavg\b|نرخ|\brate\b|نفر|عضو|درصد|بیشترین|کمترین|امتیاز|score/i;
const COUNT_RE = /(ریل|پست|استوری|reels?|posts?|stories)/i, HAVE_RE = /منتشر\s*کرد(?:ی|ید|ه‌ای|ه‌اید)|داری|دارید|ثبت\s*شده|ذخیره\s*شده|ساخته‌ای|\bhave\b|\bpublished\b|\bposted\b|تاکنون|تا الان|در کل|مجموع/i;
const CLAIM_RE = /طبق\s*(?:گفته|ادعا|نوشته|پیام)|به\s*گفته|گفتی|گفتید|نوشتی|نوشتید|اعلام\s*کرد|ادعا|فرض|اگر|\bif\b|you said|you wrote|according to you|عددی که تو/i;
const ESTIMATE_RE = /تخمین|برآورد|حدس|پیش[\s‌]?بینی|احتمالاً|تقریب|estimate|forecast|proxy|پروکسی|heuristic|ابتکاری|امتیاز\s*(?:ایده|پیشنهاد|برنامه|ابزار)/i;

function sentenceOf(t, idx) { // bounds of the sentence containing idx (a '.' inside a decimal is not a boundary)
  const isEnd = i => t[i] === '\n' || (/[.!؟?؛]/.test(t[i]) && (i + 1 >= t.length || /\s/.test(t[i + 1])));
  let a = idx; while (a > 0 && !isEnd(a - 1)) a--;
  let b = idx; while (b < t.length && !isEnd(b)) b++;
  return [a, Math.min(t.length, b + 1)];
}
const yearLike = v => Number.isInteger(v) && ((v >= 1300 && v <= 1499) || (v >= 1900 && v <= 2100));
function inDateOrTime(t, tok) { // 20:45, 2026-10-11, 1405/07/19: the token touches ':' '-' or '/' between digits
  const pc = t[tok.start - 1] || '', nc = t[tok.end] || '', pd = /\d/.test(t[tok.start - 2] || ''), nd = /\d/.test(t[tok.end + 1] || '');
  return (pc === ':' && pd) || (nc === ':' && nd) || (/[-/]/.test(pc) && pd) || (/[-/]/.test(nc) && nd);
}

// is this number a statistic-style claim (something that must be verifiable)?
export function isStatClaim(t, tok) {
  if (inDateOrTime(t, tok)) return false;
  if (!tok.percent && !tok.hasMult && tok.value <= 50 && tok.decimals === 0 && /^\)/.test(t.slice(tok.end, tok.end + 1))) return false; // list numbering
  if (tok.percent || tok.hasMult) return true;
  const [a, b] = sentenceOf(t, tok.start), sent = t.slice(a, b);
  const win = (t.slice(Math.max(a, tok.start - 32), tok.start) + ' ' + t.slice(tok.end, Math.min(b, tok.end + 32)));
  if (METRIC_RE.test(win)) return true;
  if (COUNT_RE.test(t.slice(tok.end, tok.end + 14)) && HAVE_RE.test(sent)) return true;
  if (tok.value >= 1000 && !(yearLike(tok.value) && tok.decimals === 0)) return true;
  return false;
}

// does `claim` match `fact` at the precision the claim was written with? (1.2k ↔ 1234, 12% ↔ 12.3, exact otherwise)
export function numMatch(tok, fact) {
  const v = tok.value, eq = (x, y) => Math.abs(x - y) <= 1e-9 * Math.max(1, Math.abs(x), Math.abs(y));
  if (eq(v, fact)) return true;
  if (tok.hasMult) return Math.abs(v - fact) <= (tok.mult * Math.pow(10, -tok.decimals)) / 2 + 1e-9;
  if (tok.decimals > 0 || tok.percent) return Math.abs(v - fact) <= Math.pow(10, -tok.decimals) / 2 + 1e-9;
  return false;
}
const inSet = (tok, set) => { for (const f of set) if (numMatch(tok, f) || (tok.percent && numMatch(tok, f * 100))) return true; return false; }; // 43% ↔ ratio 0.43

// ---------- data quality ----------
export function assess(A, now = Date.now()) {
  const reels = Array.isArray(A?.reels) ? A.reels : [], all = Array.isArray(A?.all) ? A.all : reels, p = A?.p || {};
  const fetched = Math.max(0, ...all.map(m => Number(m.fetchedAt)).filter(Number.isFinite));
  const fetchAgeDays = fetched ? Math.max(0, Math.floor((now - fetched) / DAY)) : null;
  const newest = reels.length ? reels[0].ts : null;
  const missing = [];
  if (p.followers == null) missing.push('followers');
  if (!(p.reachTrend != null || reels.some(r => r.metrics?.reach != null))) missing.push('reach');
  if (p.profileConv == null) missing.push('profile-visits/follows');
  if (!reels.some(r => r.hasTime)) missing.push('post-times');
  if (!p.storyCount14) missing.push('stories');
  if (!reels.some(r => r.metrics?.avgWatchSec != null)) missing.push('watch-time');
  return {
    hasData: reels.length > 0, reels: reels.length,
    newestPostDate: Number.isFinite(newest) ? new Date(newest).toISOString().slice(0, 10) : null,
    fetchAgeDays, stale: fetchAgeDays != null && fetchAgeDays > STALE_FETCH_DAYS,
    sufficientForPatterns: reels.length >= MIN_REELS_PATTERNS, sufficientForDiagnosis: A?.health?.score != null,
    sources: [...new Set(all.map(m => m.source).filter(Boolean))], missing,
    followersKnown: p.followers != null,
  };
}

// ---------- the numbers the model may quote ----------
function addNums(set, v) { // numbers in any value: numbers directly, numeric tokens inside strings, recursively
  if (v == null) return;
  if (typeof v === 'number') { if (Number.isFinite(v)) set.add(v); return; }
  if (typeof v === 'string') { for (const t of numbersIn(v)) set.add(t.value); return; }
  if (Array.isArray(v)) { v.forEach(x => addNums(set, x)); return; }
  if (typeof v === 'object') Object.values(v).forEach(x => addNums(set, x));
}
const METRIC_KEYS = ['views', 'likes', 'comments', 'shares', 'saves', 'dur', 'perf'];
// ctx = coachContext(A, plan, weekly)   → { fact:Set, estimate:Set }
export function viewRatios(ctx) { // [{id, ratio}] views ÷ overall median for the reels shown to the model (derived, computed here, not by the model)
  const med = ctx?.overallMedianViews; if (!(med > 0)) return [];
  const seen = new Set(), out = [];
  for (const r of ctx.lastReels || []) if (r && !seen.has(r.id) && Number.isFinite(r.views)) { seen.add(r.id); out.push({ id: r.id, ratio: r.views / med }); }
  return out;
}
export function factSets(ctx, A, quality) {
  const fact = new Set(), estimate = new Set(), ratio = new Set(), pct = new Set();
  for (const x of viewRatios(ctx)) { fact.add(x.ratio); ratio.add(x.ratio); }
  for (const g of ['topic', 'hook', 'duration', 'cta']) for (const x of ctx?.patterns?.[g] || []) if (Number.isFinite(x?.ratio)) ratio.add(x.ratio);
  for (const r of [...(ctx?.lastReels || []), ...(ctx?.topReels || [])]) { METRIC_KEYS.forEach(k => addNums(fact, r?.[k])); }
  addNums(fact, ctx?.overallMedianViews); addNums(fact, ctx?.health); addNums(fact, ctx?.patterns);
  for (const p of ctx?.problems || []) addNums(/proxy/i.test(String(p.evidence)) ? estimate : fact, p.evidence); // '(reel-level proxy)' evidence is an approximation, not a measurement
  const w = { ...(ctx?.weekly || {}) }; delete w.nextWeekStrategy; addNums(fact, w);
  for (const i of ctx?.todayTop || []) { addNums(estimate, i.score); estimate.add(100); } // idea score and its 0-100 scale   // heuristic idea score: an estimate, not a result
  const pm = A?.p || {};
  for (const k of ['followers', 'followDelta7', 'followGrowthPct7']) if (pm[k] != null) addNums(fact, pm[k]);
  addNums(fact, [quality?.reels, quality?.fetchAgeDays, A?.pat?.n]);
  // percentages the model may quote: only numbers that the code itself wrote with a % sign, coverage, and ratios × 100 (stops "7%" matching an unrelated "7 days")
  const pctFrom = v => { if (typeof v === 'string') { for (const t of numbersIn(v)) if (t.percent) pct.add(t.value); } else if (Array.isArray(v)) v.forEach(pctFrom); else if (v && typeof v === 'object') Object.values(v).forEach(pctFrom); };
  for (const p of ctx?.problems || []) if (!/proxy/i.test(String(p.evidence))) pctFrom(p.evidence);
  pctFrom(w); pctFrom(ctx?.health?.note);
  if (Number.isFinite(ctx?.health?.coverage)) pct.add(ctx.health.coverage);
  for (const f of ratio) pct.add(f * 100);
  return { fact, estimate, ratio, pct };
}
export const userNumbers = texts => { const s = new Set(); for (const t of texts) for (const n of numbersIn(t)) s.add(n.value); return s; };

const isRatioClaim = (t, tok) => /^\s*(?:برابر|x\b|×)/i.test(t.slice(tok.end, tok.end + 8)) || /(?:x|×)\s*$/i.test(t.slice(Math.max(0, tok.start - 3), tok.start));

// ---------- reply verification ----------
// → { ok, violations:[{type, token, start, end}], checked }
//   types: unverified | user_number_as_fact | estimate_as_fact
export function verifyReply(reply, { sets, userNums = new Set() }) {
  const t = normDigits(reply), violations = []; let checked = 0;
  for (const tok of numbersIn(reply)) {
    if (!isStatClaim(t, tok)) continue; checked++;
    const [a, b] = sentenceOf(t, tok.start), sent = t.slice(a, b);
    if (tok.percent && sets.pct) { if ([...sets.pct].some(f => numMatch(tok, f))) continue; }
    else if (inSet(tok, sets.fact)) continue;
    if (sets.ratio && isRatioClaim(t, tok) && [...sets.ratio].some(f => numMatch(tok, f) || Math.round(f) === tok.value || Math.abs(Math.round(f * 10) / 10 - tok.value) < 1e-9)) continue; // "2 برابر" / "x2.1" for a stored 2.08
    if (inSet(tok, sets.estimate)) { if (!ESTIMATE_RE.test(sent)) violations.push({ type: 'estimate_as_fact', token: tok.raw.trim(), start: tok.start, end: tok.end }); continue; }
    if (inSet(tok, userNums)) { if (!CLAIM_RE.test(sent)) violations.push({ type: 'user_number_as_fact', token: tok.raw.trim(), start: tok.start, end: tok.end }); continue; }
    violations.push({ type: 'unverified', token: tok.raw.trim(), start: tok.start, end: tok.end });
  }
  return { ok: violations.length === 0, violations, checked };
}
export function redact(reply, violations) {
  let out = String(reply);
  for (const v of [...violations].sort((x, y) => y.start - x.start)) out = out.slice(0, v.start) + REDACTED + out.slice(v.end);
  return out;
}

// ---------- "how many followers / what is my reach" questions ----------
const QTY_RE = /چند(?:تا)?|تعداد|آمار|چقدر|عدد|درصد|نرخ|میزان|الان|فعلی|how many|how much|count|number|what is my|what's my/i;
const CONFIRM_RE = /تأیید|تایید|درسته|درست است|درست؟|صحیح|confirm|correct\?|right\?/i;
const FOLLOWERS_RE = /فالوور|فالوئر|دنبال[\s‌]?کننده|follower/i, REACH_RE = /ریچ|\breach\b|ایمپرشن|impression|بازدید\s*پروفایل|profile\s*visit/i;
export function metricAsk(message) {
  const m = normDigits(message), qty = QTY_RE.test(m) || CONFIRM_RE.test(m); // a number in the message alone does NOT make it a lookup ("I have 10000 followers, give me a reel idea" goes to the model)
  const out = [];
  if (FOLLOWERS_RE.test(m) && qty) out.push('followers');
  if (REACH_RE.test(m) && qty) out.push('reach');
  return out;
}
