// AI GROWTH COACH. Answers ONLY from stored page data. Optional Claude call if ANTHROPIC_API_KEY is configured.
import { DNA, scoreFromRatio } from './analysis.js';
import { scoreIdea } from './planner.js';
import { runAI, runAIJson, validateCoach, aiProvider } from './ai.js';

const AI_SYSTEM = 'You are the analyst of an Iranian firefighter-fitness Instagram page. Reply in Persian, max 180 words, numbered, concrete. Use ONLY the JSON data provided. Never invent numbers; if something is missing write "DATA NOT AVAILABLE". Cover: 1) the single biggest growth blocker with its evidence, 2) what to change in today\'s reel (pick from todayTop or improve one), 3) one story action, 4) what NOT to do today. Every score in the data is an estimate: call it "تخمینی".';

const brief = r => ({ id: r.id, date: new Date(r.ts).toISOString().slice(0, 10), views: r.metrics?.views ?? null, likes: r.metrics?.likes ?? null, comments: r.metrics?.comments ?? null, shares: r.metrics?.shares ?? null, saves: r.metrics?.saves ?? null, dur: r.durationSec, hook: r.hook, topic: r.topic, perf: r.perfScore });

export function coachContext(A, plan, weekly) {
  return { health: { score: A.health.score, coverage: A.health.coverage }, problems: A.stuck.problems, notEvaluable: A.stuck.notEvaluable.map(x => x.id),
    lastReels: A.reels.slice(0, 6).map(brief), topReels: A.reels.slice().sort((a, b) => b.metrics.views - a.metrics.views).slice(0, 3).map(brief),
    overallMedianViews: A.pat.overallMedian, patterns: { topic: A.pat.byTopic.slice(0, 3), hook: A.pat.byHook.slice(0, 3), duration: A.pat.byDuration.slice(0, 3) },
    todayTop: plan?.ideas?.slice(0, 2).map(i => ({ title: i.title, hook: i.hook, cta: i.cta, dur: i.dur, score: i.score.total, tier: i.score.tier })), strategy: plan?.strategy, weekly };
}

function rules(q, A, plan, weekly) {
  const L = A.reels, med = A.pat.overallMedian;
  const has = re => re.test(q);
  if (!L.length) return { answer: `${DNA}: هنوز هیچ ریلزی با آمار ثبت نشده. اول Instagram API را وصل کن یا داده عمومی را Import کن.`, basedOn: [] };
  if (has(/چرا.*(نگرفت|نخورد|کم|ویو|بازدید)|why.*(reel|flop)/i)) {
    const r = L[0], ratio = med ? r.metrics.views / med : null, top = L.slice().sort((a, b) => b.metrics.views - a.metrics.views)[0];
    const diffs = [];
    if (top.id !== r.id) {
      if (r.durationBucket !== top.durationBucket) diffs.push(`مدت (${r.durationSec ?? '؟'}s) با برنده‌ات (${top.durationSec ?? '؟'}s) فرق دارد`);
      if (r.topic !== top.topic) diffs.push(`موضوع «${r.topic}» است، برنده‌ات «${top.topic}»`);
      if (r.hookFeatures[0] !== top.hookFeatures[0]) diffs.push(`هوک «${r.hookFeatures[0]}» است، برنده‌ات «${top.hookFeatures[0]}»`);
      if (r.cta === 'none' && top.cta !== 'none') diffs.push('CTA ندارد');
    }
    return { answer: `آخرین ریلز (${r.id}) ${r.metrics.views} بازدید گرفت؛ ${ratio ? ratio.toFixed(1) + ' برابر' : DNA} میانه (${Math.round(med)}). ${diffs.length ? 'تفاوت‌ها با بهترین ریلزت: ' + diffs.join('؛ ') + '.' : 'تفاوت ساختاری آشکاری با بهترین ریلز نیست.'} ${A.stuck.problems[0] ? 'مهم‌ترین مشکل ثبت‌شده: ' + A.stuck.problems[0].title + ' (' + A.stuck.problems[0].evidence + ').' : ''} ریچ، ذخیره و زمان تماشا: ${r.metrics.reach == null ? DNA : 'موجود'}.`, basedOn: ['reels', 'patterns', 'stuck'] };
  }
  if (has(/منتشر کنم یا نه|publish.*(or not|this)/i)) {
    const m = q.match(/[«"“](.+?)[»"”]/); const hook = m ? m[1] : null;
    if (!hook) return { answer: 'هوک یا عنوان ریلز را داخل « » بنویس تا امتیازش را حساب کنم. مثال: منتشر کنم یا نه «۳ ست بدون استراحت. تا آخر ببین»', basedOn: [] };
    const s = scoreIdea({ hook, topic: 'other', dur: 20, cta: '', f: {} }, { pat: A.pat, memHooks: A.all.map(x => x.hook) });
    return { answer: `امتیاز هوک: هوک ${s.parts.hook}/20، Originality ${s.parts.originality}/10 (شباهت ${s.maxSimilarity}٪ به محتوای قبلی). برای امتیاز کامل CTA، مدت و فرمت را هم بگو. ${s.maxSimilarity > 50 ? 'به محتوای قبلی خیلی شبیه است؛ زاویه را عوض کن.' : ''}`, basedOn: ['content-memory'] };
  }
  if (has(/فالوور|follower|فالو.*(نمی|اضافه)/i)) {
    const p = A.stuck.problems.filter(x => ['conversion_low', 'reel_views_no_follow', 'cta_weak', 'low_shareable'].includes(x.id));
    return { answer: p.length ? 'دلایل ثبت‌شده: ' + p.map(x => `${x.title} — ${x.evidence}. اقدام: ${x.action}`).join(' | ') : `${DNA}: داده کافی برای تشخیص علت نبود فالوور وجود ندارد (نیازمند Follower snapshots/Profile visits از API).`, basedOn: ['stuck'] };
  }
  if (has(/استوری|story/i)) {
    const s = plan?.stories?.slice(3) || [];
    return { answer: 'استوری امشب: ' + s.map(x => `${x.time} — ${x.text} [${x.sticker}]`).join(' | '), basedOn: ['plan'] };
  }
  if (has(/این هفته|تغییر|هفته/)) {
    return { answer: `ادامه بده: ${weekly.keepDoing.join('؛ ')}. متوقف کن: ${weekly.stopDoing.join('؛ ')}. استراتژی: ${weekly.nextWeekStrategy.mode}.`, basedOn: ['weekly'] };
  }
  if (has(/امروز|today/i)) {
    const t = plan.ideas[0];
    return { answer: `امروز: «${t.title}». هوک: «${t.hook}». مدت ${t.dur} ثانیه. انتشار ${plan.mission.top.publishAt}. CTA: «${t.cta}». امتیاز ${t.score.total} (${t.score.tier}).`, basedOn: ['plan'] };
  }
  return { answer: `Growth Health: ${A.health.score ?? DNA} (پوشش داده ${A.health.coverage}٪). مشکلات: ${A.stuck.problems.map(x => x.title).join('، ') || 'موردی با داده فعلی تشخیص داده نشد'}.`, basedOn: ['health', 'stuck'] };
}

export async function coachAnswer({ q, A, plan, weekly, env, fetchFn = fetch, brief = null }) {
  const ctx = { ...coachContext(A, plan, weekly), userBrief: brief };
  if (aiProvider(env)) {
    const r = await runAIJson(env, { fetchFn, maxTokens: 900,
      system: 'You are the AI Growth Coach for an Iranian Instagram page. Reply with ONLY one JSON object: {"answer": string (Persian, concise), "actions": string[] (max 5 concrete steps), "missing_data": string[]}. Use ONLY the provided data. Never invent metrics; unknown values go to missing_data as "DATA NOT AVAILABLE: ...". Never claim an API is connected unless the data says so.',
      user: `DATA:\n${JSON.stringify(ctx)}\n\nQUESTION: ${q}` }, validateCoach);
    if (r.ok) {
      const source = r.provider === 'anthropic' ? 'claude' : r.provider;
      if (r.structured) return { answer: r.data.answer, actions: r.data.actions, missingData: r.data.missing_data, structured: true, source, basedOn: ['all-data'] };
      return { answer: r.text, structured: false, source, basedOn: ['all-data'], note: 'AI reply was not valid JSON after one retry; shown as plain text' };
    }
  }
  return { ...rules(q, A, plan, weekly), source: 'rules' };
}

// Optional AI layer on top of the rule-based plan. Runs at most once per plan generation (cron: once a day).
export async function aiAnalysis({ A, plan, weekly, env, fetchFn = fetch, now = Date.now() }) {
  if (!aiProvider(env)) return { status: 'NOT CONNECTED', note: 'No AI provider (Workers AI binding or ANTHROPIC_API_KEY); the plan above is rule-based only' };
  const ctx = coachContext(A, plan, weekly);
  if (!A.reels.length) return { status: 'SKIPPED', note: 'DATA NOT AVAILABLE: no reel with stats yet, nothing to analyse' };
  const r = await runAI(env, { fetchFn, maxTokens: 700, system: AI_SYSTEM, user: 'DATA:\n' + JSON.stringify(ctx) });
  if (!r.ok) return { status: 'ERROR', message: r.reason, at: now };
  return { status: 'OK', text: r.text, model: r.model, provider: r.provider, at: now };
}
