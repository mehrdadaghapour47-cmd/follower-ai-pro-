import { getStore, scoped } from './store.js';
import { aiProvider } from './ai.js';
import { buildAudit, buildReelIdeas, buildWeeklyPlan, buildStrategy, withAISummary } from './compat.js';
import { encrypt, decrypt } from './crypto.js';
import { IGClient, REQUIRED_PERMISSIONS, OPTIONAL_PERMISSIONS, explainErrors } from './instagram.js';
import { DNA, median, scoreFromRatio } from './analysis.js';
import { analyzeAll, makePlan, weeklyReport, tehranDate, RESEARCH_TOPICS } from './planner.js';
import { coachAnswer, aiAnalysis } from './coach.js';
import { assistantReply, loadHistory, clearHistory, newSessionId, isSessionId, ASSISTANT_MAX_CHARS } from './assistant.js';

const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' } });
const DAY = 86400000;
const MAX_BODY = 200_000;                 // bytes
const MAX_IMPORT = 200;                   // items per request
const MAX_Q = 500;                        // coach question length
const TOKEN_RE = /^[A-Za-z0-9_\-.]{20,1000}$/;
const bad = (msg, code = 400) => J({ error: msg }, code);
const shortcode = u => (u || '').match(/\/(?:reel|p|tv)\/([^/?#]+)/)?.[1] || null;

// Compare SHA-256 digests so length/content of ADMIN_KEY never leaks through timing.
async function adminOk(request, env) {
  const enc = new TextEncoder();
  const [a, b] = await Promise.all([
    crypto.subtle.digest('SHA-256', enc.encode(request.headers.get('x-admin-key') || '')),
    crypto.subtle.digest('SHA-256', enc.encode(env.ADMIN_KEY)),
  ]);
  const x = new Uint8Array(a), y = new Uint8Array(b); let r = 0;
  for (let i = 0; i < x.length; i++) r |= x[i] ^ y[i];
  return r === 0;
}
function encKeyState(env) {
  if (!env.TOKEN_ENC_KEY) return 'MISSING';
  try { return atob(env.TOKEN_ENC_KEY).length === 32 ? 'SET (valid)' : 'SET (INVALID: must be 32 bytes base64)'; } catch { return 'SET (INVALID: not base64)'; }
}

async function d1State(env, store) {
  if (!env.DB) return store ? { status: 'NOT CONFIGURED', detail: 'memory fallback active (tests only)' } : { status: 'NOT CONFIGURED', detail: 'D1 binding DB is missing in wrangler.toml' };
  try { await env.DB.prepare('SELECT 1 FROM records LIMIT 1').first(); return { status: 'OK' }; }
  catch (e) { return { status: 'ERROR', detail: /no such table/i.test(e.message) ? 'Table missing: run schema.sql on follower-ai-pro-db' : String(e.message).slice(0, 160) }; }
}

async function system(env, store, now) {
  const d1 = await d1State(env, store);
  let ig = { status: 'NOT CONNECTED', data: DNA, lastSyncOk: null };
  if (store && (d1.status === 'OK' || env.ALLOW_MEMORY_STORE === '1')) {
    const c = await creds(env, store), last = await store.get('kv', 'lastSync');
    if (c.token && !c.error) ig = { status: 'CONNECTED', tokenSource: c.source, lastSyncOk: last ? !!last.ok : null, lastSyncAt: last?.at ?? null, data: last?.ok ? 'available' : DNA };
    else if (c.error) ig = { status: 'NOT CONNECTED', data: DNA, error: c.error };
  } else if (env.IG_ACCESS_TOKEN) ig = { status: 'CONNECTED', tokenSource: 'secret IG_ACCESS_TOKEN', lastSyncOk: null, data: DNA };
  return {
    time: now, worker: 'OK', d1, instagram: ig,
    ai: aiProvider(env) ? { status: 'CONNECTED', provider: aiProvider(env), note: aiProvider(env) === 'workers-ai' ? 'Cloudflare Workers AI binding (model: ' + (env.AI_MODEL || '@cf/meta/llama-3.1-8b-instruct') + '); not verified by a live call' : 'ANTHROPIC_API_KEY is set; not verified by a live call' } : { status: 'NOT CONNECTED', note: 'coach runs on built-in rules over your data' },
    configProblems: keyProblems(env),
    secrets: { ADMIN_KEY: !env.ADMIN_KEY ? 'MISSING' : env.ADMIN_KEY.length < 16 ? 'TOKEN TOO SHORT (min 16 chars)'.replace('TOKEN ', '') : 'SET', TOKEN_ENC_KEY: encKeyState(env), IG_ACCESS_TOKEN: env.IG_ACCESS_TOKEN ? 'SET' : 'not set (optional)', ANTHROPIC_API_KEY: env.ANTHROPIC_API_KEY ? 'SET' : 'not set (optional)' },
  };
}
// flat shape used by /api/status
const flatSystem = sy => ({ worker: sy.worker, d1: sy.d1.status, d1Detail: sy.d1.detail || null, instagram: sy.instagram.status,
  instagramData: sy.instagram.status === 'CONNECTED' && sy.instagram.lastSyncOk ? 'AVAILABLE' : DNA, ai: sy.ai.status, configProblems: sy.configProblems });

async function creds(env, store) {
  let token = env.IG_ACCESS_TOKEN || null, source = token ? 'secret IG_ACCESS_TOKEN' : null;
  let userId = env.IG_USER_ID || null;
  if (!token) { const kv = await store.get('kv', 'token'); if (kv) { try { token = await decrypt(env, kv.enc); source = 'encrypted store (D1)'; userId = userId || kv.userId; } catch (e) { return { error: 'TOKEN_DECRYPT_FAILED: ' + e.message }; } } }
  return { token, userId, source };
}
const client = (env, c, fetchFn) => new IGClient({ token: c.token, userId: c.userId, host: env.IG_API_HOST || 'graph.instagram.com', version: env.IG_API_VERSION || 'v25.0', fetchFn });

// ---------- data loading ----------
async function load(store) {
  const [media, daily, stories, ideas] = await Promise.all([store.list('media'), store.list('daily'), store.list('stories'), store.list('ideas', { limit: 400 })]);
  return { media, daily, stories, ideas };
}

// ---------- token refresh (only for a token stored in D1; a Worker secret cannot be rewritten by the Worker) ----------
export async function refreshToken(env, store, { now = Date.now(), fetchFn = fetch, force = false } = {}) {
  const rec = await store.get('kv', 'token');
  if (!rec) return { ok: false, skipped: true, reason: 'no token stored in D1' };
  const last = rec.refreshedAt || rec.savedAt || 0;
  if (!force && now - last < 20 * DAY) return { ok: true, skipped: true, reason: 'token is recent; refresh not needed yet' };
  let token; try { token = await decrypt(env, rec.enc); } catch (e) { return { ok: false, reason: 'TOKEN_DECRYPT_FAILED' }; }
  try {
    const ig = new IGClient({ token, userId: rec.userId, host: env.IG_API_HOST || 'graph.instagram.com', version: env.IG_API_VERSION || 'v25.0', fetchFn });
    const r = await ig.refresh();
    await store.put('kv', 'token', { ...rec, enc: await encrypt(env, r.token), refreshedAt: now, expiresAt: r.expiresIn ? now + r.expiresIn * 1000 : null });
    return { ok: true, refreshed: true, expiresAt: r.expiresIn ? now + r.expiresIn * 1000 : null };
  } catch (e) { return { ok: false, reason: String(e.message).slice(0, 200), code: e.code ?? null }; }
}

// ---------- sync ----------
export async function runSync(env, store, { now = Date.now(), fetchFn = fetch } = {}) {
  const c = await creds(env, store);
  if (c.error) return { ok: false, reason: c.error };
  if (!c.token) return { ok: false, reason: 'NOT_CONNECTED', detail: 'No Instagram token. ' + DNA };
  const ig = client(env, c, fetchFn);
  const report = { ok: true, at: now, profile: null, daysFetched: 0, media: 0, stories: 0, errors: [] };
  try {
    const pr = await ig.profile();
    ig.userId = ig.userId || pr.id;
    report.profile = { username: pr.username, followers: pr.followers_count, media: pr.media_count };
    const today = tehranDate(now, +env.TIMEZONE_OFFSET_MIN || 210);
    const cur = (await store.get('daily', today)) || { date: today };
    await store.put('daily', today, { ...cur, date: today, followers: pr.followers_count ?? null, following: pr.follows_count ?? null }, Date.parse(today));
  } catch (e) { ig.note('profile', e); report.ok = false; }
  if (report.ok) {
    const have = (await store.list('daily', { limit: 40 })).filter(d => d.reach != null).length;
    const back = have < 5 ? 10 : 2;
    const max = +env.MAX_SUBREQUESTS || 900;
    for (let i = back; i >= 1; i--) {
      if (ig.calls > max * 0.5) { ig.note('budget', { message: 'subrequest budget reached; remaining days skipped' }); break; }
      const date = new Date(now - i * DAY).toISOString().slice(0, 10);
      const row = await ig.dayInsights(date);
      const old = (await store.get('daily', date)) || {};
      await store.put('daily', date, { ...old, ...row }, Date.parse(date)); report.daysFetched++;
    }
    try {
      const items = await ig.recentMedia(+env.MAX_SUBREQUESTS && +env.MAX_SUBREQUESTS < 100 ? 8 : 20);
      for (const it of items) {
        const sc = shortcode(it.permalink), key = sc || it.id;
        const old = await store.get('media', key);
        await store.put('media', key, { ...old, ...it, durationSec: old?.durationSec ?? it.durationSec, source: 'graph-api', id: key, igMediaId: it.id }, it.ts);
        report.media++;
      }
    } catch (e) { ig.note('media', e); }
    const sts = await ig.liveStories();
    for (const s of sts) { await store.put('stories', s.id, s, s.ts); report.stories++; }
  }
  report.errors = ig.errors; report.explain = explainErrors(ig.errors); report.apiCalls = ig.calls;
  await store.put('kv', 'lastSync', report);
  return report;
}

// ---------- plan ----------
async function ensurePlan(env, store, now, force = false, fetchFn = fetch) {
  const date = tehranDate(now, +env.TIMEZONE_OFFSET_MIN || 210);
  const L = await load(store);
  const A = analyzeAll({ ...L, now });
  let plan = await store.get('plans', date);
  if (!plan || force) {
    const existing = plan;
    const prevDate = tehranDate(now - DAY, +env.TIMEZONE_OFFSET_MIN || 210);
    const prev = await store.get('plans', prevDate);
    const pastIdeas = L.ideas.filter(i => i.date !== date).map(i => i);
    plan = makePlan({ date, A, pastIdeas: L.ideas.filter(i => !i.id.startsWith(date)), prevPlan: prev, bestHourInfo: { hour: A.pat.hours[0]?.key ?? null }, now });
    if (existing) { plan.publishedMediaId = existing.publishedMediaId ?? null; plan.publishedIdeaId = existing.publishedIdeaId ?? null; } // keep the link to today's published reel
    const weekly0 = weeklyReport({ all: A.all, daily: L.daily, stories: L.stories, profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now });
    plan.ai = await aiAnalysis({ A, plan, weekly: weekly0, env, fetchFn, now });
    await store.put('plans', date, plan, now);
    for (const i of plan.ideas) await store.put('ideas', i.id, { ...i, date }, now + plan.ideas.indexOf(i));
    if (plan.mission.yesterday) await store.put('decisions', date, { date, strategy: plan.strategy, yesterday: plan.mission.yesterday }, now);
  }
  return { plan, A, L, date };
}

async function d1Check(env) {
  if (!env.DB) return { state: 'NOT CONFIGURED', detail: 'No D1 binding "DB" (data is kept in memory and will be lost)' };
  try { await env.DB.prepare('SELECT COUNT(*) AS n FROM records').first(); return { state: 'OK' }; }
  catch (e) { return { state: 'ERROR', detail: /no such table/i.test(e.message) ? 'schema.sql has not been applied to the database' : 'D1 query failed' }; }
}
export function keyProblems(env) {
  const out = [];
  if (!env.ADMIN_KEY) out.push('ADMIN_KEY missing'); else if (env.ADMIN_KEY.length < 16) out.push('ADMIN_KEY is shorter than 16 characters');
  if (!env.TOKEN_ENC_KEY) out.push('TOKEN_ENC_KEY missing (needed only to store a token in D1)');
  else { try { if (atob(env.TOKEN_ENC_KEY).length !== 32) out.push('TOKEN_ENC_KEY must decode to exactly 32 bytes'); } catch { out.push('TOKEN_ENC_KEY is not valid base64'); } }
  return out;
}

async function status(env, store) {
  const c = await creds(env, store), last = await store.get('kv', 'lastSync');
  const L = await load(store);
  const bySource = {}; L.media.forEach(m => bySource[m.source || 'unknown'] = (bySource[m.source || 'unknown'] || 0) + 1);
  const d1 = await d1Check(env);
  const igConnected = !!c.token && !c.error;
  return {
    system: { worker: 'OK', d1: d1.state, d1Detail: d1.detail || null,
      instagram: igConnected ? 'CONNECTED' : 'NOT CONNECTED', ai: aiProvider(env) ? 'CONNECTED' : 'NOT CONNECTED',
      instagramData: igConnected && last?.ok ? 'AVAILABLE' : 'DATA NOT AVAILABLE', configProblems: keyProblems(env) },
    storage: store.kind, persistent: store.kind.startsWith('cloudflare'),
    instagram: { connected: !!c.token && !c.error, tokenSource: c.source || null, tokenError: c.error || null, userId: c.userId ? '…' + String(c.userId).slice(-4) : null,
      requiredPermissions: REQUIRED_PERMISSIONS, optionalPermissions: OPTIONAL_PERMISSIONS,
      missingPermissions: last?.explain?.missingPermissions || [], tokenInvalid: last?.explain?.tokenInvalid || false,
      lastSync: last ? { at: last.at, ok: last.ok, media: last.media, stories: last.stories, days: last.daysFetched, errors: (last.errors || []).slice(0, 8) } : null },
    data: { media: L.media.length, bySource, dailyRows: L.daily.length, stories: L.stories.length, ideasMemory: L.ideas.length },
    secrets: { ADMIN_KEY: !!env.ADMIN_KEY, TOKEN_ENC_KEY: !!env.TOKEN_ENC_KEY, IG_ACCESS_TOKEN: !!env.IG_ACCESS_TOKEN, ANTHROPIC_API_KEY: !!env.ANTHROPIC_API_KEY },
    researchTopics: RESEARCH_TOPICS,
    mockParts: ['Content Research Engine uses an internal topic×angle matrix (no external trend feed)', 'Publishing/reminders are NOT automated (plan only)', 'Audience demographics not implemented'],
  };
}

function series(daily, key, n = 14) { return daily.slice().sort((a, b) => a.date.localeCompare(b.date)).slice(-n).map(d => ({ date: d.date, v: d[key] ?? null })); }

async function dashboard(env, store, now) {
  const { plan, A, L } = await ensurePlan(env, store, now);
  const weekly = weeklyReport({ all: A.all, daily: L.daily, stories: L.stories, profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now });
  const withPerf = A.reels.filter(r => r.perfScore != null);
  const card = r => ({ id: r.id, permalink: r.permalink || (r.source !== 'graph-api' ? `https://www.instagram.com/reel/${r.id}/` : null), views: r.metrics.views, likes: r.metrics.likes, comments: r.metrics.comments, shares: r.metrics.shares ?? null, saves: r.metrics.saves ?? null, reach: r.metrics.reach ?? null, hook: r.hook, topic: r.topic, perf: r.perfScore, date: new Date(r.ts).toISOString().slice(0, 10), source: r.source });
  return {
    generatedAt: now, system: await system(env, store, now), status: await status(env, store),
    growthHealth: A.health, stuck: A.stuck,
    followerGrowth: { followers: A.p.followers ?? DNA, delta7: A.p.followDelta7 ?? DNA, series: series(L.daily, 'followers') },
    reach: { trend: A.p.reachTrend ?? DNA, series: series(L.daily, 'reach') },
    engagement: { trend: A.p.engTrend ?? A.p.reelEngTrend ?? DNA, shareRate: A.p.shareRate ?? DNA, saveRate: A.p.saveRate ?? DNA, commentRate: A.p.commentRate ?? DNA },
    bestContent: withPerf.slice().sort((a, b) => b.perfScore - a.perfScore || b.metrics.views - a.metrics.views).slice(0, 3).map(card),
    weakContent: withPerf.slice().sort((a, b) => a.perfScore - b.perfScore || a.metrics.views - b.metrics.views).slice(0, 3).map(card),
    mission: plan.mission, ai: plan.ai || { status: 'NOT CONNECTED' }, todaysReels: plan.ideas, todaysStories: plan.stories, opportunities: plan.opportunities,
    strategy: plan.strategy, patterns: A.pat, weekly,
  };
}

// ---------- import ----------
function normalizeImport(it) {
  const n = v => (v == null || v === '' || isNaN(+v)) ? null : +v;
  const ts = it.ts ? +it.ts : Date.parse((it.date || '') + (String(it.date).length <= 10 ? 'T12:00:00Z' : ''));
  if (!it.id || isNaN(ts)) return null;
  return { id: String(it.id), source: it.source || 'public-scrape', type: it.type || 'REEL', ts, hasTime: !!it.ts, caption: it.caption || '', permalink: it.permalink || null, durationSec: n(it.durationSec),
    metrics: { views: n(it.views), reach: n(it.reach), likes: n(it.likes), comments: n(it.comments), shares: n(it.shares), saves: n(it.saves), avgWatchSec: n(it.avgWatchSec), totalWatchSec: null }, fetchedAt: Date.now() };
}

// ---------- router ----------

// ---------- CORS: closed by default; only origins listed in ALLOWED_ORIGINS get headers ----------
function corsFor(request, env) {
  const origin = request.headers.get('origin');
  const allowed = String(env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
  if (!origin || !allowed.includes(origin)) return null;
  return { 'access-control-allow-origin': origin, 'vary': 'Origin', 'access-control-allow-headers': 'content-type, x-admin-key, x-account', 'access-control-allow-methods': 'GET, POST, DELETE, OPTIONS' };
}
export async function handle(request, env, opts = {}) {
  const cors = corsFor(request, env);
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors || {} });
  const r = await handleInner(request, env, opts);
  if (!cors) return r;
  const h = new Headers(r.headers); for (const [k, v] of Object.entries(cors)) h.set(k, v);
  return new Response(r.body, { status: r.status, headers: h });
}

// ---------- rate limit for routes that cost AI quota (single rolling record, no growth) ----------
async function limited(store, env, now) {
  const limit = +env.RATE_LIMIT_PER_MIN || 20, minute = Math.floor(now / 60000);
  const rec = (await store.get('kv', 'rl:ai')) || { minute, n: 0 };
  const n = rec.minute === minute ? rec.n : 0;
  if (n >= limit) return true;
  await store.put('kv', 'rl:ai', { minute, n: n + 1 }, now);
  return false;
}

// ---------- assistant: map module results to HTTP. Never forwards raw AI / D1 error text. ----------
function assistantJson(r, sid) {
  if (r.ok) return J({ ok: true, sessionId: sid, reply: r.reply, saved: r.saved, hasData: r.hasData, ...(r.source ? { source: r.source } : {}), ...(r.dataQuality ? { dataQuality: r.dataQuality } : {}), ...(r.verification ? { verification: r.verification } : {}), ...(r.saved ? {} : { warning: 'answer was not saved to the history' }) });
  const code = String(r.reason || '').split(/[:\s]/)[0];
  const map = { INVALID_SESSION: [400, 'sessionId is invalid'], INVALID_INPUT: [400, 'invalid request'], INVALID_CONTEXT: [500, 'page data could not be prepared'],
    NOT_CONNECTED: [503, 'AI NOT CONNECTED'], UNSUPPORTED_PROVIDER: [503, 'AI provider is not supported for chat'], D1_ERROR: [503, 'history storage error'], EMPTY_RESPONSE: [502, 'AI returned an empty answer'] };
  const [status, error] = map[code] || [502, 'AI request failed'];
  return J({ error, code: map[code] ? code : 'AI_ERROR' }, status);
}

// ---------- Meta webhook (verify token + HMAC-SHA256 signature; events are stored, NO DM is sent) ----------
async function sameSecret(a, b) { return safeDigestEq(String(a || ''), String(b || '')); }
async function safeDigestEq(a, b) {
  if (!a || !b) return false;
  const h = async x => new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(x)));
  const [x, y] = await Promise.all([h(a), h(b)]); let r = 0; for (let i = 0; i < x.length; i++) r |= x[i] ^ y[i]; return r === 0;
}
async function hmacHex(secret, text) {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return [...new Uint8Array(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(text)))].map(b => b.toString(16).padStart(2, '0')).join('');
}
export function matchKeywordRule(text, rules) {
  const t = String(text || '').trim().toLowerCase(); if (!t) return null;
  for (const r of Array.isArray(rules) ? rules : []) {
    const kws = (Array.isArray(r?.keywords) ? r.keywords : []).map(k => String(k || '').trim().toLowerCase()).filter(Boolean);
    if (kws.some(k => t.includes(k))) return { id: r.id ?? null, sendDm: Boolean(r.sendDm) };
  }
  return null;
}
function rulesOf(env) { try { const v = JSON.parse(env.KEYWORD_RULES || '[]'); return Array.isArray(v) ? v : []; } catch { return []; } }
async function webhook(request, env, store, now) {
  const url = new URL(request.url);
  if (request.method === 'GET') {
    if (url.searchParams.get('hub.mode') === 'subscribe' && url.searchParams.get('hub.challenge')) {
      return (await sameSecret(url.searchParams.get('hub.verify_token'), env.META_VERIFY_TOKEN))
        ? new Response(url.searchParams.get('hub.challenge'), { status: 200, headers: { 'content-type': 'text/plain' } }) : new Response('Forbidden', { status: 403 });
    }
    return new Response('webhook ready', { status: 200 });
  }
  if (request.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  if (!env.META_APP_SECRET) return J({ error: 'META_APP_SECRET is not configured' }, 503);
  const raw = await request.text();
  if (raw.length > MAX_BODY) return new Response('Payload too large', { status: 413 });
  const sig = request.headers.get('x-hub-signature-256') || '';
  if (!sig.startsWith('sha256=') || !(await safeDigestEq(sig.slice(7), await hmacHex(env.META_APP_SECRET, raw)))) return new Response('Unauthorized', { status: 401 });
  let payload; try { payload = JSON.parse(raw || '{}'); } catch { return new Response('Bad Request', { status: 400 }); }
  const rules = rulesOf(env), matches = [];
  const texts = [];
  for (const e of payload.entry || []) { for (const c of e.changes || []) if (c?.value?.text) texts.push(c.value.text); for (const m of e.messaging || []) if (m?.message?.text) texts.push(m.message.text); }
  for (const t of texts) { const m = matchKeywordRule(t, rules); if (m) matches.push(m); }
  if (store) { try { await store.put('events', 'wh:' + now, { at: now, object: payload.object ?? null, entries: (payload.entry || []).length, texts: texts.length, matches }, now); } catch { /* storing an event must never fail the webhook */ } }
  return J({ success: true, received: true, matched: matches.length, dmSent: false }); // DM sending is NOT implemented
}

async function handleInner(request, env, { now = Date.now(), fetchFn = fetch } = {}) {
  const url = new URL(request.url), path = url.pathname;
  let store = null, storeErr = null;
  try { store = getStore(env); } catch (e) { storeErr = e.message; }
  if (path === '/webhook') return webhook(request, env, store, now);
  if (!path.startsWith('/api/')) {
    if (env.ASSETS) return env.ASSETS.fetch(request);
    const emb = globalThis.__IGE_EMBEDDED && globalThis.__IGE_EMBEDDED[path === '/' ? '/index.html' : path]; // single-file bundle only
    if (emb) return new Response(emb.b64 ? Uint8Array.from(atob(emb.body), c => c.charCodeAt(0)) : emb.body, { headers: { 'content-type': emb.type, 'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer', 'content-security-policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'" } });
    return new Response('Not found', { status: 404 });
  }
  if (path === '/api/health') { // public, no secrets, no data
    const d1 = await d1State(env, store);
    return J({ ok: d1.status === 'OK' || d1.status === 'NOT CONFIGURED' && !!store, worker: 'OK', d1: d1.status, time: now });
  }
  if (!env.ADMIN_KEY) return J({ error: 'ADMIN_KEY secret is not configured. Run: wrangler secret put ADMIN_KEY' }, 503);
  if (env.ADMIN_KEY.length < 16) return J({ error: 'ADMIN_KEY is too short (min 16 characters)' }, 503);
  if (!(await adminOk(request, env))) return J({ error: 'unauthorized' }, 401);
  if (path === '/api/system') return J(await system(env, store, now));
  if (path === '/api/status') {
    const sys = await system(env, store, now);
    if (!store || sys.d1.status !== 'OK' && env.ALLOW_MEMORY_STORE !== '1') return J({ system: flatSystem(sys) });
    return J({ ...(await status(env, store)), system: flatSystem(sys) });
  }
  if (!store) return J({ error: 'D1 NOT CONFIGURED', detail: storeErr }, 503);
  let body = {};
  if (request.method === 'POST' || request.method === 'DELETE') {
    const raw = await request.text();
    if (raw.length > MAX_BODY) return bad('request body too large', 413);
    if (raw) { try { body = JSON.parse(raw); } catch { return bad('invalid JSON'); } }
    if (body === null || typeof body !== 'object' || Array.isArray(body)) return bad('JSON object expected');
  }
  const acct = String(url.searchParams.get('account') || request.headers.get('x-account') || body.account || 'main').trim().toLowerCase().replace(/^@/, '');
  if (!/^[a-z0-9._]{1,30}$/.test(acct)) return bad('account must be an Instagram username (a-z, 0-9, . _ up to 30 chars)');
  if (acct !== 'main') store = scoped(store, acct); // every page gets its own data namespace in the same D1 table
  try {
    if (path === '/api/dashboard') return J(await dashboard(env, store, now));
    if (path === '/api/sync' && request.method === 'POST') return J(await runSync(env, store, { now, fetchFn }));
    if (path === '/api/plan/regenerate' && request.method === 'POST') { const { plan } = await ensurePlan(env, store, now, true, fetchFn); return J({ ok: true, mission: plan.mission, ideas: plan.ideas.length, ai: plan.ai?.status }); }
    if (path === '/api/weekly') { const { plan, A, L } = await ensurePlan(env, store, now); return J(weeklyReport({ all: A.all, daily: L.daily, stories: L.stories, profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now })); }
    if (path === '/api/token' && request.method === 'POST') {
      if (typeof body.token !== 'string' || !TOKEN_RE.test(body.token.trim())) return bad('token format invalid (20-1000 chars: letters, digits, _ - .)');
      body.token = body.token.trim();
      if (body.userId != null && !/^\d{5,25}$/.test(String(body.userId))) return bad('userId must be digits only');
      const test = new IGClient({ token: body.token, userId: body.userId || null, host: env.IG_API_HOST || 'graph.instagram.com', version: env.IG_API_VERSION || 'v25.0', fetchFn });
      let pr; try { pr = await test.profile(); } catch (e) { return J({ ok: false, error: 'Instagram rejected the token', code: e.code ?? null, message: e.message }, 400); }
      let enc; try { enc = await encrypt(env, body.token); } catch (e) { return J({ ok: false, error: e.message }, 500); }
      await store.put('kv', 'token', { enc, userId: pr.id, savedAt: now, refreshedAt: null, expiresAt: null });
      return J({ ok: true, username: pr.username, followers: pr.followers_count }); // token is never returned
    }
    if (path === '/api/ai/analyze' && request.method === 'POST') {
      if (await limited(store, env, now)) return J({ error: 'rate limit exceeded, try again in a minute' }, 429);
      const { plan, A, L } = await ensurePlan(env, store, now);
      const weekly = weeklyReport({ all: A.all, daily: L.daily, stories: L.stories, profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now });
      plan.ai = await aiAnalysis({ A, plan, weekly, env, fetchFn, now }); await store.put('plans', plan.date, plan, now);
      return J(plan.ai);
    }
    if (path === '/api/token/refresh' && request.method === 'POST') return J(await refreshToken(env, store, { now, fetchFn, force: true }));
    if (path === '/api/token' && request.method === 'DELETE') { await store.put('kv', 'token', null); return J({ ok: true }); }
    if (path === '/api/import' && request.method === 'POST') {
      let n = 0, skipped = 0;
      if (!Array.isArray(body.items)) return bad('items array required');
      if (body.items.length > MAX_IMPORT) return bad(`max ${MAX_IMPORT} items per request`, 413);
      for (const it of body.items) {
        const m = normalizeImport(it); if (!m) { skipped++; continue; }
        const old = await store.get('media', m.id);
        if (old && old.source === 'graph-api') { skipped++; continue; }
        await store.put('media', m.id, m, m.ts); n++;
      }
      return J({ ok: true, imported: n, skipped });
    }
    if (path === '/api/published' && request.method === 'POST') {
      if (body.mediaId != null && !/^[A-Za-z0-9_-]{5,40}$/.test(String(body.mediaId))) return bad('mediaId format invalid');
      if (body.date != null && !/^\d{4}-\d{2}-\d{2}$/.test(String(body.date))) return bad('date must be YYYY-MM-DD');
      const date = tehranDate(now, +env.TIMEZONE_OFFSET_MIN || 210), plan = await store.get('plans', body.date || date);
      if (!plan) return J({ error: 'no plan for that date' }, 404);
      plan.publishedMediaId = body.mediaId || null; plan.publishedIdeaId = body.ideaId || plan.ideas[0].id;
      await store.put('plans', plan.date, plan, now); return J({ ok: true });
    }
    if (['/api/audit', '/api/strategy', '/api/reel-ideas', '/api/plan'].includes(path) && request.method === 'POST') {
      if (await limited(store, env, now)) return J({ error: 'rate limit exceeded, try again in a minute' }, 429);
      const imp = Array.isArray(body.items) ? body.items : [];
      if (imp.length > MAX_IMPORT) return bad(`max ${MAX_IMPORT} items per request`, 413);
      for (const it of imp) { const m = normalizeImport(it); if (!m) continue; const old = await store.get('media', m.id); if (!(old && old.source === 'graph-api')) await store.put('media', m.id, m, m.ts); }
      const { plan, A } = await ensurePlan(env, store, now, false, fetchFn);
      const task = path.slice(5);
      const brief = await store.get('kv', 'brief');
      const raw = task === 'audit' ? buildAudit(A, acct, brief) : task === 'reel-ideas' ? buildReelIdeas(plan, A) : task === 'plan' ? buildWeeklyPlan(plan, A, now) : buildStrategy(plan, A, now, brief);
      const out = await withAISummary(task, raw, env, fetchFn);
      return J({ success: true, endpoint: task, account: acct, ai: out.ai, model: out.model, result: out.result });
    }
    if (path === '/api/profile' && request.method === 'GET') return J({ brief: (await store.get('kv', 'brief')) || null });
    if (path === '/api/profile' && request.method === 'POST') {
      const f = (k, n) => body[k] == null ? '' : String(body[k]).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);
      const brief = { niche: f('niche', 120), audience: f('audience', 300), goal: f('goal', 200), offer: f('offer', 200), updatedAt: now };
      if (typeof body.audience !== 'undefined' && typeof body.audience !== 'string') return bad('audience must be text');
      await store.put('kv', 'brief', brief, now); return J({ ok: true, brief });
    }
    if (path === '/api/content' && request.method === 'GET') return J({ items: await store.list('library', { limit: 200 }) });
    if (path === '/api/content' && request.method === 'POST') {
      if (typeof body.ideaId !== 'string' || !/^[0-9A-Za-z:_-]{5,80}$/.test(body.ideaId)) return bad('ideaId invalid');
      if (!['idea', 'filmed', 'published', 'skipped'].includes(body.status)) return bad('status must be idea|filmed|published|skipped');
      const prev = (await store.get('library', body.ideaId)) || {};
      const item = { ...prev, ideaId: body.ideaId, status: body.status, note: body.note == null ? (prev.note || '') : String(body.note).slice(0, 500), hook: body.hook == null ? (prev.hook || null) : String(body.hook).slice(0, 200), updatedAt: now };
      await store.put('library', body.ideaId, item, now); return J({ ok: true, item });
    }
    if (path === '/api/keywords/test' && request.method === 'POST') {
      if (typeof body.text !== 'string' || body.text.length > 500) return bad('text (max 500 chars) required');
      const m = matchKeywordRule(body.text, rulesOf(env));
      return J({ success: true, matched: !!m, rule: m, dmSent: false });
    }
    if (path === '/api/coach' && request.method === 'POST') {
      if (await limited(store, env, now)) return J({ error: 'rate limit exceeded, try again in a minute' }, 429);
      if (typeof body.q !== 'string' || !body.q.trim()) return bad('q (question) required');
      if (body.q.length > MAX_Q) return bad(`question too long (max ${MAX_Q} chars)`);
      const { plan, A, L } = await ensurePlan(env, store, now);
      const weekly = weeklyReport({ all: A.all, daily: L.daily, stories: L.stories, profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now });
      return J(await coachAnswer({ q: body.q.trim(), A, plan, weekly, env, fetchFn, brief: await store.get('kv', 'brief') }));
    }
    if (path === '/api/assistant' && request.method === 'POST') { // multi-turn chat. Account = the scoped store chosen above; the session id never decides access.
      const sid = body.sessionId === undefined ? newSessionId() : body.sessionId;
      if (!isSessionId(sid)) return bad('sessionId is invalid');
      if (typeof body.message !== 'string' || !body.message.trim()) return bad('message (string) required');
      if (body.message.length > ASSISTANT_MAX_CHARS) return bad(`message too long (max ${ASSISTANT_MAX_CHARS} chars)`);
      let ctx;
      try { // D1 failures here become a controlled 503 (no raw error text)
        if (await limited(store, env, now)) return J({ error: 'rate limit exceeded, try again in a minute' }, 429);
        const { plan, A, L } = await ensurePlan(env, store, now);
        ctx = { A, plan, weekly: weeklyReport({ all: A.all, daily: L.daily, stories: L.stories, profile: A.p, pat: A.pat, stuck: A.stuck, strategy: plan.strategy, now }) };
      } catch { return J({ error: 'page data could not be loaded', code: 'D1_ERROR' }, 503); }
      return assistantJson(await assistantReply({ store, env, sid, message: body.message, ...ctx, now }), sid);
    }
    if (path === '/api/assistant/history' && request.method === 'GET') {
      const sid = url.searchParams.get('sessionId');
      if (!isSessionId(sid)) return bad('sessionId is invalid');
      const h = await loadHistory(store, sid, { limit: 50 });
      return h.ok ? J({ ok: true, sessionId: sid, messages: h.messages }) : assistantJson(h, sid);
    }
    if (path === '/api/assistant/clear' && request.method === 'POST') {
      if (!isSessionId(body.sessionId)) return bad('sessionId is invalid');
      const c = await clearHistory(store, env, body.sessionId);
      return c.ok ? J({ ok: true }) : assistantJson(c, body.sessionId);
    }
    return J({ error: 'not found' }, 404);
  } catch (e) { return J({ error: 'internal', message: e.message }, 500); }
}

export default {
  fetch: (req, env) => handle(req, env),
  async scheduled(event, env, ctx) {
    let store; try { store = getStore(env); } catch { return; }
    const now = Date.now();
    ctx.waitUntil((async () => {
      try { await refreshToken(env, store, { now }); } catch { /* never block the daily plan */ }
      try { await runSync(env, store, { now }); } catch { /* sync failure is recorded in lastSync / status */ }
      try { await ensurePlan(env, store, now, true, fetch); } catch { /* D1/plan failure visible in /api/system */ }
    })());
  },
};
