// Content engine: patterns, adaptive strategy, idea generation (anti-repeat), scoring, stories, mission, weekly report.
import { DNA, clamp, median, enrich, hookFeatures, ctaType, jaccard, scoreFromRatio, computeProfile, growthHealth, stuckDetector, engRate } from './analysis.js';

const DAY = 86400000;
export const tehranDate = (now = Date.now(), offMin = 210) => new Date(now + offMin * 60000).toISOString().slice(0, 10);
function rng(seedStr) { let h = 1779033703 ^ seedStr.length; for (let i = 0; i < seedStr.length; i++) { h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353); h = h << 13 | h >>> 19; } return () => { h = Math.imul(h ^ h >>> 16, 2246822507); h = Math.imul(h ^ h >>> 13, 3266489909); h ^= h >>> 16; return (h >>> 0) / 4294967296; }; }
const pick = (arr, r) => arr[Math.floor(r() * arr.length)];

// ---------- patterns (what works for THIS page) ----------
export function patterns(all) {
  const reels = all.filter(m => m.type === 'REEL' && m.metrics?.views != null);
  const overall = median(reels.map(r => r.metrics.views));
  const group = keyFn => {
    const g = {};
    reels.forEach(r => { const k = keyFn(r); (g[k] = g[k] || []).push(r.metrics.views); });
    return Object.entries(g).map(([k, v]) => ({ key: k, n: v.length, median: median(v), ratio: overall ? median(v) / overall : null }))
      .filter(x => x.n >= 2).sort((a, b) => b.ratio - a.ratio);
  };
  const hourG = {};
  reels.filter(r => r.hasTime).forEach(r => { const h = new Date(r.ts + 210 * 60000).getUTCHours(); (hourG[h] = hourG[h] || []).push(r.metrics.views); });
  const hours = Object.entries(hourG).map(([h, v]) => ({ key: +h, n: v.length, median: median(v) })).filter(x => x.n >= 2).sort((a, b) => b.median - a.median);
  return { overallMedian: overall, n: reels.length,
    byTopic: group(r => r.topic), byDuration: group(r => r.durationBucket), byHook: group(r => r.hookFeatures[0]), byCta: group(r => r.cta), hours };
}

// ---------- adaptive strategy ----------
export function adapt(profile, pat, all) {
  const notes = []; let mode = 'EXPLORE'; const boost = {}; const avoid = [];
  const recent3 = all.filter(m => m.type === 'REEL').sort((a, b) => b.ts - a.ts).slice(0, 3);
  const best = pat.byTopic[0], worst = pat.byTopic[pat.byTopic.length - 1];
  if (profile.lastThreeBelow) {
    mode = 'PIVOT'; recent3.forEach(r => avoid.push(r.topic));
    notes.push('۳ ریلز اخیر پشت سر هم زیر ۸۰٪ میانه بودند → استراتژی عوض می‌شود: موضوع‌های همین ۳ ریلز امروز کنار گذاشته شدند.');
  }
  if (best && best.ratio >= 1.4) {
    boost.topic = best.key; if (mode !== 'PIVOT') mode = 'DOUBLE_DOWN';
    notes.push(`موضوع «${best.key}» ${best.ratio.toFixed(1)} برابر میانه بازدید دارد → زاویه‌های جدید از همین الگو ساخته می‌شود.`);
  }
  if (worst && worst.ratio <= 0.7 && worst.key !== best?.key) { avoid.push(worst.key); notes.push(`موضوع «${worst.key}» زیر ۷۰٪ میانه است → امروز پیشنهاد نمی‌شود.`); }
  const bh = pat.byHook[0]; if (bh && bh.ratio >= 1.3) { boost.hook = bh.key; notes.push(`الگوی هوک «${bh.key}» بهتر جواب داده → هوک‌های مشابه ولی جدید تولید می‌شوند.`); }
  if (!notes.length) notes.push(pat.n < 8 ? `${DNA}: برای تشخیص الگو حداقل ۸ ریلز با آمار لازم است؛ امروز حالت EXPLORE (تست زوایای متنوع).` : 'الگوی روشنی دیده نشد → EXPLORE.');
  return { mode, boost, avoid: [...new Set(avoid)], notes };
}

// ---------- idea library ----------
const ANGLES = ['بعد از شیفت شب', 'قبل از آژیر بعدی', 'با لباس کامل PPE', 'فقط با ۶۰ ثانیه وقت', 'در حیاط ایستگاه', 'با همکارم', 'ساعت ۵ صبح', 'با کوله ۲۰ کیلویی', 'با ساعت‌شمار روی صفحه', 'نسخه سخت‌ترش', 'بدون هیچ وسیله‌ای', 'با رکورد هفته پیش'];
const TAGS = '#آتش_نشانی #آتش_نشان #بدنسازی #تمرین #Firefighter #FirefighterFitness';
export const TEMPLATES = [
  { id: 'strength_test', topic: 'challenge', title: 'تست قدرت آتش‌نشان', hooks: ['فکر می‌کنی آتش‌نشان فقط باید قوی باشه؟ این تست {a} رو ببین', 'چند تکرار می‌تونم بزنم {a}؟ حدس بزن', '۳ ست بدون استراحت {a}. تا آخر ببین'],
    scenario: 'یک حرکت (شنا/بارفیکس) تا ناتوانی؛ شمارنده روی صفحه؛ ثانیه آخر عدد نهایی و واکنش.', onCamera: 'حرکت را بدون برش انجام بده؛ فقط یک بار نفس‌نفس بزن و عدد را بگو.', overlay: 'چند تکرار؟ ←  عدد نهایی', dur: 15, ctas: ['شما چند تا می‌زنید؟ عدد رو کامنت کن', 'قدرت مهم‌تره یا استقامت؟'], goal: 'کامنت + اشتراک', f: { share: .7, save: .2, follow: .6, loop: 1 } },
  { id: 'station_workout', topic: 'training', title: 'تمرین در ایستگاه با وسایل موجود', hooks: ['تو ایستگاه جیم نیست؛ این ۴ حرکت {a}', 'تمرین کامل بدن با وسایل ایستگاه {a}', 'بی‌بهانه‌ترین تمرین دنیا {a}'],
    scenario: '۴ حرکت با وسایل واقعی ایستگاه (تایر، شیلنگ، کپسول خالی، چهارپایه)؛ هر حرکت ۳ ثانیه با اسم.', onCamera: 'هر حرکت را سریع نشان بده و اسم حرکت را بگو.', overlay: '۴ حرکت، ۰ بهانه', dur: 20, ctas: ['ذخیره کن برای شیفت بعدیت', 'کدوم حرکت رو امتحان می‌کنی؟'], goal: 'ذخیره + فالو', f: { share: .5, save: .9, follow: .6, loop: .5 } },
  { id: 'after_shift', topic: 'training', title: 'تمرین بعد از شیفت ۲۴ ساعته', hooks: ['۲۴ ساعت بیدار بودم؛ حالا باشگاه {a}', 'خسته‌ترین ست من {a}', 'وقتی شیفت تموم شد، تازه تمرین شروع می‌شه'],
    scenario: 'خروج از ایستگاه ← ورود به باشگاه ← یک ست سنگین ← واکنش واقعی.', onCamera: 'با لباس شیفت وارد باشگاه شو؛ حال واقعی را بگو.', overlay: 'شیفت ۲۴ ساعته + تمرین', dur: 18, ctas: ['تو بعد کار تمرین می‌کنی یا قبلش؟', 'یه نفر رو تگ کن که بهانه می‌آره'], goal: 'هویت + فالو', f: { share: .6, save: .3, follow: .8, loop: .5 } },
  { id: 'ff_vs_bb', topic: 'challenge', title: 'آتش‌نشان در برابر بدنساز', hooks: ['بدنساز یا آتش‌نشان؟ کی تو این تست برنده‌ست', 'همون تست؛ دو بدن متفاوت {a}', 'بدن بدنساز قوی‌تره یا بدن آتش‌نشان؟'],
    scenario: 'یک تست یکسان (حمل وزنه/پله/دویدن) برای یک بدنساز و تو؛ مقایسه زمان.', onCamera: 'هر دو نفر را در یک قاب نشان بده؛ زمان‌ها را روی صفحه بنویس.', overlay: 'آتش‌نشان VS بدنساز', dur: 20, ctas: ['تو کدوم تیمی؟ بنویس A یا B', 'این رو برای رفیق بدنسازت بفرست'], goal: 'اشتراک + کامنت', f: { share: .9, save: .2, follow: .7, loop: 1 } },
  { id: 'fitness_test', topic: 'challenge', title: 'تست آمادگی جسمانی با زمان', hooks: ['این تست رو ۹۰٪ آدم‌ها تو {a} ردش می‌کنن', 'تست آمادگی آتش‌نشان‌ها؛ زمان من چقدره؟', 'می‌تونی زیر ۲ دقیقه تموم کنی؟'],
    scenario: 'یک مسیر ثابت: حمل شیلنگ + پله + کشیدن مانکن/کیسه؛ تایمر روی صفحه.', onCamera: 'تایمر را نشان بده؛ پایان با زمان نهایی.', overlay: 'زمان من: ؟؟:؟؟', dur: 25, ctas: ['زمانت رو بنویس ببینم می‌شکنی؟', 'ذخیره کن و با رفیقت امتحان کن'], goal: 'چالش + اشتراک', f: { share: .8, save: .6, follow: .6, loop: 1 } },
  { id: 'squat_record', topic: 'training', title: 'رکورد اسکوات', hooks: ['رکورد اسکوات من {a}؛ سنگین‌تر از اون چیزی که فکر می‌کنی', 'این وزنه جون آدم رو نجات نمی‌ده ولی...', 'ست آخرم رو ببین'],
    scenario: 'ست رکورد از زاویه کنار؛ روی صفحه وزن؛ نفس آخر.', onCamera: 'وزن را قبل از شروع نشان بده؛ بدون حرف اضافه.', overlay: 'رکورد: ___ کیلو', dur: 12, ctas: ['رکورد خودت چنده؟', 'می‌خوای برنامه تمرین پاهام رو بذارم؟'], goal: 'کامنت + فالو', f: { share: .5, save: .4, follow: .5, loop: .5 } },
  { id: 'ppe_training', topic: 'training', title: 'تمرین با تجهیزات کامل', hooks: ['۲۵ کیلو تجهیزات روی تنم؛ ۳ حرکت ساده {a}', 'چرا آتش‌نشان‌ها با لباس کامل تمرین می‌کنن؟', 'همین حرکت بدون لباس راحته؛ با لباس...'],
    scenario: 'یک حرکت بدون تجهیزات ← همان حرکت با PPE؛ مقایسه تعداد/زمان.', onCamera: 'تفاوت نفس و سرعت را نشان بده.', overlay: 'بدون تجهیزات VS با تجهیزات', dur: 20, ctas: ['به نظرت چند دقیقه دووم می‌آری؟', 'بفرست برای کسی که فکر می‌کنه آتش‌نشانی راحته'], goal: 'اشتراک', f: { share: .8, save: .3, follow: .7, loop: 1 } },
  { id: 'fire_mistakes', topic: 'bodybuilding', title: '۳ اشتباه بدنسازی آتش‌نشان‌ها', hooks: ['۳ اشتباهی که اکثر آتش‌نشان‌ها تو باشگاه می‌کنن', 'اگه آتش‌نشانی، این تمرین رو اشتباه انجام می‌دی', 'بدنسازی که به کار آتش‌نشانی نمی‌آد'],
    scenario: 'هر اشتباه ۵ ثانیه: نشان بده + درستش را بگو. در آخر مورد سوم غافلگیری.', onCamera: 'مستقیم به دوربین، سه انگشت، سریع.', overlay: '۱ ... ۲ ... ۳', dur: 22, ctas: ['ذخیره کن تا فراموش نکنی', 'کدومش رو تا حالا مرتکب شدی؟'], goal: 'ذخیره', f: { share: .5, save: 1, follow: .6, loop: .5 } },
  { id: 'hard_truths', topic: 'job', title: 'واقعیت‌های سخت شغل آتش‌نشانی', hooks: ['چیزی که کسی درباره آتش‌نشانی بهت نمی‌گه', '۳ واقعیت تلخ شغل من', 'مردم فکر می‌کنن ما فقط آتیش خاموش می‌کنیم'],
    scenario: 'سه واقعیت (کم‌خوابی، تماس‌های غیر آتش، استرس) هرکدام یک نمای واقعی از ایستگاه.', onCamera: 'آرام و صادق صحبت کن؛ بدون شعار.', overlay: 'واقعیت ۱/۲/۳', dur: 25, ctas: ['شما کدومش رو نمی‌دونستید؟', 'بفرست برای کسی که شغل ما رو دست‌کم می‌گیره'], goal: 'اشتراک + فالو', f: { share: .9, save: .4, follow: .8, loop: .5 } },
  { id: 'str_vs_end', topic: 'challenge', title: 'قدرت یا استقامت؟', hooks: ['فکر می‌کنی آتش‌نشان فقط باید قوی باشه؟', 'قدرت یا استقامت؟ امروز با عدد جواب می‌دم {a}', 'یک تست، دو نتیجه؛ کدوم مهم‌تره؟'],
    scenario: 'یک ست حداکثر وزن (قدرت) + یک ست زمان‌دار سبک (استقامت)؛ مقایسه کنار هم.', onCamera: 'هر دو ست را کوتاه نشان بده و نتیجه را روی صفحه بنویس.', overlay: 'قدرت ⟷ استقامت', dur: 12, ctas: ['قدرت مهم‌تره یا استقامت؟', 'رأی بده و دلیلت رو بنویس'], goal: 'کامنت', f: { share: .6, save: .2, follow: .5, loop: .5 } },
  { id: 'before_after', topic: 'training', title: 'قبل و بعد از تمرین', hooks: ['۶۰ ثانیه قبل و بعد از تمرین {a}', 'ضربان قلبم رو ببین', 'این یک تمرین چقدر منو عوض کرد؟'],
    scenario: 'نمای قبل: آرام/ضربان؛ نمای بعد: همان زاویه با عرق و ضربان.', onCamera: 'ساعت هوشمند را نشان بده.', overlay: 'قبل → بعد', dur: 10, ctas: ['تمرین بعدی رو تو انتخاب کن (کامنت)', 'ذخیره کن برای انگیزه'], goal: 'تماشا کامل', f: { share: .4, save: .5, follow: .4, loop: .5 } },
  { id: 'day_24h', topic: 'job', title: 'پشت‌صحنه ۲۴ ساعت شیفت', hooks: ['۲۴ ساعت از زندگی یک آتش‌نشان {a}', 'ساعت ۳ صبح تو ایستگاه چی می‌گذره؟', 'یه شیفت کامل در ۳۰ ثانیه'],
    scenario: 'کلیپ‌های کوتاه ساعت‌دار: صبح، غذا، تمرین، آژیر، شب.', onCamera: 'هر کلیپ ۳ ثانیه با ساعت روی صفحه.', overlay: '۰۷:۰۰ ← ۰۷:۰۰', dur: 30, ctas: ['بخش بعدی رو می‌خوای؟ بنویس «بخش ۲»', 'فالو کن تا شیفت بعدی رو ببینی'], goal: 'فالو', f: { share: .6, save: .3, follow: .9, loop: 1 } },
  { id: 'siren_ready', topic: 'mindset', title: 'وقتی آژیر زد (لحظه واقعی)', hooks: ['من برای دیده شدن تمرین نمی‌کنم؛ برای آماده بودن', '۳۰ ثانیه تا حرکت؛ این اتفاق‌هاست', 'صدای آژیر که بیاد، من چه کار می‌کنم؟'],
    scenario: 'صدای واقعی آژیر + لباس پوشیدن/سوار شدن؛ بدون موزیک غیرضروری؛ یک جمله احساسی.', onCamera: 'فقط حرکت واقعی؛ یک جمله کوتاه در پایان.', overlay: 'آماده‌ام برای روزی که...', dur: 20, ctas: ['این ریلز رو برای کسی بفرست که بهش افتخار می‌کنی', 'تو برای چی تمرین می‌کنی؟'], goal: 'اشتراک + فالو', f: { share: .8, save: .3, follow: .9, loop: 1 } },
];


// ---------- Reels Studio extras (script, storyboard, filming/editing guidance, post-publish metrics) ----------
const SCRIPTS = {
  strength_test: '«{hook}». [حرکت را بدون برش انجام بده و بلند بشمار] «این عدد منه. حالا نوبت توئه؛ چند تا می‌زنی؟»',
  station_workout: '«{hook}». [هر حرکت را با اسمش بگو] «ذخیره کن تا شیفت بعدی انجامش بدی.»',
  after_shift: '«{hook}». [حال واقعی‌ات را بگو] «خسته‌ام ولی ست آخر را می‌زنم. تو بعد از کار تمرین می‌کنی؟»',
  ff_vs_bb: '«{hook}». [نتیجه هر دو نفر را بگو] «حالا تو بگو: تیم A یا تیم B؟»',
  fitness_test: '«{hook}». [تایمر را نشان بده] «زمان من این بود. می‌تونی بشکنی؟ زمانت را بنویس.»',
  squat_record: '«{hook}». [وزن را نشان بده، ست را بدون حرف انجام بده] «رکورد خودت چنده؟»',
  ppe_training: '«{hook}». [بدون تجهیزات، بعد با تجهیزات] «فرق را دیدی؟ برای کسی بفرست که فکر می‌کنه آتش‌نشانی راحته.»',
  fire_mistakes: '«{hook}». [اشتباه اول، دوم، سوم؛ هرکدام ۵ ثانیه با راه‌حل] «ذخیره کن تا فراموش نکنی.»',
  hard_truths: '«{hook}». [سه واقعیت با نمای واقعی، آرام و صادق] «کدومش را نمی‌دونستی؟»',
  str_vs_end: '«{hook}». [ست قدرت، بعد ست استقامت] «به نظرت کدوم مهم‌تره؟ رأی بده.»',
  before_after: '«{hook}». [ضربان قلب قبل و بعد را نشان بده] «تمرین بعدی را تو انتخاب کن.»',
  day_24h: '«{hook}». [کلیپ‌های ۳ ثانیه‌ای با ساعت روی صفحه] «بخش بعدی را می‌خوای؟ فالو کن و بنویس بخش بعدی.»',
  siren_ready: '«{hook}». [صدای آژیر، آماده شدن، یک جمله پایانی] «تو برای چی تمرین می‌کنی؟»',
};
export const FILMING = 'قاب عمودی ۹:۱۶، نور طبیعی یا نور باشگاه، گوشی ثابت، صدای واقعی (آژیر، وزنه) را نگه دار، صورت و یونیفرم در قاب باشد.';
export const EDITING = 'هر ۲ تا ۳ ثانیه یک برش، زیرنویس فارسی درشت، هوک در ۳ ثانیه اول، موسیقی کم‌صدا روی حرف.';
export const REVIEW_METRICS = ['Views', 'Reach', 'Shares', 'Saves', 'Avg watch time', 'Follows از پروفایل'];
export function reelExtras(t, hook) {
  const beats = t.scenario.split(/؛|←/).map(x => x.trim().replace(/\.$/, '')).filter(Boolean);
  const per = Math.max(2, Math.round(t.dur / Math.max(beats.length, 1)));
  return { storyboard: beats.map((b, i) => ({ scene: i + 1, shot: b, seconds: per })), script: (SCRIPTS[t.id] || '«{hook}»').replace('{hook}', hook),
    filming: FILMING, editing: EDITING, reviewMetrics: REVIEW_METRICS, audience: 'مخاطب هدف را در تب ممیزی (بریف) وارد کن؛ بدون آن «DATA NOT AVAILABLE» است.' };
}

// ---------- scoring ----------
export function scoreIdea(c, ctx = {}) {
  const hook = c.hook, f = c.f || {}, hf = hookFeatures(hook), words = hook.split(/\s+/).length;
  const learnedT = ctx.pat?.byTopic?.find(x => x.key === c.topic)?.ratio ?? null;
  const bonus = learnedT == null ? 0 : learnedT >= 1.4 ? 3 : learnedT <= 0.7 ? -3 : 0;
  const hookS = clamp(8 + (hf.includes('question') || hf.includes('number') ? 4 : 0) + (words <= 10 ? 4 : words <= 14 ? 2 : 0) + (hf.includes('stay') || /چرا|اشتباه|حدس|ببین|واقعیت|بهت نمی‌گه/.test(hook) ? 4 : 0) + (ctx.boost?.hook && hf.includes(ctx.boost.hook) ? 2 : 0), 0, 20);
  const retS = clamp(8 + (c.dur <= 20 ? 6 : c.dur <= 35 ? 3 : 0) + (f.loop ? 3 : 0) + (/تا آخر|آخر/.test(hook) ? 3 : 0) + bonus, 0, 20);
  const shareS = clamp(Math.round((f.share || 0) * 10) + (/بفرست|تگ/.test(c.cta) ? 3 : 0), 0, 15);
  const saveS = clamp(Math.round((f.save || 0) * 10), 0, 10);
  const comS = /[؟?]/.test(c.cta) && / یا /.test(c.cta) ? 10 : /[؟?]/.test(c.cta) ? 6 : /کامنت|بنویس/.test(c.cta) ? 5 : 2;
  const folS = clamp(Math.round((f.follow || 0) * 10) + (/بخش|فالو/.test(c.cta) ? 3 : 0) + (c.topic === 'job' || c.topic === 'mindset' ? 2 : 0) + (bonus > 0 ? 1 : 0), 0, 15);
  const sim = Math.max(0, ...(ctx.memHooks || []).map(h => jaccard(hook, h)));
  const orgS = clamp(Math.round(10 * (1 - sim)), 0, 10);
  const total = hookS + retS + shareS + saveS + comS + folS + orgS;
  const tier = total >= 90 ? 'PRIORITY' : total >= 80 ? 'STRONG' : total >= 70 ? 'TEST' : 'REWORK';
  return { total, tier, parts: { hook: hookS, retention: retS, share: shareS, save: saveS, comment: comS, follow: folS, originality: orgS },
    viralEstimate: Math.round((hookS / 20 * 0.3 + retS / 20 * 0.35 + shareS / 15 * 0.35) * 100), followEstimate: Math.round(folS / 15 * 100), maxSimilarity: Math.round(sim * 100) };
}

// ---------- idea generation (anti-repeat) ----------
export function generateIdeas({ date, count = 5, memory, strategy, pat }) {
  const r = rng('ige:' + date);
  const memHooks = memory.hooks, usedKeys = new Set(memory.keys);
  const cands = [];
  for (const t of TEMPLATES) {
    if (strategy.avoid.includes(t.topic)) continue;
    for (const h of t.hooks) for (let k = 0; k < 2; k++) {
      const a = pick(ANGLES, r), hook = h.replace('{a}', a).replace(/\s+؟/, '؟').trim();
      const key = `${t.id}|${a}`;
      const c = { id: `${date}:${t.id}:${cands.length}`, key, templateId: t.id, topic: t.topic, title: `${t.title} — ${a}`, hook, scenario: t.scenario, onCamera: `${t.onCamera} (زاویه: ${a})`, overlay: t.overlay,
        dur: t.dur, cta: pick(t.ctas, r), goal: t.goal, f: t.f };
      c.caption = `${hook}\n\n${t.scenario.split('؛')[0]}.\n${c.cta}\n\n${TAGS}`;
      Object.assign(c, reelExtras(t, hook));
      cands.push(c);
    }
  }
  const ctx = { memHooks, pat, boost: strategy.boost };
  let scored = cands.filter(c => !usedKeys.has(c.key) && Math.max(0, ...memHooks.map(h => jaccard(c.hook, h))) < 0.5)
    .map(c => ({ ...c, score: scoreIdea(c, ctx) }));
  if (strategy.boost.topic) scored.forEach(c => { if (c.topic === strategy.boost.topic) c.score.total = Math.min(100, c.score.total + 2); });
  scored.sort((a, b) => b.score.total - a.score.total || (r() - 0.5));
  const out = [], perTopic = {}, seenT = new Set();
  for (const c of scored) {
    if (seenT.has(c.templateId) || (perTopic[c.topic] || 0) >= 2) continue;
    // reject near-duplicates inside today's list
    if (out.some(o => jaccard(o.hook, c.hook) > 0.45)) continue;
    out.push(c); perTopic[c.topic] = (perTopic[c.topic] || 0) + 1; seenT.add(c.templateId);
    if (out.length >= count) break;
  }
  return { ideas: out.map(({ f, ...rest }) => rest), rest: scored.filter(c => !out.includes(c)).slice(0, 6).map(({ f, ...x }) => x) };
}

export function memoryFrom(all, pastIdeas, now = Date.now()) {
  const hooks = [...all.map(m => m.hook).filter(Boolean), ...pastIdeas.map(i => i.hook)];
  const keys = pastIdeas.filter(i => i.ts > now - 30 * DAY).map(i => i.key);
  return { hooks, keys };
}

// ---------- stories ----------
export function buildStories(topIdea, publishAt, timeSource) {
  const [ph, pm] = publishAt.split(':').map(Number);
  const T = (dh, dm = 0) => { let m = ph * 60 + pm + dh * 60 + dm; m = (m + 1440) % 1440; return String(m / 60 | 0).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
  const opts = (topIdea.cta.includes(' یا ') ? topIdea.cta.replace(/[؟?]/g, '').split(' یا ').map(s => s.split(/\s+/).slice(-2).join(' ')) : ['موافقم', 'نه']).slice(0, 2);
  return [
    { n: 1, time: '09:00', text: 'صبح بخیر از ایستگاه؛ امروز شیفت منه. حدس بزنید امشب چی می‌ذارم؟', media: 'ویدیو ۵ ثانیه‌ای/عکس سلفی از ایستگاه یا باشگاه', sticker: 'Question: «حدس بزن امشب چی می‌ذارم»', cta: 'جواب بده تا بهت اشاره کنم', goal: 'شروع تعامل + پاسخ DM' },
    { n: 2, time: '12:30', text: topIdea.hook.slice(0, 60) + '…', media: 'یک ثانیه از تمرین/ایستگاه', sticker: `Poll: ${opts[0]} / ${opts[1]}`, cta: 'رأی بده', goal: 'تعامل + بازخورد موضوع' },
    { n: 3, time: '17:00', text: 'امشب ساعت ' + publishAt + ' یه چیزی می‌ذارم که...', media: '۳ ثانیه تیزر بدون لو دادن نتیجه', sticker: 'Countdown به ساعت انتشار', cta: 'یادآوری فعال کن', goal: 'هدایت به ریلز' },
    { n: 4, time: publishAt, text: 'ریلز جدید آمد؛ ببین و بگو چند شدی', media: 'ریلز را به استوری Share کن', sticker: 'Reel share + Question sticker', cta: 'ببین و جواب بده', goal: 'هدایت به ریلز' },
    { n: 5, time: T(1, 15), text: 'نتیجه رأی‌گیری ظهر + جواب بهترین کامنت‌ها', media: 'اسکرین‌شات نتیجه Poll + ۳ کامنت', sticker: 'Question: «تو چقدر زدی؟»', cta: 'تو هم بگو', goal: 'تعامل واقعی' },
    { n: 6, time: T(2, 15), text: 'اگه از این محتوا خوشت اومد فالو کن؛ هر روز یه تمرین/لحظه واقعی از شیفت می‌ذارم', media: 'سلفی کوتاه به پروفایل اشاره', sticker: 'Link/Profile mention', cta: 'فالو کن', goal: 'تبدیل به فالوور' },
  ].map(s => ({ ...s, timeSource: s.n === 1 || s.n === 2 || s.n === 3 ? 'default' : timeSource }));
}

// ---------- mission ----------
export function buildMission({ date, publishAt, timeSource, ideas, stories, strategy, yesterday }) {
  const top = ideas[0];
  const [ph, pm] = publishAt.split(':').map(Number);
  const T = (dm) => { const m = ph * 60 + pm + dm; return String((m / 60 | 0) % 24).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
  return { date, headline: `امروز یک ریلز بساز: «${top.title}»`, top: { hook: top.hook, duration: top.dur, publishAt, cta: top.cta, score: top.score.total, tier: top.score.tier },
    why: strategy.notes, yesterday: yesterday || null,
    steps: [
      { time: '09:00', task: `Story 1 → ${stories[0].sticker}` },
      { time: '12:30', task: `Story 2 → ${stories[1].sticker}` },
      { time: '17:00', task: `آماده‌سازی و فیلم‌برداری ریلز «${top.title}» (${top.dur} ثانیه)` },
      { time: publishAt, task: `انتشار ریلز — هوک: «${top.hook}» — CTA: «${top.cta}»` },
      { time: `${publishAt}–${T(30)}`, task: 'پاسخ به همه کامنت‌ها (۳۰ دقیقه اول مهم‌ترین است)' },
      { time: T(75), task: `Story 5 + 6 (نتیجه رأی‌گیری + CTA فالو)` },
      { time: 'قبل خواب', task: 'ثبت شماره پست در سیستم (/api/published) و بررسی اولیه عملکرد' },
    ], timeSource };
}

// ---------- yesterday decision (learn loop) ----------
export function measureYesterday(plan, all, pat) {
  if (!plan) return { status: 'NO_PLAN', text: `${DNA}: دیروز برنامه‌ای ثبت نشده است.` };
  const mediaId = plan.publishedMediaId;
  const m = mediaId ? all.find(x => x.id === mediaId) : null;
  if (!m) return { status: 'UNLINKED', text: `${DNA}: ریلز دیروز به برنامه متصل نشده. با POST /api/published شماره پست را ثبت کن تا سیستم یاد بگیرد.` };
  const ratio = pat.overallMedian && m.metrics?.views != null ? m.metrics.views / pat.overallMedian : null;
  if (ratio == null) return { status: 'NO_METRICS', text: `${DNA}: آمار پست دیروز هنوز موجود نیست.` };
  const verdict = ratio >= 1.4 ? 'WIN' : ratio >= 0.8 ? 'OK' : 'WEAK';
  return { status: verdict, ratio: +ratio.toFixed(2), views: m.metrics.views, text: verdict === 'WIN' ? `ریلز دیروز ${ratio.toFixed(1)} برابر میانه بود؛ امروز زوایای جدید از همین الگو.` : verdict === 'WEAK' ? `ریلز دیروز ${ratio.toFixed(1)} برابر میانه بود؛ امروز الگو عوض می‌شود.` : 'ریلز دیروز نزدیک میانه بود؛ ادامه با تست زوایا.' };
}

// ---------- weekly report ----------
export function weeklyReport({ all, daily, stories, profile, pat, stuck, strategy, now = Date.now() }) {
  const w = all.filter(m => m.ts > now - 7 * DAY), reelsW = w.filter(m => m.type === 'REEL' && m.metrics?.views != null);
  const by = (arr, fn) => arr.slice().sort((a, b) => fn(b) - fn(a));
  const best = by(reelsW, r => r.metrics.views)[0] || null, worst = by(reelsW, r => -r.metrics.views)[0] || null;
  const brief = r => r ? { id: r.id, permalink: r.permalink, views: r.metrics.views, hook: r.hook, topic: r.topic } : null;
  const reels30 = all.filter(m => m.type === 'REEL' && m.metrics?.views != null && m.ts > now - 30 * DAY);
  const bestAll = by(reels30, r => r.metrics.views)[0];
  const stBest = by(stories.filter(s => s.metrics?.reach != null && s.ts > now - 7 * DAY), s => s.metrics.reach)[0];
  const cont = [], stop = [];
  if (pat.byTopic[0]) cont.push(`ادامه موضوع «${pat.byTopic[0].key}» (${pat.byTopic[0].ratio.toFixed(1)}x میانه)`);
  if (pat.byHook[0]) cont.push(`ادامه هوک نوع «${pat.byHook[0].key}»`);
  if (pat.byDuration[0]) cont.push(`ادامه فرمت ${pat.byDuration[0].key}`);
  const wt = pat.byTopic[pat.byTopic.length - 1]; if (wt && wt.ratio < 0.8) stop.push(`توقف/کاهش موضوع «${wt.key}» (${wt.ratio.toFixed(1)}x)`);
  stuck.problems.slice(0, 3).forEach(p => stop.push(`رفع: ${p.title}`));
  while (cont.length < 3) cont.push(`${DNA} (آمار کافی برای تشخیص نیست)`);
  while (stop.length < 3) stop.push(`${DNA} (آمار کافی برای تشخیص نیست)`);
  return {
    period: '7-DAY GROWTH REPORT',
    followerGrowth: profile.followDelta7 != null ? { delta: profile.followDelta7, pct: +profile.followGrowthPct7.toFixed(2) } : DNA,
    bestReel: brief(best) || brief(bestAll) && { ...brief(bestAll), note: 'no reel in the last 7d; best of last 30d' } || DNA,
    weakestReel: brief(worst) || DNA,
    bestHook: (best || bestAll)?.hook || DNA,
    bestTopic: pat.byTopic[0] ? `${pat.byTopic[0].key} (${pat.byTopic[0].ratio.toFixed(1)}x)` : DNA,
    bestPostingTime: pat.hours[0] ? `${pat.hours[0].key}:00` : DNA + ' (public data has no post time; needs Graph API)',
    bestCTA: pat.byCta[0] ? pat.byCta[0].key : DNA,
    bestStory: stBest ? { id: stBest.id, reach: stBest.metrics.reach } : DNA,
    declineCauses: stuck.problems.map(p => `${p.title}: ${p.evidence}`),
    keepDoing: cont.slice(0, 3), stopDoing: stop.slice(0, 3),
    nextWeekStrategy: { mode: strategy.mode, notes: strategy.notes },
  };
}

// ---------- opportunities (internal topic x angle matrix; NO external trend feed) ----------
export const RESEARCH_TOPICS = ['Firefighter', 'Firefighter Fitness', 'Bodybuilding', 'Functional Fitness', 'Firefighter Challenges', 'Firefighter Training', 'Strength', 'Endurance', 'Rescue Training', 'PPE Training', 'Emergency Response', 'Physical Preparation'];

// ---------- full cycle ----------
export function analyzeAll({ media, daily, stories, now = Date.now() }) {
  const { p, reels, all } = computeProfile({ media, daily, stories, now });
  const health = growthHealth(p), stuck = stuckDetector(p), pat = patterns(all);
  return { p, reels, all, health, stuck, pat };
}

export function makePlan({ date, A, pastIdeas, prevPlan, bestHourInfo, now = Date.now() }) {
  const strategy = adapt(A.p, A.pat, A.all);
  const memory = memoryFrom(A.all, pastIdeas, now);
  const { ideas, rest } = generateIdeas({ date, count: 5, memory, strategy, pat: A.pat });
  const publishAt = bestHourInfo.hour != null ? `${String(bestHourInfo.hour).padStart(2, '0')}:00` : '20:45';
  const timeSource = bestHourInfo.hour != null ? 'data' : 'default (no post-time data)';
  const stories = buildStories(ideas[0], publishAt, timeSource);
  const yesterday = measureYesterday(prevPlan, A.all, A.pat);
  const mission = buildMission({ date, publishAt, timeSource, ideas, stories, strategy, yesterday });
  return { date, createdAt: now, strategy, ideas: ideas.map(i => ({ ...i, ts: now })), opportunities: rest, stories, mission, publishedMediaId: null, publishedIdeaId: null };
}
