// AI ASSISTANT: multi-turn Persian chat about the page. NOT wired into src/index.js yet.
// - Facts come ONLY from stored page data (coachContext). No data stored → the model is told so and must not invent metrics.
// - History lives in the existing virtual table "records" (one record per turn), separate per account and per session. No new table.
// - Anti-fabrication (src/integrity.js): every statistic-looking number in the model's answer is checked IN CODE against the numbers that really
//   exist in the stored data. Unverifiable numbers trigger one rewrite, then are removed. Missing account metrics are answered by code, not by the model.
// - The session id only names a conversation. It is NOT authentication: callers must have passed adminOk() first.
import { coachContext } from './coach.js';
import { runChat } from './ai.js';
import { getStore } from './store.js';
import { assess, factSets, viewRatios, userNumbers, verifyReply, redact, metricAsk, numbersIn } from './integrity.js';

export const ASSISTANT_HISTORY_MESSAGES = 12;   // previous messages sent to the model (6 turns)
export const ASSISTANT_MAX_CHARS = 2000;        // per message, input and output
export const ASSISTANT_MAX_TOKENS = 500;       // model output cap (keeps replies near the 2000-char limit)
export const ASSISTANT_KEEP_TURNS = 60;         // stored turns per session; older ones are pruned
export const ASSISTANT_MAX_CONTEXT_CHARS = 6000;

const SYSTEM_BASE =
  'You are the Persian-speaking assistant of an Iranian firefighter-fitness Instagram page. Reply in Persian, short and practical (readable on a phone, about 200 words max). ' +
  'Use ONLY the page data JSON below for any fact, number, follower count, reach or performance claim. Never invent numbers; if something is missing write "DATA NOT AVAILABLE" (in Persian: «داده‌ای موجود نیست»). ' +
  'You may freely help with ideas, hooks, captions and plans, but label them as suggestions, not results. ' +
  'Never promise growth or followers. Give fitness and firefighter-safety advice cautiously and make no medical claims. If the question is unclear, ask one short question.\n\n' +
  'DATA LABELS. OBSERVED = numbers stored from the platform or imported public data (lastReels/topReels: views, likes, comments, shares, saves, dur, date; OBSERVED ACCOUNT METRICS). ' +
  'DERIVED = computed by code from observed data (overallMedianViews, patterns, health, problems[].evidence, weekly). ' +
  'ESTIMATE = heuristic scores and proxies (todayTop[].score/tier, any evidence marked "proxy"): always call them «تخمین» or «امتیاز برآوردی», never results. ' +
  'SUGGESTION = ideas, hooks, CTAs, durations and times (todayTop, strategy, nextWeekStrategy): never present them as measured.\n' +
  'STRICT NUMBER RULES. (1) Quote a statistic only if it appears in the data below, copied exactly. (2) If a requested number is missing, write «اطلاعات کافی در دسترس نیست» and say which data is needed. ' +
  '(3) Numbers in the user\'s message and in earlier turns are NOT verified: use them only as «طبق گفته‌ی تو …», never confirm them or build on them as facts. ' +
  '(4) Do not compute new statistics (sums, differences, growth, percentages) yourself. (5) If DATA QUALITY says STALE, mention the age of the data. ' +
  '(6) In analytical answers keep real data, estimates and suggestions on separate lines labelled «داده واقعی:», «تخمین:», «پیشنهاد:».';

// ---------- helpers ----------
const err = (reason, extra = {}) => ({ ok: false, reason, ...extra });
const dbErr = e => err('D1_ERROR: ' + String(e?.message ?? e).slice(0, 200));
const clean = v => String(v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim();
const T = sid => 'assistant.' + sid;                                         // table name passed to store.put/get/list
const fullTbl = (store, sid) => T(sid) + (store.account ? '@' + store.account : ''); // what scoped() really writes (needed for DELETE)
const SID_RE = /^ses_[0-9a-f]{32}$/;

export const isSessionId = s => typeof s === 'string' && SID_RE.test(s);
export function newSessionId() { // 128 random bits from the platform CSPRNG
  return 'ses_' + [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join('');
}

function fitText(t, max = ASSISTANT_MAX_CHARS) { // model output: strip control chars, cap length, prefer cutting at a sentence end
  t = clean(t);
  if (t.length <= max) return t;
  const cut = t.slice(0, max - 1), i = Math.max(cut.lastIndexOf('\n'), cut.lastIndexOf('.'), cut.lastIndexOf('؟'), cut.lastIndexOf('!'));
  return i > max * 0.6 ? cut.slice(0, i + 1).trim() : cut.trim() + '…';
}

const validTurn = t => !!t && typeof t === 'object' && typeof t.user === 'string' && typeof t.assistant === 'string' && !!t.user.trim() && !!t.assistant.trim() && Number.isFinite(t.ts);

// One in-flight request per account+session at a time (inside one Worker isolate). Different sessions never wait for each other.
const locks = new Map();
async function withLock(key, fn) {
  const prev = locks.get(key) || Promise.resolve();
  let release; const gate = new Promise(r => { release = r; });
  const tail = prev.then(() => gate);
  locks.set(key, tail);
  await prev;
  try { return await fn(); } finally { release(); if (locks.get(key) === tail) locks.delete(key); }
}
const lockKey = (store, sid) => (store.account ?? 'main') + ':' + sid;

// The store abstraction has no delete(): use the real D1 / in-memory store behind it, on the same "records" table.
async function deleteTurns(base, tbl) {
  if (base.db) { await base.db.prepare('DELETE FROM records WHERE tbl=?').bind(tbl).run(); return; }
  if (base.m instanceof Map) { for (const [k, v] of [...base.m]) if (v.t === tbl) base.m.delete(k); return; }
  throw new Error('store does not support delete');
}
async function pruneTurns(base, tbl, keep) {
  if (base.db) { await base.db.prepare('DELETE FROM records WHERE tbl=? AND k NOT IN (SELECT k FROM records WHERE tbl=? ORDER BY ts DESC LIMIT ?)').bind(tbl, tbl, keep).run(); return; }
  if (base.m instanceof Map) { const rows = [...base.m].filter(([, v]) => v.t === tbl).sort((a, b) => b[1].ts - a[1].ts); for (const [k] of rows.slice(keep)) base.m.delete(k); }
}

async function loadTurns(store, sid, maxTurns) {
  const rows = await store.list(T(sid), { limit: maxTurns });
  const turns = rows.filter(validTurn).sort((a, b) => a.ts - b.ts);
  return { turns, skipped: rows.length - turns.length };
}
const flatten = turns => turns.flatMap(t => [{ role: 'user', content: t.user }, { role: 'assistant', content: t.assistant }]);

// ---------- public API ----------
// loadHistory(store, sid, { limit }) → { ok, messages: [{role, content}] oldest first, skipped }
export async function loadHistory(store, sid, { limit = ASSISTANT_HISTORY_MESSAGES } = {}) {
  if (!store || typeof store.list !== 'function') return err('INVALID_INPUT: store is required');
  if (!isSessionId(sid)) return err('INVALID_SESSION');
  if (!Number.isInteger(limit) || limit < 1 || limit > 50) return err('INVALID_INPUT: limit must be an integer from 1 to 50');
  try {
    const { turns, skipped } = await loadTurns(store, sid, Math.ceil(limit / 2));
    return { ok: true, messages: flatten(turns).slice(-limit), skipped };
  } catch (e) { return dbErr(e); }
}

// saveTurn(store, sid, userText, assistantText, { now, env }) → { ok, ts }. One record per turn, so a turn is never half-saved.
export async function saveTurn(store, sid, userText, assistantText, { now = Date.now(), env = null } = {}) {
  if (!store || typeof store.put !== 'function') return err('INVALID_INPUT: store is required');
  if (!isSessionId(sid)) return err('INVALID_SESSION');
  if (typeof userText !== 'string' || typeof assistantText !== 'string') return err('INVALID_INPUT: texts must be strings');
  const user = clean(userText), assistant = clean(assistantText);
  if (!user || !assistant) return err('INVALID_INPUT: texts must not be empty');
  if (user.length > ASSISTANT_MAX_CHARS || assistant.length > ASSISTANT_MAX_CHARS) return err('INVALID_INPUT: message too long (max ' + ASSISTANT_MAX_CHARS + ' chars)');
  if (!Number.isFinite(now)) return err('INVALID_INPUT: now must be a number');
  const rand = [...crypto.getRandomValues(new Uint8Array(6))].map(b => b.toString(16).padStart(2, '0')).join('');
  try {
    await store.put(T(sid), String(Math.trunc(now)).padStart(15, '0') + '-' + rand, { v: 1, ts: now, user, assistant }, now);
  } catch (e) { return dbErr(e); }
  if (env) { try { await pruneTurns(getStore(env), fullTbl(store, sid), ASSISTANT_KEEP_TURNS); } catch { /* pruning is best-effort */ } }
  return { ok: true, ts: now };
}

// clearHistory(store, env, sid) → really deletes this session's turns (this account only).
export async function clearHistory(store, env, sid) {
  if (!store || typeof store.put !== 'function') return err('INVALID_INPUT: store is required');
  if (!isSessionId(sid)) return err('INVALID_SESSION');
  return withLock(lockKey(store, sid), async () => {
    try { await deleteTurns(getStore(env || {}), fullTbl(store, sid)); return { ok: true }; } catch (e) { return dbErr(e); }
  });
}

function contextJson(ctx, max) { // shrink the page-data JSON step by step instead of cutting it in the middle
  const levels = [ctx, { ...ctx, weekly: undefined }, { ...ctx, weekly: undefined, patterns: undefined, todayTop: undefined }, { health: ctx.health, problems: ctx.problems, overallMedianViews: ctx.overallMedianViews }];
  for (let i = 0; i < levels.length; i++) { const s = JSON.stringify(levels[i]); if (s.length <= max) return { json: s, level: i }; }
  return null;
}

const MAX_SYSTEM = 8000; // runChat's own limit for the system prompt
const yn = b => b ? 'yes' : 'no';
function qualityLine(q) {
  return 'DATA QUALITY: ' + q.reels + ' reels with stats; newest post ' + (q.newestPostDate ?? 'unknown') + '; data fetched ' + (q.fetchAgeDays == null ? 'at an unknown time' : q.fetchAgeDays + ' day(s) ago')
    + (q.stale ? ' (STALE: older than 7 days)' : '') + '; enough for pattern claims (8+ reels): ' + yn(q.sufficientForPatterns) + '; enough for a growth diagnosis: ' + yn(q.sufficientForDiagnosis)
    + '; NOT STORED: ' + (q.missing.length ? q.missing.join(', ') : 'nothing');
}
function accountLine(A) { // observed account-level numbers that coachContext does not carry
  const p = A?.p || {}, v = [];
  if (p.followers != null) v.push('followers=' + p.followers);
  if (p.followDelta7 != null) v.push('followers change over 7 days=' + p.followDelta7);
  return 'OBSERVED ACCOUNT METRICS: ' + (v.length ? v.join('; ') : 'none stored');
}
function ratioLine(ctx) { // views ÷ median per recent reel, computed here so the model never has to do the arithmetic
  const r = viewRatios(ctx); return r.length ? '\nDERIVED RATIOS (views ÷ overallMedianViews): ' + r.map(x => x.id + '=' + x.ratio.toFixed(2)).join('; ') : '';
}
function footer(q, redacted) { // plain, code-generated provenance line appended to answers that quote statistics
  return '\n\nمبنا: ' + q.reels + ' ریل ذخیره‌شده' + (q.fetchAgeDays != null ? '، دریافت داده ' + q.fetchAgeDays + ' روز پیش' : '') + (q.stale ? ' (ممکن است قدیمی باشد)' : '')
    + (!q.sufficientForPatterns ? '؛ نمونه کم است' : '') + (redacted ? '؛ چند عدد غیرقابل‌تأیید حذف شد' : '') + '. تخمین‌ها و پیشنهادها در متن برچسب دارند.';
}
// metrics the user asks for by number (followers, reach...) that are NOT stored: answered by code, no model call, nothing to invent
function missingMetricReply(asks, q, userTokens) {
  const parts = [];
  if (asks.includes('followers') && !q.followersKnown) parts.push('تعداد فالوور در داده‌های ذخیره‌شده‌ی این حساب ثبت نشده؛ برای ثبت آن، Instagram API را وصل کن تا snapshot روزانه ذخیره شود.');
  if (asks.includes('reach') && q.missing.includes('reach')) parts.push('ریچ، ایمپرشن و بازدید پروفایل در داده‌های ذخیره‌شده نیست؛ برای دریافتشان Instagram API (Insights) لازم است.');
  if (!parts.length) return null;
  let text = 'اطلاعات کافی در دسترس نیست. ' + parts.join(' ');
  if (userTokens.length) text += ' عددی که در پیامت نوشتی (' + userTokens.slice(0, 3).join('، ') + ') تأییدشده نیست و آن را آمار واقعی حساب نمی‌کنم.';
  if (q.hasData) text += ' از ' + q.reels + ' ریلز ذخیره‌شده می‌توانم تحلیل بدهم؛ بپرس.';
  return text;
}
const publicQuality = q => ({ hasData: q.hasData, reels: q.reels, newestPostDate: q.newestPostDate, fetchAgeDays: q.fetchAgeDays, stale: q.stale, sufficientForPatterns: q.sufficientForPatterns, sufficientForDiagnosis: q.sufficientForDiagnosis, missing: q.missing });

// assistantReply({ store, env, sid, message, A, plan, weekly, now }) → { ok, reply, saved, hasData, source, dataQuality, verification, ... } | { ok:false, reason }
// A, plan and weekly are the same objects /api/coach builds (ensurePlan + weeklyReport); the caller passes them in.
export async function assistantReply({ store, env, sid, message, A, plan, weekly, now = Date.now() } = {}) {
  if (!store || typeof store.put !== 'function' || typeof store.list !== 'function') return err('INVALID_INPUT: store is required');
  if (!isSessionId(sid)) return err('INVALID_SESSION');
  if (typeof message !== 'string' || !clean(message)) return err('INVALID_INPUT: message is required');
  const msg = clean(message);
  if (msg.length > ASSISTANT_MAX_CHARS) return err('INVALID_INPUT: message too long (max ' + ASSISTANT_MAX_CHARS + ' chars)');
  if (!Number.isFinite(now)) return err('INVALID_INPUT: now must be a number');

  let ctx; try { ctx = coachContext(A, plan, weekly); } catch { return err('INVALID_CONTEXT: page analysis data is missing or malformed'); }
  const q = assess(A, now), reels = q.reels, hasData = q.hasData, sets = factSets(ctx, A, q);
  const head = (note = '') => SYSTEM_BASE + '\n\nPAGE DATA STATUS: ' + (hasData
    ? reels + ' reels with stored stats.'
    : 'NO REEL DATA STORED. Do not state any metric, follower count, reach or diagnosis. Say clearly that no page data is connected or imported yet, and offer general ideas only.')
    + '\n' + qualityLine(q) + '\n' + accountLine(A) + ratioLine(ctx) + (userNumsLine || '') + note + '\nPAGE DATA (JSON): ';
  let userNumsLine = '';

  return withLock(lockKey(store, sid), async () => {
    let turns;
    try { ({ turns } = await loadTurns(store, sid, ASSISTANT_HISTORY_MESSAGES / 2)); } catch (e) { return dbErr(e); } // do not answer with silently lost context
    const history = flatten(turns).slice(-ASSISTANT_HISTORY_MESSAGES);
    while (history.length && history[0].role !== 'user') history.shift();
    // numbers that come from the USER (this message or earlier user turns) are claims, never facts. Earlier ASSISTANT numbers are not trusted either: only `sets` count.
    const userTexts = [...history.filter(m => m.role === 'user').map(m => m.content), msg], userNums = userNumbers(userTexts), msgTokens = numbersIn(msg).map(t => t.raw.trim());
    const nextTs = Math.max(now, (turns.length ? turns[turns.length - 1].ts : 0) + 1); // strictly increasing order inside a session
    const done = async (reply, extra) => {
      const s = await saveTurn(store, sid, msg, reply, { now: nextTs, env });
      return { ok: true, reply, saved: s.ok, ...(s.ok ? {} : { saveError: s.reason }), hasData, dataQuality: publicQuality(q), sessionId: sid, ...extra };
    };

    const asks = metricAsk(msg), canned = asks.length ? missingMetricReply(asks, q, msgTokens) : null;
    if (canned) { // code answers: the metric is not stored, so there is nothing for the model to make up
      return done(fitText(canned + footer(q, false)), { source: 'rules', contextTrimmed: false, provider: null, model: null, verification: { status: 'not_needed', checked: 0, violations: [], removed: 0, retried: false } });
    }

    userNumsLine = userNums.size ? '\nUSER-PROVIDED NUMBERS (UNVERIFIED, not page data): ' + [...userNums].slice(0, 8).join(', ') : '';
    const fitFor = note => { const room = MAX_SYSTEM - head(note).length - 10; return room > 0 ? contextJson(ctx, Math.min(ASSISTANT_MAX_CONTEXT_CHARS, room)) : null; };
    const build = note => { const fit = fitFor(note); return fit ? { system: head(note) + fit.json, level: fit.level } : null; };
    const first = build('');
    if (!first) return err('INVALID_CONTEXT: page data too large');
    const messages = [...history, { role: 'user', content: msg }];

    let r = await runChat(env, { system: first.system, messages, maxTokens: ASSISTANT_MAX_TOKENS });
    if (!r.ok) return err(r.reason, { hasData }); // nothing is saved and no answer is invented
    let text = fitText(r.text);
    if (!text) return err('EMPTY_RESPONSE', { hasData });

    // ----- code-level check of every statistic-looking number -----
    let ver = verifyReply(text, { sets, userNums }), retried = false, status = 'ok', removed = 0, model = r.model, provider = r.provider;
    if (!ver.ok) {
      retried = true;
      const note = '\nREJECTED DRAFT: your previous answer contained numbers that are not in the data below (' + ver.violations.slice(0, 6).map(v => v.token).join(', ') + '), or were taken from the user or from earlier turns. Rewrite the answer without them, or say «اطلاعات کافی در دسترس نیست». Do not mention this note.';
      const second = build(note);
      if (second) {
        const r2 = await runChat(env, { system: second.system, messages, maxTokens: ASSISTANT_MAX_TOKENS });
        if (r2.ok && fitText(r2.text)) { text = fitText(r2.text); ver = verifyReply(text, { sets, userNums }); }
      }
      if (ver.ok) status = 'retried';
      else { text = redact(text, ver.violations); removed = ver.violations.length; status = 'redacted'; }
    }
    const stats = ver.checked - ver.violations.length > 0 || removed > 0, foot = stats ? footer(q, removed > 0) : '';
    const reply = fitText(text, ASSISTANT_MAX_CHARS - foot.length) + foot;
    if (!clean(reply)) return err('EMPTY_RESPONSE', { hasData });
    return done(reply, { source: 'ai', contextTrimmed: first.level > 0, provider, model,
      verification: { status, checked: ver.checked, violations: ver.violations.slice(0, 10).map(v => ({ type: v.type, token: v.token })), removed, retried } });
  });
}
