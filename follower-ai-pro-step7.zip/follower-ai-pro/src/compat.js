// Legacy-compatible Follower AI endpoints (/api/audit, /api/strategy, /api/reel-ideas, /api/plan).
// Same response shape as Follower AI 2.0 ({success, endpoint, ai, model, result}), but every value comes from stored data.
// No invented scores: unmeasurable parts are reported as DATA NOT AVAILABLE in `limitations`.
import { DNA } from './analysis.js';
import { runAI, aiProvider } from './ai.js';

const DAYS = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
const uniq = a => [...new Set(a)];
const limitsOf = (A, extra = []) => [...extra, ...A.stuck.notEvaluable.slice(0, 4).map(n => n.reason), ...(A.health.note ? [A.health.note] : [])];

const NEXT = {
  hook_weak: 'ریلز امروز را با یک سوال یا عدد در ۳ ثانیه اول شروع کن.',
  topic_repeated: 'امروز موضوعی غیر از موضوع تکراری انتخاب کن.',
  low_shareable: 'ریلز امروز یک جمله «برای دوستت بفرست» داشته باشد.',
  cta_weak: 'به کپشن ریلز بعدی یک CTA دو گزینه‌ای اضافه کن.',
  conversion_low: 'بایو را وعده‌دار کن و بهترین ریلز را پین کن.',
  story_retention: 'استوری امروز را با Poll یا Question شروع کن.',
  inconsistent: 'تقویم ۵ ریلز در هفته را همین الان در گوشی ثبت کن.',
  too_similar: 'کپشن ریلز بعدی را بدون شعار و با یک اتفاق مشخص بنویس.',
  drift: 'ریلز بعدی را در موضوع پربازدیدترین ریلزت بساز.',
  reel_views_no_follow: 'در ثانیه آخر ریلز دلیل فالو کردن را بگو و کامنت را پین کن.',
  engagement_drop: 'امروز یک Poll دو گزینه‌ای در استوری بگذار و به همه کامنت‌ها جواب بده.',
  reach_drop: 'همان ایده برنده را با هوک و کاور جدید دوباره منتشر کن.',
  packaging: 'کاور و متن روی ویدئو را عوض کن و همان محتوا را دوباره تست کن.',
};
// Every finding: finding, type (observed | ai_hypothesis | missing), evidence, confidence, correction, nextAction
export function buildFindings(A, brief) {
  const cov = A.health.coverage, conf = cov >= 70 ? 'متوسط تا بالا' : cov >= 35 ? 'محدود (داده ناقص)' : 'کم (داده خیلی ناقص)';
  const out = A.stuck.problems.map(p => ({ id: p.id, finding: p.title, type: 'observed', evidence: p.evidence, confidence: conf, correction: p.action, nextAction: NEXT[p.id] || p.action }));
  const best = A.pat.byTopic[0];
  if (best) out.push({ id: 'best_topic', finding: `موضوع «${best.key}» بهتر از بقیه جواب داده`, type: 'observed', evidence: `${best.n} ریلز، ${best.ratio.toFixed(1)} برابر میانه بازدید`, confidence: best.n >= 4 ? 'متوسط' : 'محدود (نمونه کم)', correction: 'روی همین موضوع زاویه‌های جدید بساز.', nextAction: 'ریلز امروز را در همین موضوع و با زاویه جدید بساز.' });
  for (const n of A.stuck.notEvaluable) out.push({ id: n.id, finding: n.title, type: 'missing', evidence: n.reason, confidence: '—', correction: 'داده لازم را وصل یا وارد کن.', nextAction: 'Instagram را از تب ممیزی وصل کن یا آمار ریلزها را وارد کن.' });
  out.push({ id: 'profile_completeness', finding: 'کامل بودن پروفایل (نام، بایو، لینک)', type: 'missing', evidence: 'DATA NOT AVAILABLE: فیلدهای پروفایل در این نسخه ذخیره نمی‌شوند', confidence: '—', correction: 'بایو را دستی بررسی کن: وعده روشن + دلیل فالو.', nextAction: 'بایو فعلی را در تب کوچ بفرست تا نقد شود.' });
  if (brief?.audience) out.push({ id: 'audience_input', finding: 'مخاطب هدف (ورودی خودت)', type: 'observed', evidence: `ورودی کاربر: ${brief.audience}`, confidence: 'تأییدنشده با آمار مخاطب', correction: 'با اتصال API بررسی شود که آمار مخاطب با این فرض می‌خواند یا نه.', nextAction: 'ریلز امروز را برای همین مخاطب بنویس.' });
  return out;
}

export function buildAudit(A, account, brief = null) {
  const h = A.health, top = A.reels.slice().sort((a, b) => b.metrics.views - a.metrics.views)[0];
  return {
    summary: h.score == null ? `${DNA}: داده کافی برای Growth Health نیست (پوشش ${h.coverage}٪).` : `Growth Health ${h.score}/100 (تخمینی، پوشش داده ${h.coverage}٪).`,
    diagnosis: A.stuck.problems.length ? A.stuck.problems.map(p => `${p.title}: ${p.evidence}`).join(' | ') : 'با داده فعلی مشکل مشخصی تشخیص داده نشد.',
    strengths: [A.pat.byTopic[0] && `موضوع «${A.pat.byTopic[0].key}» ${A.pat.byTopic[0].ratio.toFixed(1)} برابر میانه بازدید دارد`, top && `بهترین ریلز ${top.metrics.views} بازدید (${top.id})`].filter(Boolean),
    weaknesses: A.stuck.problems.map(p => p.title),
    priorities: A.stuck.problems.slice(0, 3).map(p => p.action),
    findings: buildFindings(A, brief),
    evidenceTypes: { observed: 'مشاهده‌شده از داده', ai_hypothesis: 'فرضیه تولیدشده توسط AI', missing: 'داده موجود نیست' },
    limitations: limitsOf(A, [`حساب: ${account}`]),
  };
}
export function buildReelIdeas(plan, A) {
  return { ideas: plan.ideas.map(i => ({ title: i.title, hook: i.hook, scenario: i.scenario, on_camera: i.onCamera, overlay_text: i.overlay, duration_sec: i.dur, cta: i.cta, caption: i.caption, goal: i.goal, estimated_score: i.score.total, tier: i.score.tier, note: 'امتیاز تخمینی است' })),
    rules: ['هوک در ۳ ثانیه اول', 'یک اتفاق واقعی و مشخص در هر ریلز', 'یک CTA دو گزینه‌ای'], limitations: limitsOf(A) };
}
export function buildWeeklyPlan(plan, A, now, offMin = 210) {
  const dow = new Date(now + offMin * 60000).getUTCDay();
  const reels = plan.ideas.slice(0, 5), st = plan.stories;
  const days = [];
  for (let i = 0; i < 7; i++) {
    const day = DAYS[(dow + i) % 7], r = reels[i];
    if (r) days.push({ day, content_type: 'ریلز', topic: r.title, idea: r.scenario, hook: r.hook, cta: r.cta, story: st[i % st.length].text, goal: r.goal, engagement_action: st[i % st.length].sticker });
    else days.push({ day, content_type: 'استوری تعاملی', topic: 'رأی‌گیری موضوع هفته بعد', idea: 'Poll/Question برای انتخاب مخاطب', hook: st[1].text, cta: st[1].cta, story: st[1].text, goal: 'تعامل', engagement_action: st[1].sticker });
  }
  return { days, posting_guidance: [`ساعت انتشار: ${plan.mission.top.publishAt} (${plan.mission.timeSource})`, 'اولین ۳۰ دقیقه به کامنت‌ها جواب بده'], engagement_actions: uniq(st.map(s => s.sticker)), limitations: limitsOf(A) };
}
export function buildStrategy(plan, A, now, brief = null) {
  const wp = buildWeeklyPlan(plan, A, now);
  return { diagnosis: buildAudit(A, '', brief).diagnosis, audience: brief?.audience ? `ورودی خودت (با آمار تأیید نشده): ${brief.audience}` : `${DNA}: مخاطب را در بریف وارد کن؛ آمار مخاطب API پیاده نشده`,
    content_pillars: A.pat.byTopic.length ? A.pat.byTopic.slice(0, 3).map(t => `${t.key} (${t.ratio.toFixed(1)}x میانه)`) : uniq(plan.ideas.map(i => i.topic)),
    reel_strategy: plan.strategy.notes, weekly_plan: wp.days.map(d => `${d.day}: ${d.content_type} - ${d.topic}`),
    hooks: plan.ideas.map(i => i.hook), cta: uniq(plan.ideas.map(i => i.cta)), engagement_actions: wp.engagement_actions,
    metrics: ['Reach', 'Views', 'Shares', 'Saves', 'Profile visits → Follows', 'میانه بازدید ۵ ریلز اخیر نسبت به قبل'], limitations: limitsOf(A) };
}

// optional natural-language summary, clearly separated (`ai_summary`); never replaces the data-driven fields
export async function withAISummary(task, result, env, fetchFn) {
  if (!aiProvider(env)) return { result, ai: false, model: null };
  const r = await runAI(env, { fetchFn, maxTokens: 500,
    system: 'Persian, max 120 words. Summarise ONLY the JSON given for an Instagram page owner. Never add numbers or facts that are not in the JSON. If something is "DATA NOT AVAILABLE" say so.',
    user: JSON.stringify({ task, result }) });
  if (!r.ok) return { result: { ...result, limitations: [...result.limitations, `AI summary failed: ${r.reason}`] }, ai: false, model: r.model || null };
  const extra = task === 'audit' && Array.isArray(result.findings) ? { findings: [...result.findings, { id: 'ai_summary', finding: 'خلاصه تحلیل هوش مصنوعی', type: 'ai_hypothesis', evidence: 'تولیدشده از همین داده‌ها؛ فرضیه است نه واقعیت', confidence: 'تخمینی', correction: 'با داده واقعی راستی‌آزمایی کن.', nextAction: 'فقط پیشنهادهایی را اجرا کن که با مشاهده‌ها می‌خواند.' }] } : {};
  return { result: { ...result, ...extra, ai_summary: r.text }, ai: true, model: r.model };
}
