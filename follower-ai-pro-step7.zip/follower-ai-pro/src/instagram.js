// Instagram Graph API client (Instagram API with Instagram Login, graph.instagram.com).
// NOTHING here fabricates data: on any API error the field stays null and the error is recorded.

export const REQUIRED_PERMISSIONS = [
  { scope: 'instagram_business_basic', why: 'profile, followers_count, media list' },
  { scope: 'instagram_business_manage_insights', why: 'reach, views, saves, shares, profile visits, reel/story insights' },
];
export const OPTIONAL_PERMISSIONS = [
  { scope: 'instagram_business_content_publish', why: 'only needed if you later want auto-publishing (NOT implemented)' },
];

const DAY_METRICS = ['reach', 'views', 'profile_views', 'accounts_engaged', 'total_interactions', 'likes', 'comments', 'shares', 'saves', 'follows_and_unfollows'];
const REEL_METRICS = ['reach', 'views', 'likes', 'comments', 'shares', 'saved', 'total_interactions', 'ig_reels_avg_watch_time', 'ig_reels_video_view_total_time'];
const FEED_METRICS = ['reach', 'views', 'likes', 'comments', 'shares', 'saved', 'total_interactions'];
const STORY_METRICS = ['reach', 'views', 'replies', 'shares', 'total_interactions'];

export class IGClient {
  constructor({ token, userId, host = 'graph.instagram.com', version = 'v25.0', fetchFn = fetch }) {
    Object.assign(this, { token, userId, host, version, fetchFn });
    this.errors = [];
    this.calls = 0;
  }
  async get(path, params = {}) {
    const u = new URL(`https://${this.host}/${this.version}/${path}`);
    for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
    u.searchParams.set('access_token', this.token);
    this.calls++;
    const r = await this.fetchFn(u.toString());
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.error) {
      const e = j.error || { message: 'HTTP ' + r.status };
      const err = new Error(e.message || 'Instagram API error');
      err.code = e.code; err.subcode = e.error_subcode; err.type = e.type; err.path = path;
      throw err;
    }
    return j;
  }
  note(scope, e) { this.errors.push({ scope, code: e.code ?? null, message: String(e.message).slice(0, 300) }); }

  // Long-lived Instagram User tokens last 60 days; they can be refreshed once they are >24h old and not yet expired.
  async refresh() {
    const u = new URL(`https://${this.host}/refresh_access_token`);
    u.searchParams.set('grant_type', 'ig_refresh_token'); u.searchParams.set('access_token', this.token);
    this.calls++;
    const r = await this.fetchFn(u.toString()); const j = await r.json().catch(() => ({}));
    if (!r.ok || j.error || !j.access_token) { const e = new Error(j.error?.message || 'refresh failed (HTTP ' + r.status + ')'); e.code = j.error?.code; throw e; }
    return { token: j.access_token, expiresIn: j.expires_in ?? null };
  }

  async profile() {
    return this.get(this.userId || 'me', { fields: 'id,username,followers_count,follows_count,media_count' });
  }

  // insights for one metric list; falls back to one-by-one so a single bad metric doesn't hide the rest
  async insights(objectId, metrics, extra = {}, scope = 'insights', cacheKey = null) {
    this.good = this.good || {};
    if (cacheKey && this.good[cacheKey]) metrics = this.good[cacheKey];
    const out = {};
    const parse = j => {
      for (const m of j.data || []) {
        const v = m.total_value ? m.total_value.value : (m.values && m.values[0] ? m.values[0].value : null);
        out[m.name] = typeof v === 'number' ? v : null;
      }
    };
    try { parse(await this.get(`${objectId}/insights`, { metric: metrics.join(','), ...extra })); return out; }
    catch (e) {
      this.note(scope + ':batch', e);
      if (metrics.length === 1) return out;
    }
    for (const m of metrics) {
      try { parse(await this.get(`${objectId}/insights`, { metric: m, ...extra })); }
      catch (e) { this.note(scope + ':' + m, e); out[m] = null; }
    }
    // remember which metrics work so later calls in this sync stay one request (Workers subrequest limits)
    if (cacheKey) this.good[cacheKey] = metrics.filter(m => out[m] != null);
    return out;
  }

  async dayInsights(isoDate) {
    const since = Math.floor(Date.parse(isoDate + 'T00:00:00Z') / 1000);
    const m = await this.insights(this.userId || 'me', DAY_METRICS,
      { period: 'day', metric_type: 'total_value', since, until: since + 86400 }, 'account', 'account');
    return {
      date: isoDate,
      reach: m.reach ?? null, views: m.views ?? null, profileViews: m.profile_views ?? null,
      accountsEngaged: m.accounts_engaged ?? null, interactions: m.total_interactions ?? null,
      likes: m.likes ?? null, comments: m.comments ?? null, shares: m.shares ?? null, saves: m.saves ?? null,
      follows: m.follows_and_unfollows ?? null, // total_value of follows_and_unfollows = net follows reported by API
    };
  }

  async recentMedia(limit = 25) {
    const j = await this.get(`${this.userId || 'me'}/media`, {
      fields: 'id,caption,media_type,media_product_type,timestamp,like_count,comments_count,permalink,thumbnail_url',
      limit,
    });
    const items = [];
    for (const x of j.data || []) {
      const isReel = x.media_product_type === 'REELS';
      const ins = await this.insights(x.id, isReel ? REEL_METRICS : FEED_METRICS, {}, 'media:' + x.id, isReel ? 'reel' : 'feed');
      items.push({
        id: x.id, source: 'graph-api',
        type: isReel ? 'REEL' : (x.media_type === 'CAROUSEL_ALBUM' ? 'CAROUSEL' : 'POST'),
        ts: Date.parse(x.timestamp), caption: x.caption || '', permalink: x.permalink,
        durationSec: null, hasTime: true,
        metrics: {
          views: ins.views ?? null, reach: ins.reach ?? null,
          likes: ins.likes ?? x.like_count ?? null, comments: ins.comments ?? x.comments_count ?? null,
          shares: ins.shares ?? null, saves: ins.saved ?? null,
          avgWatchSec: ins.ig_reels_avg_watch_time != null ? ins.ig_reels_avg_watch_time / 1000 : null,
          totalWatchSec: ins.ig_reels_video_view_total_time != null ? ins.ig_reels_video_view_total_time / 1000 : null,
        },
        fetchedAt: Date.now(),
      });
    }
    return items;
  }

  async liveStories() {
    let j;
    try { j = await this.get(`${this.userId || 'me'}/stories`, { fields: 'id,timestamp,media_type,permalink' }); }
    catch (e) { this.note('stories', e); return []; }
    const items = [];
    for (const s of j.data || []) {
      const ins = await this.insights(s.id, STORY_METRICS, {}, 'story:' + s.id);
      items.push({ id: s.id, ts: Date.parse(s.timestamp), type: s.media_type, permalink: s.permalink,
        metrics: { reach: ins.reach ?? null, views: ins.views ?? null, replies: ins.replies ?? null, shares: ins.shares ?? null, interactions: ins.total_interactions ?? null },
        fetchedAt: Date.now() });
    }
    return items;
  }
}

// Classify an API error into a human-actionable permission problem.
export function explainErrors(errors) {
  const missing = new Set();
  let tokenInvalid = false; const insufficient = new Set();
  for (const e of errors) {
    const m = (e.message || '').toLowerCase();
    if (m.includes('not enough viewers')) { insufficient.add(e.scope); continue; } // data limit, NOT a permission problem
    if (e.code === 190 || m.includes('access token') && (m.includes('expired') || m.includes('invalid'))) tokenInvalid = true;
    if (e.code === 10 || e.code === 200 || m.includes('permission')) {
      missing.add(e.scope.startsWith('media') || e.scope.startsWith('account') || e.scope.startsWith('story') ? 'instagram_business_manage_insights' : 'instagram_business_basic');
    }
  }
  return { tokenInvalid, missingPermissions: [...missing], notEnoughViewers: insufficient.size };
}
