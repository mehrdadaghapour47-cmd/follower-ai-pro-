// Pure analysis: metrics, GROWTH HEALTH SCORE, STUCK DETECTOR.
// Benchmarks below are adjustable HEURISTICS (not Instagram facts). Missing data => null => "DATA NOT AVAILABLE".
export const DNA = 'DATA NOT AVAILABLE';
export const clamp = (x, a = 0, b = 100) => Math.max(a, Math.min(b, x));
export const median = arr => { const a = arr.filter(x => x != null && !isNaN(x)).sort((x, y) => x - y); if (!a.length) return null; const m = a.length >> 1; return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2; };
const sum = a => a.reduce((s, x) => s + x, 0);
const DAY = 86400000;

// ---------- content classification ----------
const TOPIC_RULES = [
  ['challenge', /چالش|challenge|رکورد|تست|محک/i],
  ['training', /تمرین|تکرار|workout|training|ست\b|اسکوات|شنا/i],
  ['job', /آتش.?نشان|شیفت|ماموریت|مأموریت|ایستگاه|آژیر|firefight/i],
  ['bodybuilding', /بدنسازی|باشگاه|عضله|gym|bodybuild/i],
  ['mindset', /اراده|بهانه|غیرت|مرام|انگیزه|قوی‌تر|قوی تر/i],
];
export function topicsOf(caption = '') {
  const t = TOPIC_RULES.filter(([, r]) => r.test(caption)).map(([n]) => n);
  return t.length ? t : ['other'];
}
export const primaryTopic = c => topicsOf(c)[0];
export function hookOf(caption = '') {
  const first = caption.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '').split(/\n|[.!…]{1,3}\s/)[0].trim();
  return first.slice(0, 90);
}
export function hookFeatures(hook = '') {
  const f = [];
  if (/[؟?]/.test(hook)) f.push('question');
  if (/[0-9۰-۹]/.test(hook)) f.push('number');
  if (/تا آخر|آخرش|ببین/.test(hook)) f.push('stay');
  if (/ما |وقتی همه|برای ما/.test(hook)) f.push('slogan');
  return f.length ? f : ['plain'];
}
export const ctaType = (c = '') =>
  /[؟?]/.test(c) ? 'question' : /ذخیره|save/i.test(c) ? 'save' : /بفرست|ارسال|تگ|share/i.test(c) ? 'share' : /فالو|follow/i.test(c) ? 'follow' : /کامنت|بنویس|بگو/.test(c) ? 'comment' : 'none';
export const hasCTA = c => ctaType(c) !== 'none';
export const durationBucket = s => s == null ? 'unknown' : s < 10 ? '<10s' : s < 30 ? '10-30s' : s < 60 ? '30-60s' : '60s+';

const tokens = s => new Set((s || '').toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter(w => w.length > 2));
export function jaccard(a, b) {
  const A = tokens(a), B = tokens(b); if (!A.size || !B.size) return 0;
  let i = 0; for (const x of A) if (B.has(x)) i++;
  return i / (A.size + B.size - i);
}

// ---------- enrich content memory ----------
export function enrich(media) {
  const reels = media.filter(m => m.type === 'REEL' && m.metrics && m.metrics.views != null).sort((a, b) => b.ts - a.ts);
  const med = median(reels.map(r => r.metrics.views));
  const medEng = median(reels.map(r => engRate(r)));
  return media.map(m => {
    const hook = hookOf(m.caption);
    let perf = null;
    if (m.metrics?.views != null && med) {
      // views dominate (log scale so a 14x outlier separates from a 2x hit); engagement rate is a 20% tiebreaker
      const vr = clamp(Math.round(50 + 22 * Math.log2(Math.max(m.metrics.views, 1) / med)));
      const er = engRate(m), re = medEng && er != null ? scoreFromRatio(er / medEng) : null;
      perf = Math.round(re != null ? 0.8 * vr + 0.2 * re : vr);
    }
    return { ...m, hook, topics: topicsOf(m.caption), topic: primaryTopic(m.caption), hookFeatures: hookFeatures(hook), cta: ctaType(m.caption),
      durationBucket: durationBucket(m.durationSec), perfScore: perf };
  });
}
export const engRate = m => {
  const x = m.metrics; if (!x || !x.views) return null;
  const inter = (x.likes ?? 0) + (x.comments ?? 0) + (x.shares ?? 0) + (x.saves ?? 0);
  return inter / x.views;
};
export const scoreFromRatio = r => clamp(Math.round(50 + (r - 1) * 100));
const trend = (a, b) => (a == null || b == null || b === 0) ? null : a / b;

// ---------- profile metrics ----------
export function computeProfile({ media, daily, stories, now = Date.now() }) {
  const all = enrich(media);
  const reels = all.filter(m => m.type === 'REEL' && m.metrics?.views != null).sort((a, b) => b.ts - a.ts);
  const d = [...daily].sort((a, b) => a.date.localeCompare(b.date));
  const cut7 = new Date(now - 7 * DAY).toISOString().slice(0, 10), cut14 = new Date(now - 14 * DAY).toISOString().slice(0, 10);
  const cur = d.filter(x => x.date > cut7), prev = d.filter(x => x.date > cut14 && x.date <= cut7);
  const agg = (rows, k) => { const v = rows.map(r => r[k]).filter(x => x != null); return v.length >= 3 ? sum(v) : null; };
  const A = k => agg(cur, k), B = k => agg(prev, k);
  const reach7 = A('reach'), views7 = A('views'), inter7 = A('interactions');
  const p = {
    reachTrend: trend(reach7, B('reach')), viewsTrend: trend(views7, B('views')),
    engTrend: trend(inter7 != null && reach7 ? inter7 / reach7 : null, B('interactions') && B('reach') ? B('interactions') / B('reach') : null),
    shareRate: reach7 && A('shares') != null ? A('shares') / reach7 * 100 : null,
    saveRate: reach7 && A('saves') != null ? A('saves') / reach7 * 100 : null,
    commentRate: reach7 && A('comments') != null ? A('comments') / reach7 * 100 : null,
    profileConv: A('profileViews') && A('follows') != null ? A('follows') / A('profileViews') * 100 : null,
  };
  // follower snapshots
  const snaps = d.filter(x => x.followers != null);
  p.followers = snaps.length ? snaps[snaps.length - 1].followers : (media.__followers ?? null);
  const old = snaps.filter(x => x.date <= cut7).pop();
  p.followDelta7 = old && snaps.length ? snaps[snaps.length - 1].followers - old.followers : null;
  p.followGrowthPct7 = p.followDelta7 != null && old.followers ? p.followDelta7 / old.followers * 100 : null;
  // reels
  const rec = reels.slice(0, 5), base = reels.slice(5, 15);
  p.reelCount = reels.length;
  p.reelRecentMedian = median(rec.map(r => r.metrics.views));
  p.reelBaselineMedian = median(base.map(r => r.metrics.views));
  p.reelRatio = reels.length >= 8 ? trend(p.reelRecentMedian, p.reelBaselineMedian) : null;
  p.lastThreeBelow = reels.length >= 6 && p.reelBaselineMedian ? reels.slice(0, 3).every(r => r.metrics.views < 0.8 * p.reelBaselineMedian) : null;
  const wr = rec.filter(r => r.metrics.avgWatchSec != null && r.durationSec).map(r => r.metrics.avgWatchSec / r.durationSec);
  p.avgWatchRatio = wr.length ? median(wr) : null;
  // reel-level fallback for engagement / reach when account insights are missing
  const engRec = median(rec.map(engRate)), engBase = median(base.map(engRate));
  p.reelEngTrend = reels.length >= 8 ? trend(engRec, engBase) : null;
  // consistency
  const posts = all.filter(m => m.ts > now - 14 * DAY).map(m => m.ts).sort((a, b) => a - b);
  p.postsLast14 = all.length ? posts.length : null;
  if (all.length) {
    const pts = [now - 14 * DAY, ...posts, now]; let mg = 0;
    for (let i = 1; i < pts.length; i++) mg = Math.max(mg, (pts[i] - pts[i - 1]) / DAY);
    p.maxGapDays = Math.round(mg * 10) / 10;
  } else p.maxGapDays = null;
  // diversity / similarity over last 10
  const last10 = all.slice().sort((a, b) => b.ts - a.ts).slice(0, 10);
  if (last10.length >= 6) {
    const counts = {}; last10.forEach(m => counts[m.topic] = (counts[m.topic] || 0) + 1);
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    p.topTopic = top[0]; p.topicShare = top[1] / last10.length; p.distinctTopics = Object.keys(counts).length;
    let s = 0, n = 0; for (let i = 0; i < last10.length; i++) for (let j = i + 1; j < last10.length; j++) { s += jaccard(last10[i].caption, last10[j].caption); n++; }
    p.avgSim = s / n;
    p.ctaShare = last10.filter(m => m.cta !== 'none').length / last10.length;
  } else Object.assign(p, { topTopic: null, topicShare: null, distinctTopics: null, avgSim: null, ctaShare: null });
  // drift from winners
  if (reels.length >= 8) {
    const winners = reels.slice().sort((a, b) => b.metrics.views - a.metrics.views).slice(0, 3);
    const wt = new Set(winners.map(r => r.topic));
    p.driftFromWinners = !rec.some(r => wt.has(r.topic));
    p.winnerTopics = [...wt];
  } else p.driftFromWinners = null;
  // stories
  const st = stories.filter(s => s.ts > now - 14 * DAY && s.metrics?.reach != null);
  p.storyCount14 = st.length;
  p.storyReachRate = st.length && p.followers ? median(st.map(s => s.metrics.reach)) / p.followers * 100 : null;
  p.storyReplyRate = st.length ? median(st.filter(s => s.metrics.reach).map(s => (s.metrics.replies ?? 0) / s.metrics.reach * 100)) : null;
  p.dailyDays = d.length;
  return { p, reels, all };
}

// ---------- GROWTH HEALTH SCORE ----------
export function growthHealth(p) {
  const T = r => r == null ? null : scoreFromRatio(r);
  const R = (v, target) => v == null ? null : clamp(Math.round(v / target * 70));
  const comps = [
    ['reachTrend', 'Reach trend', 10, T(p.reachTrend), p.reachTrend != null ? `x${p.reachTrend.toFixed(2)} vs previous 7d` : null],
    ['viewsTrend', 'Views trend', 10, T(p.viewsTrend), p.viewsTrend != null ? `x${p.viewsTrend.toFixed(2)} vs previous 7d` : null],
    ['engagementTrend', 'Engagement trend', 10, T(p.engTrend ?? p.reelEngTrend), (p.engTrend ?? p.reelEngTrend) != null ? `x${(p.engTrend ?? p.reelEngTrend).toFixed(2)}` + (p.engTrend == null ? ' (reel-level proxy)' : '') : null],
    ['followerGrowth', 'Follower growth', 12, p.followGrowthPct7 == null ? null : clamp(Math.round(20 + 53 * p.followGrowthPct7)), p.followGrowthPct7 != null ? `${p.followGrowthPct7.toFixed(2)}% / 7d (${p.followDelta7 >= 0 ? '+' : ''}${p.followDelta7})` : null],
    ['shareRate', 'Share rate', 8, R(p.shareRate, 1.0), p.shareRate != null ? `${p.shareRate.toFixed(2)}% of reach` : null],
    ['saveRate', 'Save rate', 6, R(p.saveRate, 2.0), p.saveRate != null ? `${p.saveRate.toFixed(2)}% of reach` : null],
    ['commentRate', 'Comment rate', 6, R(p.commentRate, 0.5), p.commentRate != null ? `${p.commentRate.toFixed(2)}% of reach` : null],
    ['profileConversion', 'Profile conversion', 8, R(p.profileConv, 5), p.profileConv != null ? `${p.profileConv.toFixed(1)}% visit→follow` : null],
    ['reelPerformance', 'Reel performance', 12, T(p.reelRatio), p.reelRatio != null ? `last 5 median ${Math.round(p.reelRecentMedian)} vs ${Math.round(p.reelBaselineMedian)}` : null],
    ['storyPerformance', 'Story performance', 6, R(p.storyReachRate, 5), p.storyReachRate != null ? `${p.storyReachRate.toFixed(1)}% of followers reached` : null],
    ['consistency', 'Consistency', 6, p.postsLast14 == null ? null : clamp(Math.round(p.postsLast14 / 10 * 100 - (p.maxGapDays > 3 ? 15 : 0))), p.postsLast14 != null ? `${p.postsLast14} posts/14d, max gap ${p.maxGapDays}d` : null],
    ['diversity', 'Content diversity', 6, p.distinctTopics == null ? null : clamp(Math.round(0.5 * Math.min(1, p.distinctTopics / 4) * 100 + 0.5 * clamp((1 - p.avgSim / 0.6) * 100))), p.distinctTopics != null ? `${p.distinctTopics} topics, caption similarity ${(p.avgSim * 100).toFixed(0)}%` : null],
  ].map(([key, label, weight, score, detail]) => ({ key, label, weight, score, detail: detail || DNA }));
  const avail = comps.filter(c => c.score != null);
  const wAvail = sum(avail.map(c => c.weight));
  const coverage = wAvail / 100;
  const score = coverage >= 0.25 ? Math.round(sum(avail.map(c => c.score * c.weight)) / wAvail) : null;
  return { score, coverage: Math.round(coverage * 100), components: comps,
    note: score == null ? DNA + ': not enough measurable components' : coverage < 0.7 ? `Partial score from ${Math.round(coverage * 100)}% of components; connect the Instagram API for the rest.` : null };
}

// ---------- STUCK DETECTOR ----------
const RULES = [
  { id: 'hook_weak', title: 'Hook ضعف دارد', action: 'سه ثانیه اول را با سوال/عدد/تضاد شروع کن و مقدمه را حذف کن.',
    test: p => p.avgWatchRatio == null ? null : p.avgWatchRatio < 0.3 ? `میانگین زمان تماشا فقط ${(p.avgWatchRatio * 100).toFixed(0)}٪ طول ریلز است` : false, need: 'ig_reels_avg_watch_time + durationSec' },
  { id: 'topic_repeated', title: 'موضوع تکراری شده', action: 'این هفته دو موضوع جدید از لیست فرصت‌ها تست کن.',
    test: p => p.topicShare == null ? null : p.topicShare >= 0.6 ? `${(p.topicShare * 100).toFixed(0)}٪ از ۱۰ محتوای آخر موضوع «${p.topTopic}» است` : false, need: '≥6 content items' },
  { id: 'low_shareable', title: 'محتوای قابل اشتراک کم است', action: 'محتوایی بساز که مخاطب برای یک دوست بفرستد (چالش «تگ کن»، واقعیت‌های شغلی).',
    test: p => p.shareRate == null ? null : (p.shareRate < 0.3 || (p.commentRate != null && p.commentRate >= 0.3 && p.saveRate != null && p.saveRate < 0.8)) ? `share ${p.shareRate.toFixed(2)}%${p.commentRate != null ? `, comment ${p.commentRate.toFixed(2)}%` : ''}${p.saveRate != null ? `, save ${p.saveRate.toFixed(2)}%` : ''}: تعامل هست ولی ارزش انتقال کم است` : false, need: 'account insights (shares, saves, reach)' },
  { id: 'cta_weak', title: 'CTA ضعیف است', action: 'هر ریلز یک CTA دو گزینه‌ای یا «ذخیره کن / بفرست برای…» داشته باشد.',
    test: p => p.ctaShare == null ? null : p.ctaShare < 0.4 ? `فقط ${(p.ctaShare * 100).toFixed(0)}٪ کپشن‌های اخیر CTA دارند` : false, need: '≥6 captions' },
  { id: 'conversion_low', title: 'تبدیل بازدیدکننده به فالوور پایین است', action: 'بایو را با وعده روشن بنویس، ۳ پست پین‌شده با بهترین محتوا بگذار، در ریلز دلیل فالو را بگو.',
    test: p => p.profileConv != null ? (p.profileConv < 2 ? `فقط ${p.profileConv.toFixed(1)}٪ بازدیدکننده‌های پروفایل فالو می‌کنند` : false)
      : (p.viewsTrend != null && p.viewsTrend >= 1 && p.followGrowthPct7 != null && p.followGrowthPct7 <= 0.1 ? 'Views بالا یا ثابت است ولی فالوور اضافه نمی‌شود: Profile/CTA/Positioning ضعیف' : (p.viewsTrend == null || p.followGrowthPct7 == null ? null : false)), need: 'profile_views + follows OR views trend + follower snapshots' },
  { id: 'story_retention', title: 'Story retention پایین است', action: 'استوری‌ها را با Poll/Question شروع کن و بیش از ۳ فریم متوالی متن نگذار.',
    test: p => p.storyReachRate == null ? null : p.storyReachRate < 2 ? `فقط ${p.storyReachRate.toFixed(1)}٪ فالوورها استوری را می‌بینند` : false, need: 'stories captured by daily sync' },
  { id: 'inconsistent', title: 'انتشار نامنظم است', action: 'تقویم ثابت: حداقل ۵ ریلز در هفته و بیشترین فاصله ۲ روز.',
    test: p => p.postsLast14 == null ? null : (p.maxGapDays >= 4 || p.postsLast14 < 6) ? `${p.postsLast14} انتشار در ۱۴ روز، بیشترین فاصله ${p.maxGapDays} روز` : false, need: 'media list' },
  { id: 'too_similar', title: 'محتوا بیش از حد مشابه است', action: 'کپشن/هوک شعاری را کم کن؛ هر ریلز یک اتفاق واقعی و مشخص نشان بدهد.',
    test: p => p.avgSim == null ? null : p.avgSim >= 0.2 ? `شباهت کپشن‌های اخیر ${(p.avgSim * 100).toFixed(0)}٪` : false, need: '≥6 captions' },
  { id: 'drift', title: 'محتوای جدید از محتوای موفق قبلی فاصله دارد', action: 'برگرد به الگوی برنده (موضوع/فرمت) و زوایای جدید از آن بساز.',
    test: p => p.driftFromWinners == null ? null : p.driftFromWinners ? `۵ ریلز اخیر هیچ‌کدام در موضوع‌های برنده (${p.winnerTopics.join(', ')}) نیستند` : false, need: '≥8 reels' },
  { id: 'reel_views_no_follow', title: 'Reel دیده می‌شود ولی فالو نمی‌آورد', action: 'در ثانیه‌های پایانی دلیل فالو را بگو و کامنت پین‌شده بگذار.',
    test: p => (p.reelRatio == null || p.followGrowthPct7 == null) ? null : (p.reelRatio >= 1 && p.followGrowthPct7 < 0.2) ? 'Reel performance خوب/ثابت است ولی رشد فالوور تقریباً صفر است' : false, need: 'reels + follower snapshots' },
  { id: 'engagement_drop', title: 'Engagement افت کرده', action: 'سوال‌های دو گزینه‌ای و Poll در استوری بگذار؛ سریع به کامنت‌ها جواب بده.',
    test: p => { const e = p.engTrend ?? p.reelEngTrend; return e == null ? null : e < 0.8 ? `نرخ تعامل x${e.toFixed(2)} نسبت به دوره قبل` : false; }, need: 'insights or ≥8 reels' },
  { id: 'reach_drop', title: 'Reach افت کرده', action: 'فرمت ۱۵–۳۰ ثانیه، هوک قوی‌تر و انتشار در ساعت فعالیت مخاطب را تست کن.',
    test: p => { const r = p.reachTrend ?? p.reelRatio; return r == null ? null : r < 0.8 ? `Reach/Views x${r.toFixed(2)} نسبت به دوره قبل` + (p.reachTrend == null ? ' (reel-level proxy)' : '') : false; }, need: 'reach trend or ≥8 reels' },
  { id: 'packaging', title: 'Reach پایین ولی Watch Time خوب → بسته‌بندی/توزیع اولیه', action: 'کاور، متن روی ویدئو و ۳ ثانیه اول را عوض کن؛ همان محتوا را با عنوان قوی‌تر تکرار کن.',
    test: p => (p.avgWatchRatio == null || (p.reachTrend ?? p.reelRatio) == null) ? null : ((p.reachTrend ?? p.reelRatio) < 0.9 && p.avgWatchRatio >= 0.45) ? 'Watch time خوب است ولی Reach پایین' : false, need: 'watch time + reach' },
  { id: 'audience_unclear', title: 'مخاطب هدف مشخص نیست', action: '-', test: () => null, need: 'follower_demographics insight (not implemented)' },
  { id: 'low_original', title: 'محتوای Original کم است', action: '-', test: () => null, need: 'manual originality tag (not available from API)' },
];

export function stuckDetector(p) {
  const problems = [], notEvaluable = [];
  for (const r of RULES) {
    const res = r.test(p);
    if (res === null) notEvaluable.push({ id: r.id, title: r.title, reason: `${DNA} — needs: ${r.need}` });
    else if (res) problems.push({ id: r.id, title: r.title, evidence: res, action: r.action });
  }
  const evaluated = RULES.length - notEvaluable.length;
  const stuckScore = evaluated ? Math.min(100, Math.round(problems.length / evaluated * 100 * 1.6)) : null;
  return { stuckScore, problems, notEvaluable, evaluated, total: RULES.length };
}
